<?php
include 'config.php';
verificarLogin();

// DADOS REAIS DAS VENDAS - CONSULTAS SIMPLES E FUNCIONAIS
try {
    // TOTAL DE VENDAS DO MÊS
    $vendas_mes = $pdo->query("
        SELECT COUNT(*) as total, COALESCE(SUM(total), 0) as valor 
        FROM vendas 
        WHERE MONTH(data_criacao) = MONTH(CURRENT_DATE()) 
        AND YEAR(data_criacao) = YEAR(CURRENT_DATE())
        AND status = 'concluida'
    ")->fetch();
    
    $total_vendas = $vendas_mes['total'];
    $receita_mensal = $vendas_mes['valor'];
    
    // VENDAS DE HOJE
    $vendas_hoje = $pdo->query("
        SELECT COUNT(*) as total, COALESCE(SUM(total), 0) as valor 
        FROM vendas 
        WHERE DATE(data_criacao) = CURDATE() 
        AND status = 'concluida'
    ")->fetch();
    
    // TICKET MÉDIO
    $ticket_medio = $total_vendas > 0 ? $receita_mensal / $total_vendas : 0;
    
    // ÚLTIMAS 5 VENDAS
    $ultimas_vendas = $pdo->query("
        SELECT v.*, c.nome as cliente_nome 
        FROM vendas v
        LEFT JOIN clientes c ON v.cliente_id = c.id
        WHERE v.status = 'concluida'
        ORDER BY v.data_criacao DESC 
        LIMIT 5
    ")->fetchAll();
    
    // PRODUTOS MAIS VENDIDOS
    $produtos_mais_vendidos = $pdo->query("
        SELECT p.nome, SUM(vi.quantidade) as total_vendido
        FROM venda_itens vi
        JOIN produtos p ON vi.produto_id = p.id
        JOIN vendas v ON vi.venda_id = v.id
        WHERE v.status = 'concluida'
        GROUP BY p.id, p.nome
        ORDER BY total_vendido DESC
        LIMIT 5
    ")->fetchAll();
    
    // VENDAS ÚLTIMOS 6 MESES (PARA GRÁFICO)
    $vendas_ultimos_meses = $pdo->query("
        SELECT 
            MONTH(data_criacao) as mes,
            YEAR(data_criacao) as ano,
            COUNT(*) as quantidade,
            COALESCE(SUM(total), 0) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND data_criacao >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)
        GROUP BY YEAR(data_criacao), MONTH(data_criacao)
        ORDER BY ano, mes
    ")->fetchAll();
    
    // FORMAS DE PAGAMENTO
    $formas_pagamento = $pdo->query("
        SELECT forma_pagamento, COUNT(*) as total, SUM(total) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND data_criacao >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
        GROUP BY forma_pagamento
    ")->fetchAll();

    // DADOS GERAIS DO SISTEMA
    $total_clientes = $pdo->query("SELECT COUNT(*) as total FROM clientes WHERE ativo = 1")->fetch()['total'];
    $total_produtos = $pdo->query("SELECT COUNT(*) as total FROM produtos WHERE ativo = 1")->fetch()['total'];
    $total_servicos = $pdo->query("SELECT COUNT(*) as total FROM servicos WHERE ativo = 1")->fetch()['total'];
    $os_abertas = $pdo->query("SELECT COUNT(*) as total FROM ordens_servico WHERE status IN ('aberta', 'andamento')")->fetch()['total'];
    $produtos_estoque_baixo = $pdo->query("SELECT COUNT(*) as total FROM produtos WHERE estoque <= estoque_minimo AND ativo = 1")->fetch()['total'];

} catch (Exception $e) {
    // Se der erro, usar valores zerados
    $total_vendas = 0;
    $receita_mensal = 0;
    $ticket_medio = 0;
    $vendas_hoje = ['total' => 0, 'valor' => 0];
    $ultimas_vendas = [];
    $produtos_mais_vendidos = [];
    $vendas_ultimos_meses = [];
    $formas_pagamento = [];
    $total_clientes = $total_produtos = $total_servicos = $os_abertas = $produtos_estoque_baixo = 0;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;
            --purple: #8b5cf6;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
            overflow-x: hidden;
        }
        
        /* Header */
        .header {
            background: white;
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.25rem;
            color: #64748b;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 0.375rem;
            transition: background-color 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .logo img {
            height: 2.5rem;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            color: var(--primary);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .user-avatar {
            width: 2.5rem;
            height: 2.5rem;
            background: var(--primary);
            border-radius: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 70px;
            height: calc(100vh - 70px);
            width: 260px;
            background: #1e293b;
            color: white;
            z-index: 999;
            transition: transform 0.3s ease;
            overflow-y: auto;
            transform: translateX(0);
        }
        
        .nav-links {
            list-style: none;
            padding: 1rem 0;
        }
        
        .nav-links li {
            margin: 0.25rem 1rem;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            transition: all 0.2s;
            font-size: 0.9rem;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: var(--primary);
            color: white;
        }
        
        .nav-links i {
            width: 1.25rem;
            margin-right: 0.75rem;
            font-size: 1rem;
        }
        
        /* Main Content */
        .main-content {
            margin-top: 70px;
            margin-left: 260px;
            padding: 2rem;
            transition: all 0.3s ease;
            min-height: calc(100vh - 70px);
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 2rem 1.5rem;
            text-align: center;
            margin-left: 260px;
            transition: margin-left 0.3s ease;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, var(--primary), var(--purple));
            color: white;
            padding: 2rem;
            border-radius: 0.75rem;
            margin-bottom: 1.5rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
            border-left: 4px solid var(--primary);
        }
        
        .stat-card.success { border-left-color: var(--success); }
        .stat-card.warning { border-left-color: var(--warning); }
        .stat-card.info { border-left-color: var(--info); }
        .stat-card.danger { border-left-color: var(--danger); }
        .stat-card.purple { border-left-color: var(--purple); }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .stat-icon {
            width: 3rem;
            height: 3rem;
            border-radius: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            background: #dbeafe;
            color: var(--primary);
        }
        
        .stat-card.success .stat-icon { background: #dcfce7; color: var(--success); }
        .stat-card.warning .stat-icon { background: #fef3c7; color: var(--warning); }
        .stat-card.info .stat-icon { background: #cffafe; color: var(--info); }
        .stat-card.danger .stat-icon { background: #fee2e2; color: var(--danger); }
        .stat-card.purple .stat-icon { background: #e0e7ff; color: var(--purple); }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
            line-height: 1;
        }
        
        .stat-trend {
            display: flex;
            align-items: center;
            gap: 0.25rem;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .trend-up { color: var(--success); }
        .trend-down { color: var(--danger); }
        
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .chart-container {
            background: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
            height: 300px;
        }
        
        .card {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        
        .card-body {
            padding: 2rem;
        }
        
        /* Form Styles */
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: #2563eb;
        }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
        }
        
        /* Table Styles */
        .table-responsive {
            overflow-x: auto;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th,
        .data-table td {
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .data-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #1e293b;
            font-size: 0.875rem;
        }
        
        .data-table tr:hover {
            background: #f8fafc;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .venda-item {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 0.75rem;
        }
        
        .venda-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .venda-cliente {
            font-weight: 600;
            color: #1e293b;
        }
        
        .venda-valor {
            font-weight: 700;
            color: var(--success);
        }
        
        /* Footer Content */
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .footer-logo img {
            height: 2.5rem;
        }
        
        .footer-logo h3 {
            font-size: 1.375rem;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, var(--primary), var(--purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2rem;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 1rem;
            margin-bottom: 0.75rem;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 0.875rem;
            color: #94a3b8;
            margin-bottom: 0.25rem;
        }
        
        .copyright {
            font-size: 0.875rem;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 1.25rem;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
                box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            }
            
            .main-content {
                margin-left: 0;
                padding: 1.5rem;
            }
            
            footer {
                margin-left: 0;
                padding: 1.5rem;
            }
            
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            form {
                grid-template-columns: 1fr !important;
                gap: 1rem !important;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 1rem;
                height: 60px;
            }
            
            .sidebar {
                top: 60px;
                height: calc(100vh - 60px);
            }
            
            .main-content {
                margin-top: 60px;
                padding: 1rem;
            }
            
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .chart-container {
                height: 250px;
                padding: 1rem;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 1.5rem;
                text-align: center;
            }
            
            .logo h1 {
                font-size: 1.25rem;
            }
            
            .user-info span {
                display: none;
            }
        }

        /* Overlay para mobile */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 998;
        }
        
        .sidebar-overlay.active {
            display: block;
        }

        @media print {
            .header, .sidebar, footer, .btn {
                display: none !important;
            }
            
            .main-content {
                margin: 0 !important;
                padding: 1rem !important;
            }
            
            .card {
                box-shadow: none !important;
                border: 1px solid #ccc !important;
                margin-bottom: 1rem !important;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-chart-pie"></i> Relatórios</h5>
        
        <div class="user-info">
            <span>Olá, <?php echo $_SESSION['usuario_nome']; ?></span>
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
        </div>
    </div>

    <!-- Overlay para mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li class="active"><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="welcome-section">
            <h2>Relatórios Detalhados 📊</h2>
            <p>Dados completos do período selecionado</p>
            <small>Período: <?php echo date('d/m/Y', strtotime($data_inicio)); ?> a <?php echo date('d/m/Y', strtotime($data_fim)); ?></small>
        </div>

        <!-- FILTROS -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-filter"></i> Filtros do Relatório</h2>
            </div>
            <div class="card-body">
                <form method="GET" style="display: grid; grid-template-columns: 1fr 1fr auto auto; gap: 1rem; align-items: end;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Data Início</label>
                        <input type="date" name="data_inicio" value="<?php echo $data_inicio; ?>" class="form-control">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Data Fim</label>
                        <input type="date" name="data_fim" value="<?php echo $data_fim; ?>" class="form-control">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary" style="height: 42px;">
                            <i class="fas fa-search"></i> Atualizar
                        </button>
                    </div>
                    <div>
                        <button type="button" onclick="imprimirRelatorio()" class="btn btn-success" style="height: 42px;">
                            <i class="fas fa-print"></i> Imprimir
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- RESUMO PRINCIPAL - MESMO LAYOUT DO DASHBOARD -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <h3 style="color: #64748b; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;">Vendas do Período</h3>
                        <div class="stat-number"><?php echo $total_vendas; ?></div>
                        <div class="stat-trend <?php echo $vendas_hoje['total'] > 0 ? 'trend-up' : 'trend-down'; ?>">
                            <i class="fas fa-shopping-cart"></i>
                            <span><?php echo $vendas_hoje['total']; ?> vendas hoje</span>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card success">
                <div class="stat-header">
                    <div>
                        <h3 style="color: #64748b; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;">Faturamento Total</h3>
                        <div class="stat-number">R$ <?php echo number_format($receita_periodo, 2, ',', '.'); ?></div>
                        <div class="stat-trend <?php echo $variacao_receita >= 0 ? 'trend-up' : 'trend-down'; ?>">
                            <i class="fas fa-chart-line"></i>
                            <span><?php echo number_format(abs($variacao_receita), 1); ?>% vs mês anterior</span>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card info">
                <div class="stat-header">
                    <div>
                        <h3 style="color: #64748b; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;">Ticket Médio</h3>
                        <div class="stat-number">R$ <?php echo number_format($ticket_medio, 2, ',', '.'); ?></div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-receipt"></i>
                            <span>Por venda no período</span>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card warning">
                <div class="stat-header">
                    <div>
                        <h3 style="color: #64748b; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;">Clientes Ativos</h3>
                        <div class="stat-number"><?php echo $total_clientes; ?></div>
                        <div class="stat-trend trend-up">
                            <i class="fas fa-user-plus"></i>
                            <span><?php echo $clientes_novos; ?> novos no período</span>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card danger">
                <div class="stat-header">
                    <div>
                        <h3 style="color: #64748b; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;">OS em Aberto</h3>
                        <div class="stat-number"><?php echo $os_abertas; ?></div>
                        <div class="stat-trend trend-down">
                            <i class="fas fa-clock"></i>
                            <span>Precisam de atenção</span>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                </div>
            </div>

            <div class="stat-card purple">
                <div class="stat-header">
                    <div>
                        <h3 style="color: #64748b; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;">Produtos Cadastrados</h3>
                        <div class="stat-number"><?php echo $total_produtos; ?></div>
                        <div class="stat-trend trend-down">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span><?php echo $produtos_estoque_baixo; ?> com estoque baixo</span>
                        </div>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-box"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- GRÁFICOS - MESMOS DO DASHBOARD MAS COM DADOS DO PERÍODO -->
        <div class="charts-grid">
            <div class="chart-container">
                <h3 style="margin-bottom: 1rem; color: #1e293b;">Vendas por Dia</h3>
                <canvas id="vendasDiaChart"></canvas>
            </div>
            
            <div class="chart-container">
                <h3 style="margin-bottom: 1rem; color: #1e293b;">Formas de Pagamento</h3>
                <canvas id="pagamentoChart"></canvas>
            </div>
        </div>

        <!-- ÚLTIMAS VENDAS - MESMO LAYOUT DO DASHBOARD -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-shopping-cart"></i> Últimas Vendas do Período</h2>
            </div>
            <div class="card-body">
                <?php if (!empty($ultimas_vendas)): ?>
                    <?php foreach ($ultimas_vendas as $venda): ?>
                        <div class="venda-item">
                            <div class="venda-header">
                                <div class="venda-cliente">
                                    <?php echo $venda['cliente_nome'] ?: 'Cliente'; ?>
                                </div>
                                <div class="venda-valor">
                                    R$ <?php echo number_format($venda['total'], 2, ',', '.'); ?>
                                </div>
                            </div>
                            <div style="display: flex; gap: 1rem; font-size: 0.875rem; color: #64748b;">
                                <span><i class="fas fa-receipt"></i> <?php echo $venda['numero_cupom']; ?></span>
                                <span><i class="fas fa-calendar"></i> <?php echo date('d/m/Y H:i', strtotime($venda['data_criacao'])); ?></span>
                                <span><i class="fas fa-credit-card"></i> <?php echo ucfirst($venda['forma_pagamento']); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="text-align: center; color: #64748b; padding: 2rem;">Nenhuma venda encontrada no período</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- PRODUTOS MAIS VENDIDOS - MESMO LAYOUT DO DASHBOARD -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-star"></i> Produtos Mais Vendidos no Período</h2>
            </div>
            <div class="card-body">
                <?php if (!empty($produtos_mais_vendidos)): ?>
                    <div style="display: grid; gap: 0.75rem;">
                        <?php foreach ($produtos_mais_vendidos as $produto): ?>
                            <div style="display: flex; justify-content: between; align-items: center; padding: 0.75rem; background: #f8fafc; border-radius: 0.5rem;">
                                <span style="font-weight: 500;"><?php echo $produto['nome']; ?></span>
                                <div style="display: flex; gap: 1rem; align-items: center;">
                                    <span style="color: var(--success); font-weight: 600;"><?php echo $produto['total_vendido']; ?> unidades</span>
                                    <span style="color: var(--primary); font-weight: 600;">R$ <?php echo number_format($produto['valor_total'], 2, ',', '.'); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p style="text-align: center; color: #64748b;">Nenhum produto vendido no período</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- FORMAS DE PAGAMENTO DETALHADAS -->
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-credit-card"></i> Formas de Pagamento no Período</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Forma de Pagamento</th>
                                <th class="text-right">Quantidade</th>
                                <th class="text-right">Valor Total</th>
                                <th class="text-right">Percentual</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($formas_pagamento)): ?>
                                <?php 
                                $total_geral = $receita_periodo;
                                foreach ($formas_pagamento as $pagamento): 
                                    $percentual = $total_geral > 0 ? ($pagamento['valor'] / $total_geral) * 100 : 0;
                                ?>
                                    <tr>
                                        <td><?php echo ucfirst(str_replace('_', ' ', $pagamento['forma_pagamento'])); ?></td>
                                        <td class="text-right"><?php echo $pagamento['total']; ?></td>
                                        <td class="text-right" style="color: var(--info); font-weight: 600;">
                                            R$ <?php echo number_format($pagamento['valor'], 2, ',', '.'); ?>
                                        </td>
                                        <td class="text-right" style="color: var(--primary); font-weight: 600;">
                                            <?php echo number_format($percentual, 1); ?>%
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">Nenhuma venda no período</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 99258.9475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Menu Mobile
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        function toggleSidebar() {
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
        }

        mobileMenuBtn.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);

        // Fechar menu ao clicar em um link (mobile)
        sidebar.addEventListener('click', (e) => {
            if (e.target.tagName === 'A' && window.innerWidth <= 768) {
                toggleSidebar();
            }
        });

        // Dados para os gráficos - DADOS REAIS DO PHP
        const vendasDiaData = {
            labels: [<?php
                if (!empty($vendas_por_dia)) {
                    $labels = [];
                    foreach ($vendas_por_dia as $venda) {
                        $labels[] = "'" . date('d/m', strtotime($venda['data'])) . "'";
                    }
                    echo implode(', ', $labels);
                } else {
                    echo "'01/01', '02/01', '03/01', '04/01', '05/01'";
                }
            ?>],
            valores: [<?php
                if (!empty($vendas_por_dia)) {
                    $valores = [];
                    foreach ($vendas_por_dia as $venda) {
                        $valores[] = $venda['valor'];
                    }
                    echo implode(', ', $valores);
                } else {
                    echo "0, 0, 0, 0, 0";
                }
            ?>]
        };

        const pagamentoData = {
            labels: [<?php
                if (!empty($formas_pagamento)) {
                    $labels = [];
                    foreach ($formas_pagamento as $pagamento) {
                        $labels[] = "'" . ucfirst(str_replace('_', ' ', $pagamento['forma_pagamento'])) . "'";
                    }
                    echo implode(', ', $labels);
                } else {
                    echo "'Nenhum'";
                }
            ?>],
            valores: [<?php
                if (!empty($formas_pagamento)) {
                    $valores = [];
                    foreach ($formas_pagamento as $pagamento) {
                        $valores[] = $pagamento['valor'];
                    }
                    echo implode(', ', $valores);
                } else {
                    echo "0";
                }
            ?>]
        };

        // Gráfico de Vendas por Dia
        const vendasDiaCtx = document.getElementById('vendasDiaChart').getContext('2d');
        new Chart(vendasDiaCtx, {
            type: 'bar',
            data: {
                labels: vendasDiaData.labels,
                datasets: [{
                    label: 'Vendas (R$)',
                    data: vendasDiaData.valores,
                    backgroundColor: '#3b82f6',
                    borderColor: '#2563eb',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Gráfico de Formas de Pagamento
        const pagamentoCtx = document.getElementById('pagamentoChart').getContext('2d');
        new Chart(pagamentoCtx, {
            type: 'doughnut',
            data: {
                labels: pagamentoData.labels,
                datasets: [{
                    data: pagamentoData.valores,
                    backgroundColor: ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Função para imprimir relatório
        function imprimirRelatorio() {
            window.print();
        }

        // Ajustar layout quando a janela for redimensionada
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768 && sidebar.classList.contains('open')) {
                toggleSidebar();
            }
        });
    </script>
</body>
</html>