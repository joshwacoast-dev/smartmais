<?php
include 'config.php';
verificarLogin();

// Verificar se tem permissão para visualizar usuários
if (!temPermissao('usuarios_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

// Ações do formulário
if ($_POST) {
    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'adicionar':
                if (temPermissao('usuarios_editar')) {
                    $permissoes = isset($_POST['permissoes']) ? json_encode($_POST['permissoes']) : '[]';
                    $senha_hash = password_hash($_POST['senha'], PASSWORD_DEFAULT);
                    
                    $stmt = $pdo->prepare("INSERT INTO usuarios (login, senha, nome, email, tipo_usuario, permissoes, ativo) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $_POST['login'],
                        $senha_hash,
                        $_POST['nome'],
                        $_POST['email'],
                        $_POST['tipo_usuario'],
                        $permissoes,
                        isset($_POST['ativo']) ? 1 : 0
                    ]);
                    $sucesso = "Usuário cadastrado com sucesso!";
                }
                break;
                
            case 'editar':
                if (temPermissao('usuarios_editar')) {
                    $permissoes = isset($_POST['permissoes']) ? json_encode($_POST['permissoes']) : '[]';
                    
                    if (!empty($_POST['senha'])) {
                        $senha_hash = password_hash($_POST['senha'], PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("UPDATE usuarios SET login = ?, senha = ?, nome = ?, email = ?, tipo_usuario = ?, permissoes = ?, ativo = ? WHERE id = ?");
                        $stmt->execute([
                            $_POST['login'],
                            $senha_hash,
                            $_POST['nome'],
                            $_POST['email'],
                            $_POST['tipo_usuario'],
                            $permissoes,
                            isset($_POST['ativo']) ? 1 : 0,
                            $_POST['id']
                        ]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE usuarios SET login = ?, nome = ?, email = ?, tipo_usuario = ?, permissoes = ?, ativo = ? WHERE id = ?");
                        $stmt->execute([
                            $_POST['login'],
                            $_POST['nome'],
                            $_POST['email'],
                            $_POST['tipo_usuario'],
                            $permissoes,
                            isset($_POST['ativo']) ? 1 : 0,
                            $_POST['id']
                        ]);
                    }
                    $sucesso = "Usuário atualizado com sucesso!";
                }
                break;
                
            case 'excluir':
                if (temPermissao('usuarios_excluir')) {
                    // Não permitir excluir o próprio usuário
                    if ($_POST['id'] != $_SESSION['usuario_id']) {
                        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
                        $stmt->execute([$_POST['id']]);
                        $sucesso = "Usuário excluído com sucesso!";
                    } else {
                        $erro = "Você não pode excluir seu próprio usuário!";
                    }
                }
                break;
        }
    }
}

// Buscar usuários
$usuarios = $pdo->query("SELECT * FROM usuarios ORDER BY nome")->fetchAll();

// Buscar permissões disponíveis
$permissoes_disponiveis = $pdo->query("SELECT * FROM permissoes_sistema ORDER BY categoria, nome")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1200px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-primary { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .badge-info { 
            background: #cffafe; 
            color: #155e75; 
            border: 1px solid #a5f3fc;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .checkbox-group {
            max-height: 300px;
            overflow-y: auto;
            padding: 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            background: #fafafa;
        }
        
        .permission-category {
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .permission-category:last-child {
            margin-bottom: 0;
            border-bottom: none;
        }
        
        .permission-category h4 {
            color: #1e293b;
            margin-bottom: 12px;
            font-size: 16px;
            font-weight: 600;
            padding-bottom: 8px;
            border-bottom: 2px solid #3b82f6;
        }
        
        .permission-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 8px 0;
            border-radius: 6px;
            transition: background 0.2s;
        }
        
        .permission-item:hover {
            background: #f8fafc;
        }
        
        .permission-item input[type="checkbox"] {
            margin-top: 2px;
        }
        
        .permission-info {
            flex: 1;
        }
        
        .permission-name {
            font-weight: 500;
            color: #374151;
            font-size: 14px;
        }
        
        .permission-desc {
            color: #6b7280;
            font-size: 13px;
            margin-top: 2px;
        }
        
        .help-text {
            display: block;
            margin-top: 6px;
            color: #6b7280;
            font-size: 13px;
            line-height: 1.4;
        }
        
        .form-section {
            margin-bottom: 24px;
            padding-bottom: 24px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .form-section:last-child {
            border-bottom: none;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
            width: 20px;
        }
        
        .checkbox-group-custom {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
        }
        
        .checkbox-group-custom input[type="checkbox"] {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 2px solid #d1d5db;
            cursor: pointer;
        }
        
        .checkbox-group-custom label {
            margin: 0;
            font-weight: 500;
            color: #374151;
            cursor: pointer;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-header {
                padding: 20px;
            }
            
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-user-cog"></i> Gerenciar Usuários</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?> (<?php echo $_SESSION['usuario_tipo']; ?>)</span>
        </div>
    </div>
 <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li class="active"><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($sucesso)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $sucesso; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($erro)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $erro; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-users"></i> Lista de Usuários</h2>
                    <?php if (temPermissao('usuarios_editar')): ?>
                    <button onclick="abrirModal('adicionar')" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Novo Usuário
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Login</th>
                                    <th>Email</th>
                                    <th>Tipo</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($usuarios as $usuario): ?>
                                <tr>
                                    <td>
                                        <div style="font-weight: 500; color: #1e293b;"><?php echo $usuario['nome']; ?></div>
                                    </td>
                                    <td><?php echo $usuario['login']; ?></td>
                                    <td><?php echo $usuario['email'] ?: '<span style="color: #9ca3af;">-</span>'; ?></td>
                                    <td>
                                        <span class="badge 
                                            <?php echo $usuario['tipo_usuario'] == 'Administrador' ? 'badge-primary' : 
                                                  ($usuario['tipo_usuario'] == 'Gerente' ? 'badge-warning' : 
                                                  ($usuario['tipo_usuario'] == 'Técnico' ? 'badge-info' : 'badge-success')); ?>">
                                            <?php echo $usuario['tipo_usuario']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $usuario['ativo'] ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo $usuario['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <?php if (temPermissao('usuarios_editar')): ?>
                                            <button onclick="editarUsuario(<?php echo $usuario['id']; ?>)" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i> Editar
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if (temPermissao('usuarios_excluir') && $usuario['id'] != $_SESSION['usuario_id']): ?>
                                            <button onclick="excluirUsuario(<?php echo $usuario['id']; ?>)" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i> Excluir
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($usuarios)): ?>
                                <tr>
                                    <td colspan="6">
                                        <div class="empty-state">
                                            <i class="fas fa-users"></i>
                                            <h3>Nenhum usuário encontrado</h3>
                                            <p>Comece cadastrando o primeiro usuário do sistema</p>
                                            <?php if (temPermissao('usuarios_editar')): ?>
                                            <button onclick="abrirModal('adicionar')" class="btn btn-primary" style="margin-top: 16px;">
                                                <i class="fas fa-plus"></i> Cadastrar Usuário
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    
    <!-- Modal para adicionar/editar usuário -->
    <div id="modalUsuario" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-user-plus"></i> <span id="modalTitulo">Adicionar Usuário</span></h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formUsuario" method="POST">
                    <input type="hidden" name="acao" id="formAcao" value="adicionar">
                    <input type="hidden" name="id" id="usuarioId">
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-user"></i> Informações Básicas</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Nome Completo</label>
                                <input type="text" name="nome" id="nome" class="form-control" required 
                                       placeholder="Digite o nome completo">
                            </div>
                            
                            <div class="form-group">
                                <label>Login</label>
                                <input type="text" name="login" id="login" class="form-control" required 
                                       placeholder="Digite o nome de usuário">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" id="email" class="form-control" 
                                       placeholder="email@exemplo.com">
                            </div>
                            
                            <div class="form-group">
                                <label>Tipo de Usuário</label>
                                <select name="tipo_usuario" id="tipo_usuario" class="form-control" required>
                                    <option value="Administrador">Administrador</option>
                                    <option value="Gerente">Gerente</option>
                                    <option value="Técnico">Técnico</option>
                                    <option value="Vendedor">Vendedor</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-lock"></i> Segurança</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Senha</label>
                                <input type="password" name="senha" id="senha" class="form-control" required>
                                <span class="help-text" id="senhaHelp" style="display: none;">
                                    Deixe em branco para manter a senha atual
                                </span>
                            </div>
                            
                            <div class="form-group">
                                <label>Confirmar Senha</label>
                                <input type="password" name="confirmar_senha" id="confirmar_senha" class="form-control">
                            </div>
                        </div>
                        
                        <div class="checkbox-group-custom">
                            <input type="checkbox" name="ativo" id="ativo" value="1" checked>
                            <label for="ativo">Usuário Ativo</label>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-shield-alt"></i> Permissões do Sistema</h3>
                        
                        <div class="checkbox-group" id="permissoesContainer">
                            <?php
                            $categoria_atual = '';
                            foreach ($permissoes_disponiveis as $permissao):
                                if ($categoria_atual != $permissao['categoria']):
                                    $categoria_atual = $permissao['categoria'];
                            ?>
                            <div class="permission-category">
                                <h4><?php echo $permissao['categoria']; ?></h4>
                            <?php endif; ?>
                            
                            <div class="permission-item">
                                <input type="checkbox" name="permissoes[]" value="<?php echo $permissao['codigo']; ?>" 
                                       class="permissao-checkbox" data-categoria="<?php echo $permissao['categoria']; ?>">
                                <div class="permission-info">
                                    <div class="permission-name"><?php echo $permissao['nome']; ?></div>
                                    <div class="permission-desc"><?php echo $permissao['descricao']; ?></div>
                                </div>
                            </div>
                            
                            <?php
                                if (next($permissoes_disponiveis) && $permissoes_disponiveis[key($permissoes_disponiveis)]['categoria'] != $categoria_atual):
                            ?>
                            </div>
                            <?php
                                endif;
                            endforeach;
                            ?>
                        </div>
                    </div>
                    
                    <div style="margin-top: 32px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <button type="button" onclick="fecharModal()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Salvar Usuário
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        function abrirModal(acao) {
            document.getElementById('modalUsuario').style.display = 'block';
            document.getElementById('formAcao').value = acao;
            document.getElementById('modalTitulo').textContent = acao === 'adicionar' ? 'Adicionar Usuário' : 'Editar Usuário';
            document.getElementById('senha').required = acao === 'adicionar';
            document.getElementById('senhaHelp').style.display = acao === 'adicionar' ? 'none' : 'block';
            
            if (acao === 'adicionar') {
                document.getElementById('formUsuario').reset();
                document.querySelectorAll('.permissao-checkbox').forEach(cb => cb.checked = false);
            }
        }
        
        function fecharModal() {
            document.getElementById('modalUsuario').style.display = 'none';
        }
        
        function editarUsuario(id) {
            fetch('ajax_usuarios.php?acao=buscar&id=' + id)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na requisição');
                    }
                    return response.json();
                })
                .then(usuario => {
                    if (usuario.error) {
                        alert(usuario.error);
                        return;
                    }
                    
                    document.getElementById('usuarioId').value = usuario.id;
                    document.getElementById('nome').value = usuario.nome;
                    document.getElementById('login').value = usuario.login;
                    document.getElementById('email').value = usuario.email;
                    document.getElementById('tipo_usuario').value = usuario.tipo_usuario;
                    document.getElementById('ativo').checked = usuario.ativo == 1;
                    
                    // Limpar checkboxes
                    document.querySelectorAll('.permissao-checkbox').forEach(cb => cb.checked = false);
                    
                    // Marcar permissões do usuário
                    if (usuario.permissoes) {
                        usuario.permissoes.forEach(permissao => {
                            const checkbox = document.querySelector(`input[value="${permissao}"]`);
                            if (checkbox) checkbox.checked = true;
                        });
                    }
                    
                    abrirModal('editar');
                })
                .catch(error => {
                    console.error('Erro ao buscar usuário:', error);
                    alert('Erro ao carregar dados do usuário: ' + error.message);
                });
        }
        
        function excluirUsuario(id) {
            if (confirm('Tem certeza que deseja excluir este usuário?\n\nEsta ação não pode ser desfeita.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalUsuario');
            if (event.target === modal) {
                fecharModal();
            }
        }
        
        // Validação de senha
        document.getElementById('formUsuario').addEventListener('submit', function(e) {
            const senha = document.getElementById('senha').value;
            const confirmarSenha = document.getElementById('confirmar_senha').value;
            const acao = document.getElementById('formAcao').value;
            
            if (acao === 'adicionar' && senha !== confirmarSenha) {
                e.preventDefault();
                alert('As senhas não coincidem!');
                return false;
            }
        });

        // Debug no console
        console.log('Página de usuários carregada');
    </script>
</body>
</html>