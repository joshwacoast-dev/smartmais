-- Arquivo: smartmais_final.sql
-- Execute este arquivo no phpMyAdmin

SET FOREIGN_KEY_CHECKS = 0;
DROP DATABASE IF EXISTS smartmais;
CREATE DATABASE smartmais CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartmais;

-- Tabela de usuários
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    login VARCHAR(50) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    tipo_usuario ENUM('Administrador', 'Gerente', 'Técnico', 'Vendedor') DEFAULT 'Técnico',
    permissoes TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de informações da empresa
CREATE TABLE empresa_info (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome_empresa VARCHAR(255) NOT NULL,
    cnpj VARCHAR(20),
    endereco TEXT,
    telefone VARCHAR(20),
    email VARCHAR(100),
    site VARCHAR(100),
    logo_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de clientes
CREATE TABLE clientes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    tipo ENUM('Física', 'Jurídica') DEFAULT 'Física',
    cpf_cnpj VARCHAR(20),
    rg_ie VARCHAR(20),
    email VARCHAR(100),
    telefone VARCHAR(20),
    celular VARCHAR(20),
    endereco TEXT,
    numero VARCHAR(10),
    complemento VARCHAR(50),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    cep VARCHAR(10),
    observacoes TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de produtos
CREATE TABLE produtos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco_custo DECIMAL(10,2) DEFAULT 0,
    preco_venda DECIMAL(10,2) DEFAULT 0,
    estoque INT DEFAULT 0,
    estoque_minimo INT DEFAULT 0,
    unidade VARCHAR(20) DEFAULT 'UN',
    categoria VARCHAR(100),
    marca VARCHAR(100),
    fornecedor VARCHAR(100),
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de serviços
CREATE TABLE servicos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10,2) DEFAULT 0,
    tempo_estimado VARCHAR(50),
    categoria VARCHAR(100),
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de orçamentos
CREATE TABLE orcamentos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    numero VARCHAR(50) UNIQUE NOT NULL,
    cliente_id INT,
    data_emissao DATE,
    valido_ate DATE,
    status ENUM('Pendente', 'Aprovado', 'Rejeitado', 'Expirado') DEFAULT 'Pendente',
    subtotal DECIMAL(10,2) DEFAULT 0,
    desconto DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) DEFAULT 0,
    observacoes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (created_by) REFERENCES usuarios(id)
);

-- Tabela de itens do orçamento
CREATE TABLE orcamento_itens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    orcamento_id INT,
    tipo ENUM('produto', 'servico'),
    item_id INT,
    quantidade DECIMAL(10,2) DEFAULT 1,
    preco_unitario DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) DEFAULT 0,
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (orcamento_id) REFERENCES orcamentos(id) ON DELETE CASCADE
);

-- Tabela de ordens de serviço
CREATE TABLE ordens_servico (
    id INT PRIMARY KEY AUTO_INCREMENT,
    numero VARCHAR(50) UNIQUE NOT NULL,
    cliente_id INT,
    equipamento VARCHAR(255),
    modelo VARCHAR(100),
    numero_serie VARCHAR(100),
    defeito_relatado TEXT,
    diagnostico_tecnico TEXT,
    servico_realizado TEXT,
    observacoes TEXT,
    status ENUM('Aberta', 'Em Andamento', 'Aguardando Peças', 'Concluída', 'Entregue', 'Cancelada') DEFAULT 'Aberta',
    prioridade ENUM('Baixa', 'Normal', 'Alta', 'Urgente') DEFAULT 'Normal',
    data_entrada DATE,
    data_previsao DATE,
    data_conclusao DATE,
    subtotal DECIMAL(10,2) DEFAULT 0,
    desconto DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) DEFAULT 0,
    tecnico_id INT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (tecnico_id) REFERENCES usuarios(id),
    FOREIGN KEY (created_by) REFERENCES usuarios(id)
);

-- Tabela de itens da ordem de serviço
CREATE TABLE os_itens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ordem_servico_id INT,
    tipo ENUM('produto', 'servico'),
    item_id INT,
    quantidade DECIMAL(10,2) DEFAULT 1,
    preco_unitario DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) DEFAULT 0,
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ordem_servico_id) REFERENCES ordens_servico(id) ON DELETE CASCADE
);

-- Tabela de movimentação de estoque
CREATE TABLE estoque_movimentacao (
    id INT PRIMARY KEY AUTO_INCREMENT,
    produto_id INT,
    tipo ENUM('entrada', 'saida'),
    quantidade INT,
    motivo ENUM('compra', 'venda', 'ajuste', 'devolucao', 'producao') DEFAULT 'ajuste',
    observacoes TEXT,
    usuario_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (produto_id) REFERENCES produtos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de permissões disponíveis
CREATE TABLE permissoes_sistema (
    id INT PRIMARY KEY AUTO_INCREMENT,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(50)
);

-- Tabela de logs do sistema
CREATE TABLE logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT,
    acao VARCHAR(255),
    detalhes TEXT,
    ip VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir permissões padrão
INSERT INTO permissoes_sistema (codigo, nome, descricao, categoria) VALUES 
('clientes_visualizar', 'Visualizar Clientes', 'Permite visualizar lista de clientes', 'Clientes'),
('clientes_editar', 'Editar Clientes', 'Permite adicionar/editar clientes', 'Clientes'),
('clientes_excluir', 'Excluir Clientes', 'Permite excluir clientes', 'Clientes'),

('produtos_visualizar', 'Visualizar Produtos', 'Permite visualizar lista de produtos', 'Produtos'),
('produtos_editar', 'Editar Produtos', 'Permite adicionar/editar produtos', 'Produtos'),
('produtos_excluir', 'Excluir Produtos', 'Permite excluir produtos', 'Produtos'),

('servicos_visualizar', 'Visualizar Serviços', 'Permite visualizar lista de serviços', 'Serviços'),
('servicos_editar', 'Editar Serviços', 'Permite adicionar/editar serviços', 'Serviços'),
('servicos_excluir', 'Excluir Serviços', 'Permite excluir serviços', 'Serviços'),

('orcamentos_visualizar', 'Visualizar Orçamentos', 'Permite visualizar orçamentos', 'Orçamentos'),
('orcamentos_editar', 'Editar Orçamentos', 'Permite criar/editar orçamentos', 'Orçamentos'),
('orcamentos_excluir', 'Excluir Orçamentos', 'Permite excluir orçamentos', 'Orçamentos'),
('orcamentos_aprovar', 'Aprovar Orçamentos', 'Permite aprovar/rejeitar orçamentos', 'Orçamentos'),

('os_visualizar', 'Visualizar OS', 'Permite visualizar ordens de serviço', 'Ordens de Serviço'),
('os_editar', 'Editar OS', 'Permite criar/editar ordens de serviço', 'Ordens de Serviço'),
('os_excluir', 'Excluir OS', 'Permite excluir ordens de serviço', 'Ordens de Serviço'),
('os_concluir', 'Concluir OS', 'Permite concluir ordens de serviço', 'Ordens de Serviço'),

('estoque_visualizar', 'Visualizar Estoque', 'Permite visualizar estoque', 'Estoque'),
('estoque_editar', 'Editar Estoque', 'Permite movimentar estoque', 'Estoque'),

('relatorios_visualizar', 'Visualizar Relatórios', 'Permite visualizar relatórios', 'Relatórios'),

('usuarios_visualizar', 'Visualizar Usuários', 'Permite visualizar usuários', 'Usuários'),
('usuarios_editar', 'Editar Usuários', 'Permite criar/editar usuários', 'Usuários'),
('usuarios_excluir', 'Excluir Usuários', 'Permite excluir usuários', 'Usuários'),

('empresa_editar', 'Editar Empresa', 'Permite editar informações da empresa', 'Configurações');

-- Inserir usuário padrão (senha: admin)
INSERT INTO usuarios (login, senha, nome, email, tipo_usuario, permissoes) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador', 'admin@smartmais.com', 'Administrador', '["clientes_visualizar","clientes_editar","clientes_excluir","produtos_visualizar","produtos_editar","produtos_excluir","servicos_visualizar","servicos_editar","servicos_excluir","orcamentos_visualizar","orcamentos_editar","orcamentos_excluir","orcamentos_aprovar","os_visualizar","os_editar","os_excluir","os_concluir","estoque_visualizar","estoque_editar","relatorios_visualizar","usuarios_visualizar","usuarios_editar","usuarios_excluir","empresa_editar"]');

-- Inserir informações padrão da empresa
INSERT INTO empresa_info (nome_empresa, cnpj, endereco, telefone, email) VALUES 
('SmartMais Sistemas', '12.345.678/0001-90', 'Rua Exemplo, 123 - Centro - São Paulo/SP', '(11) 9999-9999', 'contato@smartmais.com');

-- Inserir alguns dados de exemplo
INSERT INTO clientes (nome, tipo, cpf_cnpj, email, telefone, endereco, cidade, estado) VALUES 
('João Silva', 'Física', '123.456.789-00', 'joao@email.com', '(11) 9999-8888', 'Rua A, 100 - Centro', 'São Paulo', 'SP'),
('Empresa ABC Ltda', 'Jurídica', '12.345.678/0001-99', 'contato@empresaabc.com', '(11) 7777-6666', 'Av. Principal, 500 - Jardins', 'São Paulo', 'SP');

INSERT INTO produtos (codigo, nome, descricao, preco_custo, preco_venda, estoque, categoria, marca) VALUES 
('PROD001', 'Mouse USB', 'Mouse óptico USB 1600DPI', 15.00, 29.90, 50, 'Informática', 'Logitech'),
('PROD002', 'Teclado Mecânico', 'Teclado mecânico RGB', 89.90, 199.90, 25, 'Informática', 'Redragon'),
('PROD003', 'Monitor 24"', 'Monitor LED 24 polegadas Full HD', 450.00, 799.90, 10, 'Informática', 'Samsung');

INSERT INTO servicos (codigo, nome, descricao, preco, tempo_estimado, categoria) VALUES 
('SERV001', 'Formatação e Instalação', 'Formatação e instalação do Windows e drivers', 120.00, '2-3 horas', 'Software'),
('SERV002', 'Limpeza Interna', 'Limpeza completa do computador', 80.00, '1 hora', 'Hardware'),
('SERV003', 'Troca de Tela', 'Substituição de tela LCD', 150.00, '1-2 horas', 'Hardware');

SET FOREIGN_KEY_CHECKS = 1;

SELECT 'Banco de dados SmartMais criado com sucesso!' as status;