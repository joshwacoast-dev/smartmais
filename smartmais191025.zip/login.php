<?php
session_start();
include 'config.php';

// Redirecionar se já estiver logado
if (isset($_SESSION['usuario_id'])) {
    header("Location: dashboard.php");
    exit();
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $senha = trim($_POST['senha']);
    
    if (empty($login) || empty($senha)) {
        $erro = "Preencha todos os campos!";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE login = ? AND ativo = 1");
        $stmt->execute([$login]);
        $usuario = $stmt->fetch();
        
        if ($usuario) {
            // Verificar senha - admin fixo ou hash no banco
            if (($login === 'admin' && $senha === 'admin') || password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_login'] = $usuario['login'];
                
                // Se as funções existirem no config.php
                if (function_exists('carregarPermissoesUsuario')) {
                    carregarPermissoesUsuario($usuario['id']);
                }
                if (function_exists('registrarLog')) {
                    registrarLog('Login no sistema', 'Usuário: ' . $usuario['nome']);
                }
                
                // REDIRECIONAMENTO CORRETO
                header("Location: dashboard.php");
                exit();
            } else {
                $erro = "Senha incorreta!";
            }
        } else {
            $erro = "Usuário não encontrado ou inativo!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-wrapper {
            display: flex;
            width: 100%;
            max-width: 1000px;
            min-height: 600px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .login-left {
            flex: 1;
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .login-left::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><polygon fill="%23ffffff" fill-opacity="0.03" points="0,1000 1000,0 1000,1000"/></svg>');
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 40px;
            position: relative;
            z-index: 1;
        }

        .logo img {
            height: 50px;
        }

        .logo h1 {
            font-size: 28px;
            font-weight: 700;
        }

        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .welcome-text h2 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 16px;
            position: relative;
            z-index: 1;
        }

        .welcome-text p {
            color: #cbd5e1;
            font-size: 16px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }

        .features {
            position: relative;
            z-index: 1;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            color: #cbd5e1;
        }

        .feature-item i {
            color: #3b82f6;
            font-size: 16px;
            width: 20px;
        }

        .login-right {
            flex: 1;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .login-header h2 {
            font-size: 28px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #64748b;
            font-size: 16px;
        }

        .form-group {
            margin-bottom: 24px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }

        .input-with-icon {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
            font-size: 16px;
            z-index: 2;
            width: 16px;
            height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .input-with-icon input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.2s;
            background: white;
            color: #374151;
            font-weight: 500;
        }

        .input-with-icon input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .input-with-icon input::placeholder {
            color: #9ca3af;
            font-weight: 400;
        }

        .password-container {
            position: relative;
            width: 100%;
        }

        .password-container input {
            padding-left: 44px !important;
            padding-right: 44px !important;
        }

        .password-toggle {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #9ca3af;
            cursor: pointer;
            font-size: 16px;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: all 0.2s;
            z-index: 3;
        }

        .password-toggle:hover {
            color: #374151;
            background: #f3f4f6;
        }

        .btn-login {
            width: 100%;
            padding: 16px 24px;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 8px;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }

        .btn-login:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .alert {
            padding: 16px 20px;
            background: #fef2f2;
            color: #dc2626;
            border-radius: 10px;
            margin-bottom: 24px;
            border-left: 4px solid #ef4444;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
        }

        .alert i {
            font-size: 18px;
        }

        .demo-info {
            background: #f8fafc;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #e5e7eb;
            margin-top: 30px;
        }

        .demo-info h4 {
            color: #374151;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .demo-info h4 i {
            color: #3b82f6;
        }

        .credentials {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .credential-item {
            padding: 12px;
            background: white;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }

        .credential-label {
            font-size: 12px;
            color: #6b7280;
            font-weight: 500;
            margin-bottom: 4px;
        }

        .credential-value {
            font-size: 14px;
            color: #374151;
            font-weight: 600;
            font-family: 'Monaco', 'Consolas', monospace;
        }

        @media (max-width: 768px) {
            .login-wrapper {
                flex-direction: column;
                min-height: auto;
            }
            
            .login-left {
                padding: 40px 20px;
                text-align: center;
            }
            
            .login-right {
                padding: 40px 20px;
            }
            
            .credentials {
                grid-template-columns: 1fr;
            }
            
            .logo {
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .login-wrapper {
                border-radius: 12px;
            }
            
            .login-left,
            .login-right {
                padding: 30px 20px;
            }
            
            .logo h1 {
                font-size: 24px;
            }
            
            .welcome-text h2 {
                font-size: 24px;
            }
            
            .password-container input {
                padding-left: 40px !important;
                padding-right: 40px !important;
            }
            
            .input-icon {
                left: 12px;
            }
            
            .password-toggle {
                right: 12px;
            }
        }

        .floating-shapes {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }

        .shape {
            position: absolute;
            background: rgba(59, 130, 246, 0.1);
            border-radius: 50%;
        }

        .shape-1 {
            width: 100px;
            height: 100px;
            top: 10%;
            right: 10%;
            animation: float 6s ease-in-out infinite;
        }

        .shape-2 {
            width: 150px;
            height: 150px;
            bottom: 20%;
            left: 5%;
            animation: float 8s ease-in-out infinite;
        }

        .shape-3 {
            width: 80px;
            height: 80px;
            top: 60%;
            right: 20%;
            animation: float 7s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-left">
            <div class="floating-shapes">
                <div class="shape shape-1"></div>
                <div class="shape shape-2"></div>
                <div class="shape shape-3"></div>
            </div>
            
            <div class="logo">
               
                <h1>Software<span> 2.0</span></h1>
            </div>
            
            <div class="welcome-text">
                <h2>Bem-vindo de volta!</h2>
                <p>Entre em sua conta para acessar o sistema de gestão completo.</p>
            </div>
            
            <div class="features">
                <div class="feature-item">
                    <i class="fas fa-shield-alt"></i>
                    <span>Sistema seguro e confiável</span>
                </div>
                <div class="feature-item">
                    <i class="fas fa-bolt"></i>
                    <span>Rápido e eficiente</span>
                </div>
                <div class="feature-item">
                    <i class="fas fa-chart-line"></i>
                    <span>Gestão completa do negócio</span>
                </div>
                <div class="feature-item">
                    <i class="fas fa-mobile-alt"></i>
                    <span>Totalmente responsivo</span>
                </div>
            </div>
        </div>
        
        <div class="login-right">
            <div class="login-header">
                <h2>Fazer Login</h2>
                <p>Entre com suas credenciais para continuar</p>
            </div>
            
            <?php if ($erro): ?>
                <div class="alert">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo htmlspecialchars($erro); ?></span>
                </div>
            <?php endif; ?>
            
            <form method="POST" id="loginForm">
                <div class="form-group">
                    <label for="login">Usuário</label>
                    <div class="input-with-icon">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" id="login" name="login" value="" required placeholder="Digite seu usuário">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <div class="input-with-icon">
                        <div class="password-container">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" id="senha" name="senha" value="" required placeholder="Digite sua senha">
                            <button type="button" class="password-toggle" onclick="togglePassword()">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>
                    Entrar no Sistema
                </button>
            </form>
            
           
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('senha');
            const toggleIcon = document.querySelector('.password-toggle i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                toggleIcon.className = 'fas fa-eye';
            }
        }
        
        // Aplicar padding correto para os campos com ícones
        document.addEventListener('DOMContentLoaded', function() {
            // Campo de usuário
            const userInput = document.getElementById('login');
            userInput.style.paddingLeft = '44px';
            
            // Foco no campo de usuário
            userInput.focus();
        });
        
        // Prevenir envio duplo do formulário
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
        });
    </script>
</body>
</html>