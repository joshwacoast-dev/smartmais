<?php
include 'config.php';
verificarLogin();

if (!temPermissao('servicos_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? 0;

// Função para converter valor monetário do formato brasileiro para decimal
function converterMoedaParaDecimal($valor) {
    if (empty($valor) || $valor === 'R$ 0,00') return 0;
    
    // Remove "R$" e espaços
    $valor = str_replace(['R$', ' '], '', $valor);
    
    // Remove pontos (separadores de milhar)
    $valor = str_replace('.', '', $valor);
    
    // Substitui vírgula por ponto para formato decimal
    $valor = str_replace(',', '.', $valor);
    
    return floatval($valor);
}

// Processar formulário
if ($_POST) {
    $dados = $_POST;
    
    if ($dados['acao'] == 'adicionar' && temPermissao('servicos_editar')) {
        // Converter valor monetário
        $preco = converterMoedaParaDecimal($dados['preco'] ?? '');
        
        $stmt = $pdo->prepare("INSERT INTO servicos (codigo, nome, descricao, preco, tempo_estimado, categoria) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $dados['codigo'], 
            $dados['nome'], 
            $dados['descricao'] ?? '',
            $preco,
            $dados['tempo_estimado'] ?? '',
            $dados['categoria'] ?? ''
        ]);
        
        registrarLog('Cadastro de serviço', 'Serviço: ' . $dados['nome']);
        header("Location: servicos.php?sucesso=Serviço cadastrado com sucesso!");
        exit();
    }
    elseif ($dados['acao'] == 'editar' && temPermissao('servicos_editar')) {
        // Converter valor monetário
        $preco = converterMoedaParaDecimal($dados['preco'] ?? '');
        
        $stmt = $pdo->prepare("UPDATE servicos SET codigo=?, nome=?, descricao=?, preco=?, tempo_estimado=?, categoria=?, ativo=? WHERE id=?");
        $stmt->execute([
            $dados['codigo'], 
            $dados['nome'], 
            $dados['descricao'] ?? '',
            $preco,
            $dados['tempo_estimado'] ?? '',
            $dados['categoria'] ?? '',
            $dados['ativo'] ?? 1,
            $dados['id']
        ]);
        
        registrarLog('Edição de serviço', 'Serviço ID: ' . $dados['id']);
        header("Location: servicos.php?sucesso=Serviço atualizado com sucesso!");
        exit();
    }
    elseif ($dados['acao'] == 'excluir' && temPermissao('servicos_excluir')) {
        $stmt = $pdo->prepare("UPDATE servicos SET ativo = 0 WHERE id = ?");
        $stmt->execute([$dados['id']]);
        
        registrarLog('Exclusão de serviço', 'Serviço ID: ' . $dados['id']);
        header("Location: servicos.php?sucesso=Serviço excluído com sucesso!");
        exit();
    }
}

// Buscar serviço específico para edição
$servico = null;
if ($id && $acao == 'editar') {
    $stmt = $pdo->prepare("SELECT * FROM servicos WHERE id = ?");
    $stmt->execute([$id]);
    $servico = $stmt->fetch();
}

// Buscar todos os serviços
$filtro = $_GET['filtro'] ?? '';
$where = "ativo = 1";
$params = [];

if ($filtro) {
    $where .= " AND (nome LIKE ? OR codigo LIKE ? OR descricao LIKE ?)";
    $termo = "%$filtro%";
    $params = array_merge($params, [$termo, $termo, $termo]);
}

$sql = "SELECT * FROM servicos WHERE $where ORDER BY nome";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$servicos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serviços - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1400px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 1px 3px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-info {
            background: #06b6d4;
            color: white;
            box-shadow: 0 1px 3px rgba(6, 182, 212, 0.3);
        }
        
        .btn-info:hover {
            background: #0891b2;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }
        
        .btn-sm {
            padding: 8px 12px;
            font-size: 13px;
        }
        
        /* Formulários */
        .filters {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-info { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .badge-primary { 
            background: #e0e7ff; 
            color: #3730a3; 
            border: 1px solid #c7d2fe;
        }
        
        .badge-secondary { 
            background: #f3f4f6; 
            color: #374151; 
            border: 1px solid #e5e7eb;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        /* Formulário */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 24px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .servico-code {
            font-family: 'Monaco', 'Consolas', monospace;
            font-weight: 700;
            color: #3b82f6;
            background: #eff6ff;
            padding: 4px 8px;
            border-radius: 6px;
            border: 1px solid #dbeafe;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 2px solid #d1d5db;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            font-weight: 500;
            color: #374151;
            cursor: pointer;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-header {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-tools"></i> Serviços</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
   <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li class="active"><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['erro'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $_GET['erro']; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-list"></i> Lista de Serviços</h2>
                    <?php if (temPermissao('servicos_editar')): ?>
                    <button onclick="abrirModal()" class="btn btn-success">
                        <i class="fas fa-plus"></i> Novo Serviço
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <div class="filters">
                        <input type="text" id="searchInput" class="form-control" placeholder="Buscar serviços..." 
                               value="<?php echo htmlspecialchars($filtro); ?>" style="width: 300px;">
                        <button onclick="filtrarServicos()" class="btn btn-primary">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Nome</th>
                                    <th>Preço</th>
                                    <th>Tempo Estimado</th>
                                    <th>Categoria</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($servicos as $serv): ?>
                                <tr>
                                    <td>
                                        <span class="servico-code"><?php echo $serv['codigo']; ?></span>
                                    </td>
                                    <td>
                                        <div style="font-weight: 600; color: #1e293b;">
                                            <?php echo htmlspecialchars($serv['nome']); ?>
                                        </div>
                                        <?php if ($serv['descricao']): ?>
                                        <div style="font-size: 14px; color: #6b7280; margin-top: 4px;">
                                            <?php echo substr($serv['descricao'], 0, 80); ?>...
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div style="font-weight: 700; color: #059669;">
                                            <?php echo formatarMoeda($serv['preco']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($serv['tempo_estimado']): ?>
                                        <span style="color: #374151; font-weight: 500;">
                                            <?php echo $serv['tempo_estimado']; ?>
                                        </span>
                                        <?php else: ?>
                                        <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($serv['categoria']): ?>
                                        <span class="badge badge-secondary">
                                            <?php echo $serv['categoria']; ?>
                                        </span>
                                        <?php else: ?>
                                        <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $serv['ativo'] ? 'badge-success' : 'badge-danger'; ?>">
                                            <i class="fas fa-<?php echo $serv['ativo'] ? 'check' : 'times'; ?>"></i>
                                            <?php echo $serv['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <?php if (temPermissao('servicos_editar')): ?>
                                            <button onclick="editarServico(<?php echo $serv['id']; ?>)" class="btn btn-warning btn-sm" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                            <?php if (temPermissao('servicos_excluir')): ?>
                                            <button onclick="excluirServico(<?php echo $serv['id']; ?>)" class="btn btn-danger btn-sm" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($servicos)): ?>
                                <tr>
                                    <td colspan="7">
                                        <div class="empty-state">
                                            <i class="fas fa-tools"></i>
                                            <h3>Nenhum serviço encontrado</h3>
                                            <p>Comece cadastrando seu primeiro serviço</p>
                                            <?php if (temPermissao('servicos_editar')): ?>
                                            <button onclick="abrirModal()" class="btn btn-success" style="margin-top: 16px;">
                                                <i class="fas fa-plus"></i> Cadastrar Serviço
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Modal Serviço -->
    <div id="modalServico" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus-circle"></i> <span id="modalTitulo">Novo Serviço</span></h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formServico" method="POST">
                    <input type="hidden" name="acao" id="formAcao" value="adicionar">
                    <input type="hidden" name="id" id="servicoId">
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-info-circle"></i> Informações Básicas</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Código *</label>
                                <input type="text" name="codigo" id="codigo" class="form-control" required 
                                       placeholder="Ex: SV001">
                            </div>
                            <div class="form-group">
                                <label>Nome *</label>
                                <input type="text" name="nome" id="nome" class="form-control" required 
                                       placeholder="Nome do serviço">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-align-left"></i> Descrição</h3>
                        
                        <div class="form-group">
                            <textarea name="descricao" id="descricao" class="form-control" rows="3" 
                                      placeholder="Descrição detalhada do serviço"></textarea>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-cog"></i> Configurações</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Preço *</label>
                                <input type="text" name="preco" id="preco" class="form-control money" required 
                                       placeholder="R$ 0,00">
                            </div>
                            <div class="form-group">
                                <label>Tempo Estimado</label>
                                <input type="text" name="tempo_estimado" id="tempo_estimado" class="form-control" 
                                       placeholder="Ex: 2 horas, 30 minutos">
                            </div>
                            <div class="form-group">
                                <label>Categoria</label>
                                <input type="text" name="categoria" id="categoria" class="form-control" 
                                       placeholder="Ex: Manutenção, Instalação">
                            </div>
                        </div>
                    </div>

                    <div class="form-section" id="ativoField" style="display: none;">
                        <h3 class="section-title"><i class="fas fa-toggle-on"></i> Status</h3>
                        
                        <div class="checkbox-group">
                            <input type="checkbox" name="ativo" id="ativo" value="1" checked>
                            <label for="ativo">Serviço ativo</label>
                        </div>
                    </div>

                    <div style="margin-top: 32px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <button type="button" onclick="fecharModal()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Salvar Serviço
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        function abrirModal() {
            document.getElementById('modalServico').style.display = 'block';
            document.getElementById('formAcao').value = 'adicionar';
            document.getElementById('modalTitulo').textContent = 'Novo Serviço';
            document.getElementById('ativoField').style.display = 'none';
            document.getElementById('formServico').reset();
            
            // Limpar campo de preço
            document.getElementById('preco').value = '';
        }
        
        function fecharModal() {
            document.getElementById('modalServico').style.display = 'none';
        }
        
        function filtrarServicos() {
            const filtro = document.getElementById('searchInput').value;
            window.location.href = 'servicos.php?filtro=' + encodeURIComponent(filtro);
        }
        
        function editarServico(id) {
            fetch('ajax_servicos.php?acao=buscar&id=' + id)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na requisição');
                    }
                    return response.json();
                })
                .then(servico => {
                    if (servico.error) {
                        alert(servico.error);
                        return;
                    }
                    
                    console.log('Serviço carregado:', servico);
                    
                    document.getElementById('servicoId').value = servico.id;
                    document.getElementById('codigo').value = servico.codigo;
                    document.getElementById('nome').value = servico.nome;
                    document.getElementById('descricao').value = servico.descricao || '';
                    document.getElementById('preco').value = formatarMoedaParaInput(servico.preco);
                    document.getElementById('tempo_estimado').value = servico.tempo_estimado || '';
                    document.getElementById('categoria').value = servico.categoria || '';
                    document.getElementById('ativo').checked = servico.ativo == 1;
                    
                    document.getElementById('formAcao').value = 'editar';
                    document.getElementById('modalTitulo').textContent = 'Editar Serviço';
                    document.getElementById('ativoField').style.display = 'block';
                    
                    document.getElementById('modalServico').style.display = 'block';
                })
                .catch(error => {
                    console.error('Erro ao buscar serviço:', error);
                    alert('Erro ao carregar dados do serviço: ' + error.message);
                });
        }
        
        function excluirServico(id) {
            if (confirm('Tem certeza que deseja excluir este serviço?\n\nEsta ação não pode ser desfeita.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalServico');
            if (event.target === modal) {
                fecharModal();
            }
        }

        // Formatação de moeda SIMPLIFICADA
        document.addEventListener('DOMContentLoaded', function() {
            const moneyInputs = document.querySelectorAll('.money');
            
            moneyInputs.forEach(input => {
                // Formatar ao digitar
                input.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    
                    if (value === '') {
                        e.target.value = '';
                        return;
                    }
                    
                    // Adiciona zeros à esquerda para ter pelo menos 3 dígitos
                    while (value.length < 3) {
                        value = '0' + value;
                    }
                    
                    const cents = value.slice(-2);
                    const reais = value.slice(0, -2) || '0';
                    
                    // Formata com separadores de milhar
                    const reaisFormatado = reais.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                    
                    e.target.value = `R$ ${reaisFormatado},${cents}`;
                });
            });
        });

        // Função para formatar moeda do banco para o input
        function formatarMoedaParaInput(valor) {
            if (!valor || valor == 0) return 'R$ 0,00';
            
            // Converte para número
            const numero = parseFloat(valor);
            
            // Formata para o padrão brasileiro
            return numero.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            });
        }

        // Permitir busca com Enter
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                filtrarServicos();
            }
        });

        // Debug no console
        console.log('Página de serviços carregada');
    </script>
</body>
</html>