<?php
/**
 * Sistema de Verificação - SmartMais ERP
 * Script de diagnóstico e validação do ambiente
 * @version 1.1
 * @package SmartMais
 */

// Configurações de segurança e exibição
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/html; charset=utf-8');

/**
 * Classe para verificação do sistema
 */
class SystemValidator {
    private $results = [];
    private $errors = [];
    private $warnings = [];
    
    public function __construct() {
        $this->validateEnvironment();
    }
    
    /**
     * Valida ambiente do sistema
     */
    private function validateEnvironment() {
        $this->validatePHP();
        $this->validateDirectories();
        $this->validateFiles();
        $this->validateDatabase();
    }
    
    /**
     * Verifica requisitos do PHP
     */
    private function validatePHP() {
        $phpVersion = PHP_VERSION;
        $isVersionValid = version_compare($phpVersion, '7.4.0', '>=');
        
        $this->results['php'] = [
            'title' => 'Requisitos do PHP',
            'items' => [
                'Versão do PHP' => [
                    'value' => $phpVersion,
                    'status' => $isVersionValid ? 'success' : 'error',
                    'required' => '7.4.0+',
                    'current' => $phpVersion
                ],
                'Extensão PDO' => [
                    'value' => extension_loaded('pdo') ? 'Carregada' : 'Não carregada',
                    'status' => extension_loaded('pdo') ? 'success' : 'error'
                ],
                'Extensão PDO MySQL' => [
                    'value' => extension_loaded('pdo_mysql') ? 'Carregada' : 'Não carregada',
                    'status' => extension_loaded('pdo_mysql') ? 'success' : 'error'
                ],
                'Sessões' => [
                    'value' => function_exists('session_start') ? 'Habilitada' : 'Desabilitada',
                    'status' => function_exists('session_start') ? 'success' : 'error'
                ],
                'Extensão cURL' => [
                    'value' => extension_loaded('curl') ? 'Carregada' : 'Não carregada',
                    'status' => extension_loaded('curl') ? 'success' : 'warning'
                ],
                'Upload de arquivos' => [
                    'value' => ini_get('file_uploads') ? 'Habilitado (' . ini_get('upload_max_filesize') . ')' : 'Desabilitado',
                    'status' => ini_get('file_uploads') ? 'success' : 'warning'
                ],
                'Memory Limit' => [
                    'value' => ini_get('memory_limit'),
                    'status' => (intval(ini_get('memory_limit')) >= 128) ? 'success' : 'warning',
                    'recommended' => '128M+'
                ]
            ]
        ];
        
        if (!$isVersionValid) {
            $this->errors[] = "Versão do PHP ({$phpVersion}) abaixo do requerido (7.4.0+)";
        }
    }
    
    /**
     * Verifica permissões de diretórios
     */
    private function validateDirectories() {
        $directories = ['uploads', 'temp', 'backups'];
        $items = [];
        
        foreach ($directories as $dir) {
            $item = [];
            
            // Verifica existência
            if (!file_exists($dir)) {
                if (@mkdir($dir, 0755, true)) {
                    $item['value'] = 'Criado com sucesso';
                    $item['status'] = 'success';
                } else {
                    $item['value'] = 'Falha na criação';
                    $item['status'] = 'error';
                    $this->errors[] = "Não foi possível criar o diretório: {$dir}";
                }
            } else {
                $item['value'] = 'Diretório existente';
                $item['status'] = 'success';
            }
            
            // Verifica permissão de escrita
            if (is_writable($dir)) {
                $item['writable'] = 'Gravação permitida';
                $item['writable_status'] = 'success';
            } else {
                $item['writable'] = 'Gravação negada';
                $item['writable_status'] = 'error';
                $this->errors[] = "Diretório sem permissão de escrita: {$dir}";
            }
            
            $items[$dir] = $item;
        }
        
        $this->results['directories'] = [
            'title' => 'Diretórios do Sistema',
            'items' => $items
        ];
    }
    
    /**
     * Verifica arquivos essenciais
     */
    private function validateFiles() {
        $essentialFiles = [
            'config.php',
            'login.php', 
            'dashboard.php',
            'clientes.php',
            'produtos.php',
            'servicos.php',
            'orcamentos.php',
            'ordens_servico.php',
            'estoque.php',
            'usuarios.php',
            'empresa.php',
            'logout.php'
        ];
        
        $items = [];
        foreach ($essentialFiles as $file) {
            if (file_exists($file)) {
                $size = filesize($file);
                $items[$file] = [
                    'value' => 'Presente (' . $this->formatBytes($size) . ')',
                    'status' => 'success'
                ];
            } else {
                $items[$file] = [
                    'value' => 'Arquivo ausente',
                    'status' => 'error'
                ];
                $this->errors[] = "Arquivo essencial não encontrado: {$file}";
            }
        }
        
        $this->results['files'] = [
            'title' => 'Arquivos do Sistema',
            'items' => $items
        ];
    }
    
    /**
     * Verifica conexão com banco de dados
     */
    private function validateDatabase() {
        $items = [];
        
        // Testar diferentes configurações de conexão
        $connectionTests = [
            'localhost' => ['host' => 'localhost', 'dbname' => 'smartmais', 'user' => 'root', 'pass' => ''],
            '127.0.0.1' => ['host' => '127.0.0.1', 'dbname' => 'smartmais', 'user' => 'root', 'pass' => ''],
        ];
        
        $connectionSuccess = false;
        $lastError = '';
        
        foreach ($connectionTests as $testName => $config) {
            try {
                $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4";
                $pdo = new PDO($dsn, $config['user'], $config['pass'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_TIMEOUT => 5
                ]);
                
                $items['conexao'] = [
                    'value' => "Conectado via {$testName}",
                    'status' => 'success',
                    'details' => "Host: {$config['host']}, Banco: {$config['dbname']}"
                ];
                
                $connectionSuccess = true;
                
                // Verificar tabelas necessárias
                $requiredTables = [
                    'usuarios', 'empresa_info', 'clientes', 'produtos', 'servicos',
                    'orcamentos', 'orcamento_itens', 'ordens_servico', 'os_itens',
                    'estoque_movimentacao', 'permissoes_sistema'
                ];
                
                $stmt = $pdo->query("SHOW TABLES");
                $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                $items['total_tabelas'] = [
                    'value' => count($existingTables) . ' tabelas encontradas',
                    'status' => count($existingTables) > 0 ? 'success' : 'warning'
                ];
                
                // Verificar tabelas específicas
                $missingTables = [];
                foreach ($requiredTables as $table) {
                    if (in_array($table, $existingTables)) {
                        $items["tabela_{$table}"] = [
                            'value' => 'Tabela presente',
                            'status' => 'success'
                        ];
                    } else {
                        $items["tabela_{$table}"] = [
                            'value' => 'Tabela ausente',
                            'status' => 'error'
                        ];
                        $missingTables[] = $table;
                    }
                }
                
                if (!empty($missingTables)) {
                    $this->errors[] = "Tabelas necessárias não encontradas: " . implode(', ', $missingTables);
                }
                
                break; // Sai do loop se uma conexão funcionar
                
            } catch (PDOException $e) {
                $lastError = $e->getMessage();
                continue; // Tenta próxima configuração
            }
        }
        
        if (!$connectionSuccess) {
            $items['conexao'] = [
                'value' => 'Falha na conexão',
                'status' => 'error',
                'details' => $lastError
            ];
            $this->errors[] = "Não foi possível conectar ao banco de dados: {$lastError}";
            $this->warnings[] = "Verifique: servidor MySQL, nome do banco, usuário e senha";
        }
        
        $this->results['database'] = [
            'title' => 'Banco de Dados',
            'items' => $items
        ];
    }
    
    /**
     * Formata bytes para leitura humana
     */
    private function formatBytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
    
    /**
     * Gera relatório HTML
     */
    public function generateReport() {
        echo '<!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Verificação do Sistema - SmartMais ERP</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { 
                    font-family: "Segoe UI", Arial, sans-serif; 
                    line-height: 1.6; 
                    color: #333; 
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                }
                .container { 
                    max-width: 1200px; 
                    margin: 0 auto; 
                    background: white; 
                    border-radius: 10px; 
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    overflow: hidden;
                }
                .header { 
                    background: linear-gradient(135deg, #2c3e50, #34495e);
                    color: white; 
                    padding: 30px; 
                    text-align: center;
                }
                .header h1 { 
                    font-size: 2.5em; 
                    margin-bottom: 10px;
                    font-weight: 300;
                }
                .header .subtitle { 
                    font-size: 1.1em; 
                    opacity: 0.9;
                }
                .status-section { 
                    padding: 25px; 
                    border-bottom: 1px solid #eee; 
                }
                .status-section:last-child { border-bottom: none; }
                .status-section h2 { 
                    color: #2c3e50; 
                    margin-bottom: 20px; 
                    font-size: 1.4em;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .status-item { 
                    display: flex; 
                    justify-content: space-between; 
                    align-items: center;
                    padding: 12px 15px; 
                    margin-bottom: 8px; 
                    background: #f8f9fa;
                    border-radius: 6px;
                    border-left: 4px solid #ddd;
                    flex-wrap: wrap;
                }
                .status-success { border-left-color: #28a745; background: #f8fff9; }
                .status-error { border-left-color: #dc3545; background: #fff8f8; }
                .status-warning { border-left-color: #ffc107; background: #fffef0; }
                .status-label { flex: 1; font-weight: 500; min-width: 200px; }
                .status-value { flex: 2; min-width: 250px; }
                .status-details { flex-basis: 100%; font-size: 0.85em; color: #666; margin-top: 5px; }
                .status-badge { 
                    padding: 4px 12px; 
                    border-radius: 20px; 
                    font-size: 0.85em; 
                    font-weight: 500;
                    white-space: nowrap;
                }
                .badge-success { background: #28a745; color: white; }
                .badge-error { background: #dc3545; color: white; }
                .badge-warning { background: #ffc107; color: #212529; }
                .next-steps { 
                    background: #e8f4fd; 
                    padding: 25px; 
                    border-radius: 8px;
                    margin-top: 20px;
                }
                .next-steps h3 { color: #155724; margin-bottom: 15px; }
                .next-steps ol { padding-left: 20px; }
                .next-steps li { margin-bottom: 10px; }
                .next-steps code { 
                    background: #f1f1f1; 
                    padding: 2px 6px; 
                    border-radius: 3px; 
                    font-family: monospace;
                }
                .summary { 
                    background: #f8f9fa; 
                    padding: 20px; 
                    text-align: center;
                    border-top: 1px solid #dee2e6;
                }
                .error-count { 
                    display: inline-block;
                    padding: 10px 20px;
                    margin: 10px;
                    border-radius: 6px;
                    font-weight: bold;
                }
                .errors-present { background: #dc3545; color: white; }
                .no-errors { background: #28a745; color: white; }
                .warnings-present { background: #ffc107; color: #212529; }
                @media (max-width: 768px) {
                    .status-item { flex-direction: column; align-items: flex-start; }
                    .status-label, .status-value { min-width: auto; margin-bottom: 5px; }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🔍 Sistema de Verificação</h1>
                    <div class="subtitle">SmartMais ERP - Diagnóstico do Ambiente</div>
                </div>';
        
        // Seções de verificação
        foreach ($this->results as $section) {
            echo '<div class="status-section">
                    <h2>📋 ' . $section['title'] . '</h2>';
            
            foreach ($section['items'] as $label => $item) {
                $statusClass = 'status-' . $item['status'];
                $badgeClass = 'badge-' . $item['status'];
                
                echo '<div class="status-item ' . $statusClass . '">
                        <div class="status-label">' . $label . '</div>
                        <div class="status-value">' . $item['value'];
                
                if (isset($item['required'])) {
                    echo ' <small>(Requisito: ' . $item['required'] . ')</small>';
                }
                if (isset($item['current'])) {
                    echo ' <small>(Atual: ' . $item['current'] . ')</small>';
                }
                if (isset($item['recommended'])) {
                    echo ' <small>(Recomendado: ' . $item['recommended'] . ')</small>';
                }
                
                echo '</div>
                        <span class="status-badge ' . $badgeClass . '">' . 
                        strtoupper($item['status']) . '</span>';
                
                if (isset($item['writable'])) {
                    $writableBadgeClass = 'badge-' . $item['writable_status'];
                    echo '<span class="status-badge ' . $writableBadgeClass . '">' . 
                         $item['writable'] . '</span>';
                }
                
                if (isset($item['details'])) {
                    echo '<div class="status-details">' . $item['details'] . '</div>';
                }
                
                echo '</div>';
            }
            
            echo '</div>';
        }
        
        // Próximos passos
        echo '<div class="status-section">
                <h2>🚀 Próximos Passos para Instalação</h2>
                <div class="next-steps">
                    <ol>
                        <li><strong>Importar banco de dados:</strong> Execute o arquivo <code>smartmais_completo.sql</code> no phpMyAdmin</li>
                        <li><strong>Configurar conexão:</strong> Edite o arquivo <code>config.php</code> com os dados do seu banco</li>
                        <li><strong>Verificar credenciais:</strong> Confirme usuário, senha e nome do banco MySQL</li>
                        <li><strong>Acessar sistema:</strong> Navegue para <code>http://seusite.com/smartmais/login.php</code></li>
                        <li><strong>Login inicial:</strong> Utilize usuário <code>admin</code> e senha <code>admin</code></li>
                        <li><strong>Segurança:</strong> Altere a senha padrão após o primeiro acesso</li>
                    </ol>
                </div>
              </div>';
        
        // Resumo
        $errorCount = count($this->errors);
        $warningCount = count($this->warnings);
        
        echo '<div class="summary">';
        
        if ($errorCount > 0) {
            echo '<div class="error-count errors-present">
                    ' . $errorCount . ' erro(s) encontrado(s)
                  </div>';
        }
        
        if ($warningCount > 0) {
            echo '<div class="error-count warnings-present">
                    ' . $warningCount . ' aviso(s)
                  </div>';
        }
        
        if ($errorCount === 0 && $warningCount === 0) {
            echo '<div class="error-count no-errors">
                    Sistema verificado com sucesso!
                  </div>';
        }
        
        if ($errorCount > 0) {
            echo '<div style="margin-top: 15px; text-align: left; max-width: 600px; margin: 15px auto;">
                    <h4>Problemas identificados:</h4>
                    <ul style="text-align: left;">';
            foreach ($this->errors as $error) {
                echo '<li>' . htmlspecialchars($error) . '</li>';
            }
            echo '</ul></div>';
        }
        
        if ($warningCount > 0) {
            echo '<div style="margin-top: 15px; text-align: left; max-width: 600px; margin: 15px auto;">
                    <h4>Recomendações:</h4>
                    <ul style="text-align: left;">';
            foreach ($this->warnings as $warning) {
                echo '<li>' . htmlspecialchars($warning) . '</li>';
            }
            echo '</ul></div>';
        }
        
        echo '</div></div></body></html>';
    }
}

// Executar verificação
try {
    $validator = new SystemValidator();
    $validator->generateReport();
} catch (Exception $e) {
    echo "<h1>Erro na verificação do sistema</h1>";
    echo "<p>Ocorreu um erro durante a verificação: " . $e->getMessage() . "</p>";
    echo "<p>Verifique se o PHP está na versão 7.4 ou superior.</p>";
}
?>