<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $token = $_POST['token'] ?? '';
    
    // Validar dados
    if (empty($tipo) || $id <= 0 || empty($nome) || empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
        exit;
    }
    
    // Verificar se é um acesso via token válido
    if (!empty($token)) {
        $stmt = $pdo->prepare("SELECT * FROM documentos_compartilhados WHERE token = ? AND expira_em > NOW()");
        $stmt->execute([$token]);
        $compartilhamento = $stmt->fetch();
        
        if (!$compartilhamento) {
            echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado']);
            exit;
        }
    }
    
    // Verificar se já existe assinatura
    $stmt = $pdo->prepare("SELECT id FROM assinaturas_digitais WHERE tipo_documento = ? AND documento_id = ?");
    $stmt->execute([$tipo, $id]);
    $assinatura_existente = $stmt->fetch();
    
    if ($assinatura_existente) {
        echo json_encode(['success' => false, 'message' => 'Documento já foi assinado']);
        exit;
    }
    
    // Inserir assinatura digital
    $ip = $_SERVER['REMOTE_ADDR'];
    $data_assinatura = date('Y-m-d H:i:s');
    
    $stmt = $pdo->prepare("INSERT INTO assinaturas_digitais (tipo_documento, documento_id, nome, email, ip, data_assinatura) VALUES (?, ?, ?, ?, ?, ?)");
    $result = $stmt->execute([$tipo, $id, $nome, $email, $ip, $data_assinatura]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Documento assinado com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao salvar assinatura']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
}
?>