<?php
function popularEstadosCidades($pdo) {
    // Verificar se já existem estados
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM estados");
    $result = $stmt->fetch();
    
    if ($result['total'] == 0) {
        // Inserir estados
        $estados = [
            ['AC', 'Acre'],
            ['AL', 'Alagoas'],
            ['AP', 'Amapá'],
            ['AM', 'Amazonas'],
            ['BA', 'Bahia'],
            ['CE', 'Ceará'],
            ['DF', 'Distrito Federal'],
            ['ES', 'Espírito Santo'],
            ['GO', 'Goiás'],
            ['MA', 'Maranhão'],
            ['MT', 'Mato Grosso'],
            ['MS', 'Mato Grosso do Sul'],
            ['MG', 'Minas Gerais'],
            ['PA', 'Pará'],
            ['PB', 'Paraíba'],
            ['PR', 'Paraná'],
            ['PE', 'Pernambuco'],
            ['PI', 'Piauí'],
            ['RJ', 'Rio de Janeiro'],
            ['RN', 'Rio Grande do Norte'],
            ['RS', 'Rio Grande do Sul'],
            ['RO', 'Rondônia'],
            ['RR', 'Roraima'],
            ['SC', 'Santa Catarina'],
            ['SP', 'São Paulo'],
            ['SE', 'Sergipe'],
            ['TO', 'Tocantins']
        ];
        
        foreach ($estados as $estado) {
            $stmt = $pdo->prepare("INSERT INTO estados (uf, nome) VALUES (?, ?)");
            $stmt->execute([$estado[0], $estado[1]]);
        }
        
        echo "Estados inseridos com sucesso!<br>";
    }
    
    // Aqui você pode adicionar as cidades principais de cada estado
    // Por enquanto, vamos criar um sistema que carrega cidades via API
}
?>