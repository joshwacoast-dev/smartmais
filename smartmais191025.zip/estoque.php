<?php
include 'config.php';
verificarLogin();

if (!temPermissao('estoque_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

// Processar movimentação de estoque
if ($_POST && temPermissao('estoque_editar')) {
    $dados = $_POST;
    
    if ($dados['acao'] == 'ajustar_estoque') {
        $produto_id = $dados['produto_id'];
        $tipo = $dados['tipo'];
        $quantidade = $dados['quantidade'];
        $motivo = $dados['motivo'];
        $observacoes = $dados['observacoes'];
        
        // Atualizar estoque do produto
        $sinal = $tipo == 'entrada' ? '+' : '-';
        $stmt = $pdo->prepare("UPDATE produtos SET estoque = estoque $sinal ? WHERE id = ?");
        $stmt->execute([$quantidade, $produto_id]);
        
        // Registrar movimentação
        $stmt = $pdo->prepare("INSERT INTO estoque_movimentacao (produto_id, tipo, quantidade, motivo, observacoes, usuario_id) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$produto_id, $tipo, $quantidade, $motivo, $observacoes, $_SESSION['usuario_id']]);
        
        registrarLog('Movimentação de estoque', 'Produto ID: ' . $produto_id . ' - ' . $tipo . ' - Qtd: ' . $quantidade);
        header("Location: estoque.php?sucesso=Estoque ajustado com sucesso!");
        exit();
    }
}

// Buscar produtos com estoque
$filtro = $_GET['filtro'] ?? '';
$estoque_baixo = isset($_GET['estoque_baixo']);

$where = "ativo = 1";
$params = [];

if ($filtro) {
    $where .= " AND (nome LIKE ? OR codigo LIKE ?)";
    $termo = "%$filtro%";
    $params = [$termo, $termo];
}

if ($estoque_baixo) {
    $where .= " AND estoque <= estoque_minimo AND estoque_minimo > 0";
}

$sql = "SELECT * FROM produtos WHERE $where ORDER BY nome";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$produtos = $stmt->fetchAll();

// Buscar movimentações recentes
$movimentacoes = $pdo->query("
    SELECT em.*, p.nome as produto_nome, u.nome as usuario_nome 
    FROM estoque_movimentacao em 
    LEFT JOIN produtos p ON em.produto_id = p.id 
    LEFT JOIN usuarios u ON em.usuario_id = u.id 
    ORDER BY em.created_at DESC 
    LIMIT 50
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estoque - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1200px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 13px;
        }
        
        /* Formulários */
        .filters {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .search-box {
            display: flex;
            gap: 12px;
            align-items: center;
            flex: 1;
            min-width: 300px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        .stock-low {
            background: #fffbeb !important;
            border-left: 4px solid #f59e0b;
        }
        
        .stock-out {
            background: #fef2f2 !important;
            border-left: 4px solid #ef4444;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        .movimentacao-entrada {
            color: #059669;
            font-weight: 600;
        }
        
        .movimentacao-saida {
            color: #dc2626;
            font-weight: 600;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 2px solid #d1d5db;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            font-weight: 500;
            color: #374151;
            cursor: pointer;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 80px;
            line-height: 1.5;
        }
        
        .product-info {
            background: #f8fafc;
            padding: 16px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        
        .product-info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .product-info-item:last-child {
            margin-bottom: 0;
        }
        
        .product-info-label {
            font-weight: 500;
            color: #6b7280;
        }
        
        .product-info-value {
            font-weight: 600;
            color: #1e293b;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                min-width: auto;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-header {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-warehouse"></i> Controle de Estoque</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
   <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li class="active"><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['erro'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $_GET['erro']; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-boxes"></i> Produtos em Estoque</h2>
                </div>
                
                <div class="card-body">
                    <div class="filters">
                        <div class="search-box">
                            <input type="text" id="searchInput" class="form-control" 
                                   placeholder="Buscar produtos por nome ou código..." 
                                   value="<?php echo htmlspecialchars($filtro); ?>">
                            <button onclick="filtrarEstoque()" class="btn btn-primary">
                                <i class="fas fa-search"></i> Buscar
                            </button>
                        </div>
                        
                        <div class="checkbox-group">
                            <input type="checkbox" id="estoqueBaixoCheck" <?php echo $estoque_baixo ? 'checked' : ''; ?> onchange="filtrarEstoque()">
                            <label for="estoqueBaixoCheck">Mostrar apenas estoque baixo</label>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Produto</th>
                                    <th>Código</th>
                                    <th>Estoque Atual</th>
                                    <th>Estoque Mínimo</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($produtos as $prod): ?>
                                <?php
                                $classe_estoque = '';
                                if ($prod['estoque'] == 0) {
                                    $classe_estoque = 'stock-out';
                                } elseif ($prod['estoque_minimo'] > 0 && $prod['estoque'] <= $prod['estoque_minimo']) {
                                    $classe_estoque = 'stock-low';
                                }
                                ?>
                                <tr class="<?php echo $classe_estoque; ?>">
                                    <td>
                                        <div style="font-weight: 600; color: #1e293b; margin-bottom: 4px;">
                                            <?php echo htmlspecialchars($prod['nome']); ?>
                                        </div>
                                        <?php if ($prod['marca']): ?>
                                        <div style="font-size: 13px; color: #6b7280;">
                                            <i class="fas fa-tag"></i> <?php echo $prod['marca']; ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <code style="background: #f3f4f6; padding: 4px 8px; border-radius: 4px; font-size: 13px;">
                                            <?php echo $prod['codigo']; ?>
                                        </code>
                                    </td>
                                    <td>
                                        <div style="font-weight: 700; color: #1e293b; font-size: 16px;">
                                            <?php echo $prod['estoque']; ?> <?php echo $prod['unidade']; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($prod['estoque_minimo'] > 0): ?>
                                        <div style="color: #6b7280;">
                                            <?php echo $prod['estoque_minimo']; ?> <?php echo $prod['unidade']; ?>
                                        </div>
                                        <?php else: ?>
                                        <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($prod['estoque'] == 0): ?>
                                        <span class="badge badge-danger">
                                            <i class="fas fa-times-circle"></i> ESGOTADO
                                        </span>
                                        <?php elseif ($prod['estoque_minimo'] > 0 && $prod['estoque'] <= $prod['estoque_minimo']): ?>
                                        <span class="badge badge-warning">
                                            <i class="fas fa-exclamation-triangle"></i> ESTOQUE BAIXO
                                        </span>
                                        <?php else: ?>
                                        <span class="badge badge-success">
                                            <i class="fas fa-check-circle"></i> NORMAL
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (temPermissao('estoque_editar')): ?>
                                        <button onclick="ajustarEstoque(<?php echo $prod['id']; ?>)" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i> Ajustar
                                        </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($produtos)): ?>
                                <tr>
                                    <td colspan="6">
                                        <div class="empty-state">
                                            <i class="fas fa-boxes"></i>
                                            <h3>Nenhum produto encontrado</h3>
                                            <p><?php echo $estoque_baixo ? 'Nenhum produto com estoque baixo' : 'Comece cadastrando produtos no sistema'; ?></p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-exchange-alt"></i> Movimentações Recentes</h2>
                </div>
                
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Data/Hora</th>
                                    <th>Produto</th>
                                    <th>Tipo</th>
                                    <th>Quantidade</th>
                                    <th>Motivo</th>
                                    <th>Usuário</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($movimentacoes as $mov): ?>
                                <tr>
                                    <td>
                                        <div style="font-weight: 500; color: #374151;">
                                            <?php echo date('d/m/Y', strtotime($mov['created_at'])); ?>
                                        </div>
                                        <div style="font-size: 13px; color: #6b7280;">
                                            <?php echo date('H:i', strtotime($mov['created_at'])); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($mov['produto_nome']); ?></td>
                                    <td>
                                        <span class="<?php echo $mov['tipo'] == 'entrada' ? 'movimentacao-entrada' : 'movimentacao-saida'; ?>">
                                            <i class="fas fa-<?php echo $mov['tipo'] == 'entrada' ? 'plus' : 'minus'; ?>"></i>
                                            <?php echo $mov['tipo'] == 'entrada' ? 'ENTRADA' : 'SAÍDA'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?php echo $mov['quantidade']; ?></strong>
                                    </td>
                                    <td>
                                        <?php 
                                        $motivos = [
                                            'compra' => 'Compra',
                                            'venda' => 'Venda', 
                                            'ajuste' => 'Ajuste',
                                            'devolucao' => 'Devolução',
                                            'producao' => 'Produção'
                                        ];
                                        echo $motivos[$mov['motivo']] ?? $mov['motivo'];
                                        ?>
                                    </td>
                                    <td><?php echo $mov['usuario_nome']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($movimentacoes)): ?>
                                <tr>
                                    <td colspan="6">
                                        <div class="empty-state">
                                            <i class="fas fa-exchange-alt"></i>
                                            <h3>Nenhuma movimentação registrada</h3>
                                            <p>As movimentações de estoque aparecerão aqui</p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Modal Ajustar Estoque -->
    <div id="modalEstoque" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-edit"></i> Ajustar Estoque</h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formEstoque" method="POST">
                    <input type="hidden" name="acao" value="ajustar_estoque">
                    <input type="hidden" name="produto_id" id="produtoId">
                    
                    <div class="product-info">
                        <div class="product-info-item">
                            <span class="product-info-label">Produto:</span>
                            <span class="product-info-value" id="produtoNome"></span>
                        </div>
                        <div class="product-info-item">
                            <span class="product-info-label">Estoque Atual:</span>
                            <span class="product-info-value" id="estoqueAtual"></span>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Tipo de Movimentação</label>
                            <select name="tipo" id="tipoMovimentacao" class="form-control" required>
                                <option value="entrada">Entrada (Adicionar)</option>
                                <option value="saida">Saída (Remover)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Quantidade</label>
                            <input type="number" name="quantidade" class="form-control" min="1" required 
                                   placeholder="Digite a quantidade">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Motivo</label>
                        <select name="motivo" class="form-control" required>
                            <option value="compra">Compra</option>
                            <option value="venda">Venda</option>
                            <option value="ajuste">Ajuste de Estoque</option>
                            <option value="devolucao">Devolução</option>
                            <option value="producao">Produção</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Observações</label>
                        <textarea name="observacoes" class="form-control" rows="3" 
                                  placeholder="Observações adicionais sobre a movimentação"></textarea>
                    </div>
                    
                    <div style="margin-top: 24px; text-align: right;">
                        <button type="button" onclick="fecharModal()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Salvar Ajuste
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        function filtrarEstoque() {
            const filtro = document.getElementById('searchInput').value;
            const estoqueBaixo = document.getElementById('estoqueBaixoCheck').checked;
            
            let url = 'estoque.php?';
            if (filtro) url += 'filtro=' + encodeURIComponent(filtro) + '&';
            if (estoqueBaixo) url += 'estoque_baixo=1&';
            
            window.location.href = url;
        }
        
        function ajustarEstoque(produtoId) {
            fetch('ajax_produtos.php?acao=buscar&id=' + produtoId)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na requisição');
                    }
                    return response.json();
                })
                .then(produto => {
                    if (produto.error) {
                        alert(produto.error);
                        return;
                    }
                    
                    document.getElementById('produtoId').value = produto.id;
                    document.getElementById('produtoNome').textContent = produto.nome + ' (' + produto.codigo + ')';
                    document.getElementById('estoqueAtual').textContent = produto.estoque + ' ' + (produto.unidade || 'UN');
                    
                    document.getElementById('modalEstoque').style.display = 'block';
                })
                .catch(error => {
                    console.error('Erro ao buscar produto:', error);
                    alert('Erro ao carregar dados do produto: ' + error.message);
                });
        }
        
        function fecharModal() {
            document.getElementById('modalEstoque').style.display = 'none';
        }
        
        // Buscar ao pressionar Enter
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                filtrarEstoque();
            }
        });
        
        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalEstoque');
            if (event.target === modal) {
                fecharModal();
            }
        }

        // Debug no console
        console.log('Página de estoque carregada');
    </script>
</body>
</html>