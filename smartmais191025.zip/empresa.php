<?php
include 'config.php';
verificarLogin();

if (!temPermissao('empresa_editar')) {
    header("Location: dashboard.php");
    exit();
}

// Buscar informações da empresa
$stmt = $pdo->prepare("SELECT * FROM empresa_info WHERE id = 1");
$stmt->execute();
$empresa = $stmt->fetch();

// Processar atualização
if ($_POST) {
    $dados = $_POST;
    
    if ($dados['acao'] == 'atualizar') {
        $stmt = $pdo->prepare("UPDATE empresa_info SET nome_empresa=?, cnpj=?, endereco=?, telefone=?, email=?, site=? WHERE id=1");
        $stmt->execute([
            $dados['nome_empresa'], $dados['cnpj'], $dados['endereco'],
            $dados['telefone'], $dados['email'], $dados['site']
        ]);
        
        // Processar upload de logo
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
            // Criar pasta uploads se não existir
            if (!file_exists('uploads')) {
                mkdir('uploads', 0755, true);
            }
            
            $extensao = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
            $nome_arquivo = 'logo_' . time() . '.' . $extensao;
            $caminho = 'uploads/' . $nome_arquivo;
            
            if (move_uploaded_file($_FILES['logo']['tmp_name'], $caminho)) {
                $stmt = $pdo->prepare("UPDATE empresa_info SET logo_path = ? WHERE id = 1");
                $stmt->execute([$caminho]);
            }
        }
        
        registrarLog('Atualização dados empresa', 'Empresa: ' . $dados['nome_empresa']);
        header("Location: empresa.php?sucesso=Dados da empresa atualizados com sucesso!");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1000px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Formulários */
        .form-group {
            margin-bottom: 24px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        /* Seções especiais */
        .logo-section {
            background: #f8fafc;
            padding: 24px;
            border-radius: 8px;
            border: 2px dashed #cbd5e1;
            text-align: center;
            margin-bottom: 20px;
        }
        
        .logo-preview {
            display: inline-block;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .logo-preview img {
            max-height: 80px;
            max-width: 200px;
            border-radius: 4px;
        }
        
        .file-upload {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-upload-label {
            display: block;
            padding: 16px;
            background: white;
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            text-align: center;
            color: #6b7280;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .file-upload-label:hover {
            border-color: #3b82f6;
            color: #3b82f6;
            background: #f0f9ff;
        }
        
        .file-upload-label i {
            margin-right: 8px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .section-divider {
            height: 1px;
            background: #e2e8f0;
            margin: 32px 0;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
            width: 20px;
        }
        
        .help-text {
            display: block;
            margin-top: 6px;
            color: #6b7280;
            font-size: 13px;
            line-height: 1.4;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-building"></i> Informações da Empresa</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
 <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li class="active"><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['erro'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $_GET['erro']; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-cog"></i> Configurações da Empresa</h2>
                </div>
                
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="acao" value="atualizar">
                        
                        <div class="form-section">
                            <h3 class="section-title"><i class="fas fa-info-circle"></i> Informações Básicas</h3>
                            
                            <div class="form-group">
                                <label>Nome da Empresa</label>
                                <input type="text" name="nome_empresa" class="form-control" 
                                       value="<?php echo htmlspecialchars($empresa['nome_empresa'] ?? ''); ?>" 
                                       required placeholder="Digite o nome da empresa">
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>CNPJ</label>
                                    <input type="text" name="cnpj" class="form-control" 
                                           value="<?php echo htmlspecialchars($empresa['cnpj'] ?? ''); ?>" 
                                           placeholder="00.000.000/0000-00">
                                    <span class="help-text">Formato: 00.000.000/0000-00</span>
                                </div>
                                <div class="form-group">
                                    <label>Telefone</label>
                                    <input type="text" name="telefone" class="form-control" 
                                           value="<?php echo htmlspecialchars($empresa['telefone'] ?? ''); ?>" 
                                           placeholder="(11) 99999-9999">
                                    <span class="help-text">Formato: (11) 99999-9999</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="section-divider"></div>
                        
                        <div class="form-section">
                            <h3 class="section-title"><i class="fas fa-envelope"></i> Informações de Contato</h3>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?php echo htmlspecialchars($empresa['email'] ?? ''); ?>" 
                                           placeholder="contato@empresa.com">
                                </div>
                                <div class="form-group">
                                    <label>Site</label>
                                    <input type="url" name="site" class="form-control" 
                                           value="<?php echo htmlspecialchars($empresa['site'] ?? ''); ?>" 
                                           placeholder="https://www.empresa.com">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Endereço</label>
                                <textarea name="endereco" class="form-control" rows="3" 
                                          placeholder="Digite o endereço completo da empresa"><?php echo htmlspecialchars($empresa['endereco'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="section-divider"></div>
                        
                        <div class="form-section">
                            <h3 class="section-title"><i class="fas fa-palette"></i> Identidade Visual</h3>
                            
                            <div class="form-group">
                                <label>Logo da Empresa</label>
                                
                                <?php if (isset($empresa['logo_path']) && $empresa['logo_path'] && file_exists($empresa['logo_path'])): ?>
                                <div class="logo-section">
                                    <div class="logo-preview">
                                        <img src="<?php echo $empresa['logo_path']; ?>" alt="Logo da Empresa">
                                    </div>
                                    <p style="margin-top: 12px; color: #64748b; font-size: 14px;">
                                        Logo atual - <a href="<?php echo $empresa['logo_path']; ?>" target="_blank" style="color: #3b82f6; text-decoration: none;">Visualizar em tamanho real</a>
                                    </p>
                                </div>
                                <?php else: ?>
                                <div class="logo-section">
                                    <div class="empty-state">
                                        <i class="fas fa-building"></i>
                                        <h3>Nenhuma logo cadastrada</h3>
                                        <p>Faça upload de uma imagem para usar como logo da empresa</p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="file-upload">
                                    <label class="file-upload-label">
                                        <i class="fas fa-upload"></i>
                                        <span id="file-name">Clique para selecionar uma nova logo</span>
                                    </label>
                                    <input type="file" name="logo" accept="image/*" onchange="updateFileName(this)">
                                </div>
                                <span class="help-text">
                                    Formatos suportados: JPG, PNG, GIF. Tamanho máximo: 2MB. Dimensões recomendadas: 300x100px
                                </span>
                            </div>
                        </div>
                        
                        <div style="margin-top: 32px; text-align: right;">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Salvar Alterações
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });

        function updateFileName(input) {
            const fileName = input.files[0] ? input.files[0].name : 'Clique para selecionar uma nova logo';
            document.getElementById('file-name').textContent = fileName;
        }

        // Máscaras de formatação
        document.addEventListener('DOMContentLoaded', function() {
            // Máscara para CNPJ
            const cnpjInput = document.querySelector('input[name="cnpj"]');
            if (cnpjInput) {
                cnpjInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length <= 14) {
                        value = value.replace(/(\d{2})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1/$2');
                        value = value.replace(/(\d{4})(\d{1,2})$/, '$1-$2');
                        e.target.value = value;
                    }
                });
            }

            // Máscara para telefone
            const telefoneInput = document.querySelector('input[name="telefone"]');
            if (telefoneInput) {
                telefoneInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length <= 11) {
                        value = value.replace(/(\d{2})(\d)/, '($1) $2');
                        value = value.replace(/(\d{5})(\d)/, '$1-$2');
                        e.target.value = value;
                    }
                });
            }
        });

        // Debug no console
        console.log('Página de empresa carregada');
    </script>
</body>
</html>