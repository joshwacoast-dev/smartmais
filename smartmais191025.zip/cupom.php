<?php
include 'config.php';
verificarLogin();

// BUSCAR DADOS DA EMPRESA CORRETAMENTE
try {
    $stmt_empresa = $pdo->prepare("SELECT * FROM empresa LIMIT 1");
    $stmt_empresa->execute();
    $empresa = $stmt_empresa->fetch();
    
    if (!$empresa) {
        $empresa = [
            'nome_fantasia' => 'SmartMais Tecnologia',
            'razao_social' => 'SmartMais Tecnologia LTDA',
            'cnpj' => '12.345.678/0001-90',
            'endereco' => 'Rua Exemplo, 123',
            'telefone' => '(85) 3095-0064',
            'email' => 'contato@storessmart.com.br',
            'cidade' => 'Fortaleza',
            'estado' => 'CE',
            'cep' => '60000-000'
        ];
    }
} catch (PDOException $e) {
    $empresa = [
        'nome_fantasia' => 'SmartMais Tecnologia',
        'razao_social' => 'SmartMais Tecnologia LTDA', 
        'cnpj' => '12.345.678/0001-90',
        'endereco' => 'Rua Exemplo, 123',
        'telefone' => '(85) 3095-0064',
        'email' => 'contato@storessmart.com.br',
        'cidade' => 'Fortaleza',
        'estado' => 'CE',
        'cep' => '60000-000'
    ];
}

// PESQUISAR CUPOM - BUSCA COMPLETA PARA SEGUNDA VIA
$cupom_pesquisa = null;
$resultados_pesquisa = [];
$erro_pesquisa = '';

if (isset($_GET['pesquisar_cupom']) && !empty($_GET['numero_cupom'])) {
    try {
        $numero_cupom = $_GET['numero_cupom'];
        
        // Buscar a venda principal
        $stmt_venda = $pdo->prepare("
            SELECT v.*, c.nome as cliente_nome, c.cpf_cnpj, c.endereco, c.telefone,
                   u.nome as vendedor
            FROM vendas v
            LEFT JOIN clientes c ON v.cliente_id = c.id
            LEFT JOIN usuarios u ON v.usuario_id = u.id
            WHERE v.numero_cupom = ?
        ");
        $stmt_venda->execute([$numero_cupom]);
        $cupom_pesquisa = $stmt_venda->fetch();
        
        if ($cupom_pesquisa) {
            // Buscar os itens da venda
            $stmt_itens = $pdo->prepare("
                SELECT vi.*, p.nome as produto_nome, p.codigo as produto_codigo
                FROM venda_itens vi
                LEFT JOIN produtos p ON vi.produto_id = p.id
                WHERE vi.venda_id = ?
            ");
            $stmt_itens->execute([$cupom_pesquisa['id']]);
            $resultados_pesquisa = $stmt_itens->fetchAll();
        } else {
            $erro_pesquisa = "Cupom não encontrado. Verifique o número e tente novamente.";
        }
        
    } catch (PDOException $e) {
        $erro_pesquisa = "Erro ao pesquisar cupom: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cupom Fiscal - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Seção de Boas-vindas */
        .welcome-section {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            color: white;
            padding: 32px;
            border-radius: 12px;
            margin-bottom: 24px;
            position: relative;
            overflow: hidden;
        }
        
        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: url('https://storessmart.com.br/mascote2.png') no-repeat center;
            background-size: contain;
            opacity: 0.1;
        }
        
        .welcome-content h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .welcome-content p {
            opacity: 0.9;
            margin-bottom: 4px;
        }
        
        /* Seção de Informações da Empresa */
        .empresa-section {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 24px;
            border: 1px solid #e2e8f0;
        }
        
        .empresa-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f1f5f9;
        }
        
        .empresa-header h2 {
            color: #1e293b;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .empresa-header h2 i {
            color: #3b82f6;
        }
        
        .empresa-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .empresa-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #3b82f6;
        }
        
        .empresa-card h3 {
            color: #1e293b;
            margin-bottom: 15px;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .empresa-card h3 i {
            color: #3b82f6;
        }
        
        .empresa-info {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: #64748b;
            font-weight: 500;
        }
        
        .info-value {
            color: #1e293b;
            font-weight: 600;
        }
        
        /* Seção de Pesquisa */
        .search-section {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            margin-bottom: 24px;
            border: 1px solid #e2e8f0;
        }
        
        .search-form {
            display: flex;
            gap: 12px;
            align-items: end;
        }
        
        .search-form .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        
        .search-results {
            margin-top: 20px;
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
        
        .cupom-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .cupom-info {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #3b82f6;
        }
        
        /* Botões */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            text-decoration: none;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-outline {
            background: white;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        
        .btn-outline:hover {
            background: #f9fafb;
            border-color: #9ca3af;
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        /* Form Controls */
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .form-group label {
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-control {
            padding: 10px 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
        }
        
        /* Tabelas */
        .table-responsive {
            overflow-x: auto;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th,
        .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .data-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #1e293b;
            font-size: 14px;
        }
        
        .data-table tr:hover {
            background: #f8fafc;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Estilo para o Cupom Fiscal 80mm */
        .cupom-80mm {
            width: 80mm;
            min-height: 100mm;
            background: white;
            padding: 8px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.2;
            margin: 0 auto;
            border: 1px solid #ccc;
        }
        
        .cupom-header-80mm {
            text-align: center;
            border-bottom: 1px dashed #000;
            padding-bottom: 8px;
            margin-bottom: 8px;
        }
        
        .cupom-header-80mm .empresa-nome {
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 4px;
        }
        
        .cupom-header-80mm .empresa-cnpj {
            font-size: 10px;
            margin-bottom: 4px;
        }
        
        .cupom-header-80mm .empresa-endereco {
            font-size: 10px;
            margin-bottom: 4px;
        }
        
        .cupom-body-80mm {
            margin-bottom: 8px;
        }
        
        .cupom-item-80mm {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
            border-bottom: 1px dotted #ccc;
            padding-bottom: 4px;
        }
        
        .cupom-item-descricao {
            flex: 2;
        }
        
        .cupom-item-valores {
            flex: 1;
            text-align: right;
        }
        
        .cupom-totais-correto {
            border-top: 2px dashed #000;
            padding-top: 10px;
            margin-top: 10px;
        }
        
        .cupom-totais-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        
        .cupom-total-final {
            border-top: 2px solid #000;
            padding-top: 8px;
            margin-top: 8px;
            text-align: center;
            font-weight: bold;
            font-size: 14px;
        }
        
        .cupom-troco {
            border-top: 1px solid #000;
            padding-top: 8px;
            margin-top: 8px;
            font-weight: bold;
        }
        
        .cupom-footer-80mm {
            border-top: 1px dashed #000;
            padding-top: 8px;
            text-align: center;
            font-size: 10px;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-bold { font-weight: bold; }
        
        /* Overlay para impressão */
        .print-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .print-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            max-width: 90vw;
            max-height: 90vh;
            overflow: auto;
        }
        
        .print-actions {
            margin-top: 20px;
            text-align: center;
        }
        
        .no-print {
            display: block;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .cupom-80mm, .cupom-80mm * {
                visibility: visible;
            }
            .cupom-80mm {
                position: absolute;
                left: 0;
                top: 0;
                width: 80mm;
                box-shadow: none;
                margin: 0;
                padding: 8px;
            }
            .no-print {
                display: none !important;
            }
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .search-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .cupom-actions {
                flex-direction: column;
            }
            
            .cupom-actions .btn {
                width: 100%;
                text-align: center;
            }
            
            .empresa-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .welcome-section {
                padding: 24px;
            }
            
            .welcome-content h2 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-receipt"></i> Cupom Fiscal</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li class="active"><a href="cupom.php"><i class="fas fa-receipt"></i> Cupom Fiscal</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <!-- Welcome Section -->
            <div class="welcome-section">
                <div class="welcome-content">
                    <h2>Cupom Fiscal 📄</h2>
                    <p>Consulte e gere segunda via de cupons fiscais</p>
                    <p><strong>Data atual:</strong> <?php echo date('d/m/Y'); ?></p>
                </div>
            </div>

            <!-- Seção de Informações da Empresa -->
            <div class="empresa-section">
                <div class="empresa-header">
                    <h2><i class="fas fa-building"></i> Informações da Empresa</h2>
                    <a href="empresa.php" class="btn btn-outline">
                        <i class="fas fa-edit"></i> Editar Dados
                    </a>
                </div>
                
                <div class="empresa-grid">
                    <div class="empresa-card">
                        <h3><i class="fas fa-info-circle"></i> Dados Principais</h3>
                        <div class="empresa-info">
                            <div class="info-item">
                                <span class="info-label">Nome Fantasia:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['nome_fantasia']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Razão Social:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['razao_social']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">CNPJ:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['cnpj']); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="empresa-card">
                        <h3><i class="fas fa-map-marker-alt"></i> Endereço</h3>
                        <div class="empresa-info">
                            <div class="info-item">
                                <span class="info-label">Endereço:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['endereco']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Cidade/UF:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['cidade'] . '/' . $empresa['estado']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">CEP:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['cep']); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="empresa-card">
                        <h3><i class="fas fa-phone"></i> Contato</h3>
                        <div class="empresa-info">
                            <div class="info-item">
                                <span class="info-label">Telefone:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['telefone']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">E-mail:</span>
                                <span class="info-value"><?php echo htmlspecialchars($empresa['email']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Seção de Pesquisa de Cupons -->
            <div class="search-section">
                <h3 style="margin-bottom: 20px; color: #1e293b; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-search"></i> Pesquisar Cupom Fiscal - Segunda Via
                </h3>
                
                <form method="GET" class="search-form">
                    <div class="form-group">
                        <label for="numero_cupom">Número do Cupom</label>
                        <input type="text" name="numero_cupom" id="numero_cupom" class="form-control" 
                               placeholder="Digite o número do cupom fiscal para gerar segunda via" 
                               value="<?php echo $_GET['numero_cupom'] ?? ''; ?>" required>
                    </div>
                    <button type="submit" name="pesquisar_cupom" class="btn btn-primary" style="height: fit-content;">
                        <i class="fas fa-search"></i> Pesquisar Cupom
                    </button>
                </form>

                <?php if (!empty($erro_pesquisa)): ?>
                    <div style="background: #fee2e2; color: #dc2626; padding: 12px; border-radius: 6px; margin-top: 15px;">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $erro_pesquisa; ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['pesquisar_cupom']) && !empty($cupom_pesquisa)): ?>
                    <div class="search-results">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                            <h4 style="color: #059669; margin: 0;">
                                <i class="fas fa-check-circle"></i> Cupom Encontrado - Segunda Via
                            </h4>
                            <span class="badge badge-success">VÁLIDO</span>
                        </div>
                        
                        <div class="cupom-info">
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
                                <div>
                                    <strong>Número do Cupom:</strong><br>
                                    <?php echo $cupom_pesquisa['numero_cupom']; ?>
                                </div>
                                <div>
                                    <strong>Data da Venda:</strong><br>
                                    <?php echo date('d/m/Y H:i', strtotime($cupom_pesquisa['data_criacao'])); ?>
                                </div>
                                <div>
                                    <strong>Cliente:</strong><br>
                                    <?php echo $cupom_pesquisa['cliente_nome']; ?>
                                </div>
                                <div>
                                    <strong>Valor Total:</strong><br>
                                    R$ <?php echo number_format($cupom_pesquisa['total'], 2, ',', '.'); ?>
                                </div>
                                <div>
                                    <strong>Vendedor:</strong><br>
                                    <?php echo $cupom_pesquisa['vendedor']; ?>
                                </div>
                                <div>
                                    <strong>Forma de Pagamento:</strong><br>
                                    <?php echo ucfirst(str_replace('_', ' ', $cupom_pesquisa['forma_pagamento'])); ?>
                                </div>
                            </div>
                            
                            <!-- Detalhes dos Itens -->
                            <h5 style="margin-bottom: 15px; color: #1e293b;">Itens da Venda:</h5>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Produto</th>
                                            <th class="text-right">Quantidade</th>
                                            <th class="text-right">Preço Unit.</th>
                                            <th class="text-right">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($resultados_pesquisa as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['produto_nome']); ?></td>
                                                <td class="text-right"><?php echo $item['quantidade']; ?></td>
                                                <td class="text-right">R$ <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?></td>
                                                <td class="text-right">R$ <?php echo number_format($item['total'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr style="background: #f8fafc;">
                                            <td colspan="3" class="text-right"><strong>Total da Venda:</strong></td>
                                            <td class="text-right"><strong>R$ <?php echo number_format($cupom_pesquisa['total'], 2, ',', '.'); ?></strong></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            
                            <!-- BOTÕES DE AÇÃO PARA SEGUNDA VIA -->
                            <div class="cupom-actions">
                                <button class="btn btn-success" onclick="visualizarCupom()">
                                    <i class="fas fa-eye"></i> Visualizar Cupom
                                </button>
                                <button class="btn btn-warning" onclick="imprimirCupom()">
                                    <i class="fas fa-print"></i> Imprimir Segunda Via
                                </button>
                                <a href="cupom.php" class="btn btn-outline">
                                    <i class="fas fa-times"></i> Nova Pesquisa
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Overlay para visualização e impressão do cupom -->
                    <div class="print-overlay" id="printOverlay">
                        <div class="print-container">
                            <!-- Cupom Fiscal 80mm -->
                            <div class="cupom-80mm" id="cupom80mm">
                                <!-- CABEÇALHO COM DADOS REAIS DA EMPRESA -->
                                <div class="cupom-header-80mm">
                                    <div class="empresa-nome"><?php echo htmlspecialchars($empresa['nome_fantasia']); ?></div>
                                    <div class="empresa-cnpj">CNPJ: <?php echo htmlspecialchars($empresa['cnpj']); ?></div>
                                    <div class="empresa-endereco">
                                        <?php 
                                        $endereco_completo = $empresa['endereco'];
                                        if (!empty($empresa['cidade'])) {
                                            $endereco_completo .= ' - ' . $empresa['cidade'];
                                            if (!empty($empresa['estado'])) {
                                                $endereco_completo .= '/' . $empresa['estado'];
                                            }
                                        }
                                        echo htmlspecialchars($endereco_completo);
                                        ?>
                                    </div>
                                    <div class="empresa-telefone">Tel: <?php echo htmlspecialchars($empresa['telefone']); ?></div>
                                </div>
                                
                                <div class="cupom-body-80mm">
                                    <div class="text-center text-bold">CUPOM NÃO FISCAL - SEGUNDA VIA</div>
                                    <div style="border-bottom: 1px dashed #000; margin: 8px 0; padding-bottom: 8px;">
                                        <div>Nº: <?php echo $cupom_pesquisa['numero_cupom']; ?></div>
                                        <div>Data: <?php echo date('d/m/Y H:i', strtotime($cupom_pesquisa['data_criacao'])); ?></div>
                                        <div>Cliente: <?php echo htmlspecialchars($cupom_pesquisa['cliente_nome']); ?></div>
                                        <?php if (!empty($cupom_pesquisa['cpf_cnpj'])): ?>
                                            <div>CPF/CNPJ: <?php echo htmlspecialchars($cupom_pesquisa['cpf_cnpj']); ?></div>
                                        <?php endif; ?>
                                        <div>Vendedor: <?php echo htmlspecialchars($cupom_pesquisa['vendedor']); ?></div>
                                    </div>
                                    
                                    <div style="margin-bottom: 8px;">
                                        <div class="text-bold" style="border-bottom: 1px solid #000; padding-bottom: 4px; margin-bottom: 4px;">
                                            ITENS DA VENDA
                                        </div>
                                        <?php 
                                        $subtotal_calculado = 0;
                                        foreach ($resultados_pesquisa as $item): 
                                            $subtotal_calculado += $item['total'];
                                        ?>
                                            <div class="cupom-item-80mm">
                                                <div class="cupom-item-descricao">
                                                    <?php echo htmlspecialchars($item['produto_nome']); ?>
                                                </div>
                                                <div class="cupom-item-valores">
                                                    <?php echo $item['quantidade']; ?> x R$ <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?>
                                                </div>
                                            </div>
                                            <div class="text-right" style="margin-bottom: 4px;">
                                                R$ <?php echo number_format($item['total'], 2, ',', '.'); ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <!-- TOTAIS CORRETOS -->
                                    <div class="cupom-totais-correto">
                                        <div class="cupom-totais-item">
                                            <div>Subtotal:</div>
                                            <div>R$ <?php echo number_format($subtotal_calculado, 2, ',', '.'); ?></div>
                                        </div>
                                        <?php if (isset($cupom_pesquisa['desconto']) && $cupom_pesquisa['desconto'] > 0): ?>
                                        <div class="cupom-totais-item">
                                            <div>Desconto:</div>
                                            <div>- R$ <?php echo number_format($cupom_pesquisa['desconto'], 2, ',', '.'); ?></div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if (isset($cupom_pesquisa['acrescimo']) && $cupom_pesquisa['acrescimo'] > 0): ?>
                                        <div class="cupom-totais-item">
                                            <div>Acréscimo:</div>
                                            <div>+ R$ <?php echo number_format($cupom_pesquisa['acrescimo'], 2, ',', '.'); ?></div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="cupom-total-final">
                                    TOTAL: R$ <?php echo number_format($cupom_pesquisa['total'], 2, ',', '.'); ?>
                                </div>
                                
                                <div class="cupom-footer-80mm">
                                    <div style="margin-bottom: 4px;">
                                        <strong>FORMA DE PAGAMENTO:</strong><br>
                                        <?php echo strtoupper(str_replace('_', ' ', $cupom_pesquisa['forma_pagamento'])); ?>
                                    </div>
                                    <?php if (isset($cupom_pesquisa['troco']) && $cupom_pesquisa['troco'] > 0): ?>
                                    <div class="cupom-troco">
                                        TROCO: R$ <?php echo number_format($cupom_pesquisa['troco'], 2, ',', '.'); ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (!empty($cupom_pesquisa['observacoes'])): ?>
                                    <div style="margin-bottom: 4px;">
                                        <strong>OBSERVAÇÕES:</strong><br>
                                        <?php echo htmlspecialchars($cupom_pesquisa['observacoes']); ?>
                                    </div>
                                    <?php endif; ?>
                                    <div style="border-top: 1px dashed #000; padding-top: 8px; margin-top: 8px;">
                                        *** SEGUNDA VIA - CUPOM NÃO FISCAL ***<br>
                                        *** OBRIGADO PELA PREFERÊNCIA ***<br>
                                        Volte Sempre!
                                    </div>
                                    <div style="margin-top: 8px; font-size: 9px;">
                                        Emitido em: <?php echo date('d/m/Y H:i:s'); ?><br>
                                        Sistema: SmartMais
                                    </div>
                                </div>
                            </div>
                            
                            <div class="print-actions no-print">
                                <button class="btn btn-success" onclick="imprimirCupomDireto()">
                                    <i class="fas fa-print"></i> Imprimir Segunda Via
                                </button>
                                <button class="btn btn-outline" onclick="fecharVisualizacao()">
                                    <i class="fas fa-times"></i> Fechar
                                </button>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif (isset($_GET['pesquisar_cupom'])): ?>
                    <div class="search-results">
                        <div style="text-align: center; padding: 20px; color: #64748b;">
                            <i class="fas fa-search" style="font-size: 48px; margin-bottom: 15px; color: #cbd5e1;"></i>
                            <h4 style="color: #64748b; margin-bottom: 10px;">Cupom não encontrado</h4>
                            <p>Verifique se o número do cupom está correto e tente novamente.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 99258.9475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        // Fechar menu ao clicar fora (em telas pequenas)
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(event.target) && 
                !mobileMenuBtn.contains(event.target) &&
                sidebar.classList.contains('open')) {
                sidebar.classList.remove('open');
            }
        });

        // Funções para o cupom fiscal
        function visualizarCupom() {
            document.getElementById('printOverlay').style.display = 'flex';
        }
        
        function fecharVisualizacao() {
            document.getElementById('printOverlay').style.display = 'none';
        }
        
        function imprimirCupom() {
            visualizarCupom();
        }
        
        function imprimirCupomDireto() {
            const cupomElement = document.getElementById('cupom80mm');
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Cupom Fiscal - <?php echo $empresa['nome_fantasia']; ?></title>
                    <style>
                        body {
                            margin: 0;
                            padding: 0;
                            font-family: 'Courier New', monospace;
                            font-size: 12px;
                            line-height: 1.2;
                        }
                        .cupom-80mm {
                            width: 80mm;
                            min-height: 100mm;
                            background: white;
                            padding: 8px;
                        }
                        .cupom-header-80mm {
                            text-align: center;
                            border-bottom: 1px dashed #000;
                            padding-bottom: 8px;
                            margin-bottom: 8px;
                        }
                        .cupom-header-80mm .empresa-nome {
                            font-weight: bold;
                            font-size: 14px;
                            margin-bottom: 4px;
                        }
                        .cupom-header-80mm .empresa-cnpj {
                            font-size: 10px;
                            margin-bottom: 4px;
                        }
                        .cupom-header-80mm .empresa-endereco {
                            font-size: 10px;
                            margin-bottom: 4px;
                        }
                        .cupom-body-80mm {
                            margin-bottom: 8px;
                        }
                        .cupom-item-80mm {
                            display: flex;
                            justify-content: space-between;
                            margin-bottom: 4px;
                            border-bottom: 1px dotted #ccc;
                            padding-bottom: 4px;
                        }
                        .cupom-item-descricao { flex: 2; }
                        .cupom-item-valores { flex: 1; text-align: right; }
                        .cupom-total-80mm {
                            border-top: 2px solid #000;
                            padding-top: 8px;
                            margin-top: 8px;
                            text-align: center;
                            font-weight: bold;
                            font-size: 14px;
                        }
                        .cupom-footer-80mm {
                            border-top: 1px dashed #000;
                            padding-top: 8px;
                            text-align: center;
                            font-size: 10px;
                        }
                        .text-center { text-align: center; }
                        .text-right { text-align: right; }
                        .text-bold { font-weight: bold; }
                        .cupom-totais-correto {
                            border-top: 2px dashed #000;
                            padding-top: 10px;
                            margin-top: 10px;
                        }
                        .cupom-totais-item {
                            display: flex;
                            justify-content: space-between;
                            margin-bottom: 4px;
                        }
                        .cupom-total-final {
                            border-top: 2px solid #000;
                            padding-top: 8px;
                            margin-top: 8px;
                            text-align: center;
                            font-weight: bold;
                            font-size: 14px;
                        }
                        .cupom-troco {
                            border-top: 1px solid #000;
                            padding-top: 8px;
                            margin-top: 8px;
                            font-weight: bold;
                        }
                        @media print {
                            body { margin: 0; padding: 0; }
                            .cupom-80mm { 
                                width: 80mm !important; 
                                margin: 0 !important;
                                padding: 8px !important;
                                box-shadow: none !important;
                            }
                        }
                    </style>
                </head>
                <body>
                    ${cupomElement.outerHTML}
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() {
                                window.close();
                            }, 1000);
                        };
                    <\/script>
                </body>
                </html>
            `);
            
            printWindow.document.close();
        }

        // Fechar overlay ao clicar fora
        window.onclick = function(event) {
            const overlay = document.getElementById('printOverlay');
            if (event.target === overlay) {
                fecharVisualizacao();
            }
        }

        // Focar no campo de pesquisa ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            const numeroCupomInput = document.getElementById('numero_cupom');
            if (numeroCupomInput) {
                numeroCupomInput.focus();
            }
        });
    </script>
</body>
</html>