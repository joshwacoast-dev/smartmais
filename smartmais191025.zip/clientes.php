<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config.php';
verificarLogin();

if (!temPermissao('clientes_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? 0;

// Processar formulário
if ($_POST) {
    $dados = $_POST;
    
    // Remover máscaras antes de salvar
    $dados['cpf_cnpj'] = preg_replace('/[^0-9]/', '', $dados['cpf_cnpj']);
    $dados['telefone'] = preg_replace('/[^0-9]/', '', $dados['telefone']);
    $dados['celular'] = preg_replace('/[^0-9]/', '', $dados['celular']);
    $dados['cep'] = preg_replace('/[^0-9]/', '', $dados['cep']);
    
    if ($dados['acao'] == 'adicionar' && temPermissao('clientes_editar')) {
        $stmt = $pdo->prepare("INSERT INTO clientes (nome, tipo, cpf_cnpj, rg_ie, email, telefone, celular, endereco, numero, complemento, bairro, cidade, estado, cep, observacoes, estado_id, cidade_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $dados['nome'], $dados['tipo'], $dados['cpf_cnpj'], $dados['rg_ie'],
            $dados['email'], $dados['telefone'], $dados['celular'], $dados['endereco'],
            $dados['numero'], $dados['complemento'], $dados['bairro'], $dados['cidade'],
            $dados['estado'], $dados['cep'], $dados['observacoes'], $dados['estado_id'], $dados['cidade_id']
        ]);
        
        registrarLog('Cadastro de cliente', 'Cliente: ' . $dados['nome']);
        header("Location: clientes.php?sucesso=Cliente cadastrado com sucesso!");
        exit();
    }
    elseif ($dados['acao'] == 'editar' && temPermissao('clientes_editar')) {
        $stmt = $pdo->prepare("UPDATE clientes SET nome=?, tipo=?, cpf_cnpj=?, rg_ie=?, email=?, telefone=?, celular=?, endereco=?, numero=?, complemento=?, bairro=?, cidade=?, estado=?, cep=?, observacoes=?, estado_id=?, cidade_id=?, ativo=? WHERE id=?");
        $stmt->execute([
            $dados['nome'], $dados['tipo'], $dados['cpf_cnpj'], $dados['rg_ie'],
            $dados['email'], $dados['telefone'], $dados['celular'], $dados['endereco'],
            $dados['numero'], $dados['complemento'], $dados['bairro'], $dados['cidade'],
            $dados['estado'], $dados['cep'], $dados['observacoes'], $dados['estado_id'], $dados['cidade_id'],
            $dados['ativo'], $dados['id']
        ]);
        
        registrarLog('Edição de cliente', 'Cliente ID: ' . $dados['id']);
        header("Location: clientes.php?sucesso=Cliente atualizado com sucesso!");
        exit();
    }
    elseif ($dados['acao'] == 'excluir' && temPermissao('clientes_excluir')) {
        $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
        $stmt->execute([$dados['id']]);
        
        registrarLog('Exclusão de cliente', 'Cliente ID: ' . $dados['id']);
        header("Location: clientes.php?sucesso=Cliente excluído com sucesso!");
        exit();
    }
    elseif ($dados['acao'] == 'reativar' && temPermissao('clientes_editar')) {
        $stmt = $pdo->prepare("UPDATE clientes SET ativo = 1 WHERE id = ?");
        $stmt->execute([$dados['id']]);
        
        registrarLog('Reativação de cliente', 'Cliente ID: ' . $dados['id']);
        header("Location: clientes.php?sucesso=Cliente reativado com sucesso!");
        exit();
    }
}

// Buscar cliente específico para edição
$cliente_edicao = null;
if ($id && $acao == 'editar') {
    $stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
    $stmt->execute([$id]);
    $cliente_edicao = $stmt->fetch();
}

// Buscar todos os clientes
$filtro = $_GET['filtro'] ?? '';
$mostrarInativos = $_GET['inativos'] ?? '0';

// Construir a cláusula WHERE dinamicamente
$where = "1=1";

if (!$mostrarInativos) {
    $where .= " AND ativo = 1";
}

if ($filtro) {
    $where .= " AND (nome LIKE ? OR email LIKE ? OR telefone LIKE ?)";
}

$sql = "SELECT * FROM clientes WHERE $where ORDER BY ativo DESC, nome";
$stmt = $pdo->prepare($sql);

if ($filtro) {
    $termo = "%$filtro%";
    $stmt->execute([$termo, $termo, $termo]);
} else {
    $stmt->execute();
}

$clientes = $stmt->fetchAll();

// Contar clientes ativos e inativos para estatísticas
$stmt = $pdo->prepare("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativos,
    SUM(CASE WHEN ativo = 0 THEN 1 ELSE 0 END) as inativos
    FROM clientes");
$stmt->execute();
$estatisticas = $stmt->fetch();

// Buscar estados do banco de dados
$estados = $pdo->query("SELECT * FROM estados WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Buscar cidades se tiver um cliente em edição
$cidades = [];
if (isset($cliente_edicao['estado_id']) && $cliente_edicao['estado_id']) {
    $stmt = $pdo->prepare("SELECT * FROM cidades WHERE estado_id = ? AND ativo = 1 ORDER BY nome");
    $stmt->execute([$cliente_edicao['estado_id']]);
    $cidades = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1400px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 1px 3px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-info {
            background: #06b6d4;
            color: white;
            box-shadow: 0 1px 3px rgba(6, 182, 212, 0.3);
        }
        
        .btn-info:hover {
            background: #0891b2;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
            box-shadow: 0 1px 3px rgba(107, 114, 128, 0.3);
        }
        
        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-1px);
        }
        
        .btn-sm {
            padding: 8px 12px;
            font-size: 13px;
        }
        
        /* Formulários */
        .filters {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-info { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .badge-primary { 
            background: #e0e7ff; 
            color: #3730a3; 
            border: 1px solid #c7d2fe;
        }
        
        .badge-secondary { 
            background: #f3f4f6; 
            color: #374151; 
            border: 1px solid #e5e7eb;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        /* Modal de Confirmação */
        .confirm-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1100;
            backdrop-filter: blur(4px);
        }
        
        .confirm-modal-content {
            background: white;
            margin: 200px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            animation: slideDown 0.3s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .confirm-modal-header {
            padding: 24px;
            border-bottom: 1px solid #e5e7eb;
            background: #fef2f2;
            border-radius: 12px 12px 0 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .confirm-modal-header i {
            color: #ef4444;
            font-size: 24px;
        }
        
        .confirm-modal-header h3 {
            font-size: 18px;
            font-weight: 600;
            color: #dc2626;
        }
        
        .confirm-modal-body {
            padding: 24px;
            text-align: center;
        }
        
        .confirm-modal-body p {
            color: #6b7280;
            margin-bottom: 24px;
            line-height: 1.6;
        }
        
        .confirm-modal-footer {
            padding: 16px 24px 24px;
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }
        
        .btn-cancel {
            background: #6b7280;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .btn-cancel:hover {
            background: #4b5563;
        }
        
        .btn-confirm-delete {
            background: #ef4444;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-confirm-delete:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }
        
        /* Formulário */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 24px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .cliente-name {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 4px;
        }
        
        .cliente-contact {
            font-size: 14px;
            color: #6b7280;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 4px;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 2px solid #d1d5db;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            font-weight: 500;
            color: #374151;
            cursor: pointer;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Estatísticas */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            text-align: center;
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 4px;
        }
        
        .stat-label {
            font-size: 14px;
            color: #6b7280;
        }
        
        .stat-total .stat-number { color: #3b82f6; }
        .stat-ativos .stat-number { color: #10b981; }
        .stat-inativos .stat-number { color: #ef4444; }
        
        /* Cliente inativo */
        .cliente-inativo {
            background-color: #fef2f2;
            opacity: 0.8;
        }
        
        .cliente-inativo:hover {
            background-color: #fef2f2;
            opacity: 1;
        }
        
        /* Loading para cidades */
        .loading-cidades {
            color: #6b7280;
            font-style: italic;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
            
            .confirm-modal-footer {
                flex-direction: column;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-header {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-users"></i> Clientes</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li class="active"><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Estatísticas -->
            <div class="stats-container">
                <div class="stat-card stat-total">
                    <div class="stat-number"><?php echo $estatisticas['total']; ?></div>
                    <div class="stat-label">Total de Clientes</div>
                </div>
                <div class="stat-card stat-ativos">
                    <div class="stat-number"><?php echo $estatisticas['ativos']; ?></div>
                    <div class="stat-label">Clientes Ativos</div>
                </div>
                <div class="stat-card stat-inativos">
                    <div class="stat-number"><?php echo $estatisticas['inativos']; ?></div>
                    <div class="stat-label">Clientes Inativos</div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-list"></i> Lista de Clientes</h2>
                    <?php if (temPermissao('clientes_editar')): ?>
                    <button onclick="abrirModal()" class="btn btn-success">
                        <i class="fas fa-plus"></i> Novo Cliente
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <div class="filters">
                        <input type="text" id="searchInput" class="form-control" placeholder="Buscar clientes por nome, email ou telefone..." 
                               value="<?php echo htmlspecialchars($filtro); ?>" style="width: 400px;">
                        <button onclick="buscarClientes()" class="btn btn-primary">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                        
                        <!-- Botão para mostrar/ocultar inativos -->
                        <?php if ($mostrarInativos): ?>
                            <a href="clientes.php?filtro=<?php echo urlencode($filtro); ?>&inativos=0" class="btn btn-secondary">
                                <i class="fas fa-eye-slash"></i> Ocultar Inativos
                            </a>
                        <?php else: ?>
                            <a href="clientes.php?filtro=<?php echo urlencode($filtro); ?>&inativos=1" class="btn btn-secondary">
                                <i class="fas fa-eye"></i> Mostrar Inativos
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>Cliente</th>
                                    <th>Documento</th>
                                    <th>Contato</th>
                                    <th>Localização</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($clientes as $cliente_item): ?>
                                <tr class="<?php echo $cliente_item['ativo'] == 0 ? 'cliente-inativo' : ''; ?>">
                                    <td>
                                        <?php if ($cliente_item['ativo'] == 1): ?>
                                            <span class="badge badge-success">
                                                <i class="fas fa-check-circle"></i> Ativo
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">
                                                <i class="fas fa-times-circle"></i> Inativo
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="cliente-name">
                                            <?php echo htmlspecialchars($cliente_item['nome']); ?>
                                        </div>
                                        <span class="badge <?php echo $cliente_item['tipo'] == 'Física' ? 'badge-primary' : 'badge-warning'; ?>">
                                            <i class="fas fa-<?php echo $cliente_item['tipo'] == 'Física' ? 'user' : 'building'; ?>"></i>
                                            <?php echo $cliente_item['tipo']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div style="font-weight: 500; color: #374151;">
                                            <?php 
                                            // Aplicar máscara para exibição
                                            if ($cliente_item['tipo'] == 'Física' && strlen($cliente_item['cpf_cnpj']) == 11) {
                                                echo preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $cliente_item['cpf_cnpj']);
                                            } elseif ($cliente_item['tipo'] == 'Jurídica' && strlen($cliente_item['cpf_cnpj']) == 14) {
                                                echo preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cliente_item['cpf_cnpj']);
                                            } else {
                                                echo htmlspecialchars($cliente_item['cpf_cnpj']);
                                            }
                                            ?>
                                        </div>
                                        <?php if ($cliente_item['rg_ie']): ?>
                                        <div style="font-size: 13px; color: #6b7280;">
                                            <?php echo $cliente_item['rg_ie']; ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($cliente_item['email']): ?>
                                        <div class="cliente-contact">
                                            <i class="fas fa-envelope"></i>
                                            <?php echo htmlspecialchars($cliente_item['email']); ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($cliente_item['telefone']): ?>
                                        <div class="cliente-contact">
                                            <i class="fas fa-phone"></i>
                                            <?php 
                                            // Aplicar máscara para telefone
                                            $telefone = $cliente_item['telefone'];
                                            if (strlen($telefone) == 10) {
                                                echo preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2-$3', $telefone);
                                            } elseif (strlen($telefone) == 11) {
                                                echo preg_replace('/(\d{2})(\d{5})(\d{4})/', '($1) $2-$3', $telefone);
                                            } else {
                                                echo htmlspecialchars($telefone);
                                            }
                                            ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($cliente_item['celular']): ?>
                                        <div class="cliente-contact">
                                            <i class="fas fa-mobile-alt"></i>
                                            <?php 
                                            // Aplicar máscara para celular
                                            $celular = $cliente_item['celular'];
                                            if (strlen($celular) == 11) {
                                                echo preg_replace('/(\d{2})(\d{5})(\d{4})/', '($1) $2-$3', $celular);
                                            } else {
                                                echo htmlspecialchars($celular);
                                            }
                                            ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($cliente_item['cidade']): ?>
                                        <div style="font-weight: 500; color: #374151;">
                                            <?php echo htmlspecialchars($cliente_item['cidade']); ?>/<?php echo htmlspecialchars($cliente_item['estado']); ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($cliente_item['bairro']): ?>
                                        <div style="font-size: 13px; color: #6b7280;">
                                            <?php echo $cliente_item['bairro']; ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($cliente_item['cep']): ?>
                                        <div style="font-size: 13px; color: #6b7280;">
                                            <?php 
                                            // Aplicar máscara para CEP
                                            $cep = $cliente_item['cep'];
                                            if (strlen($cep) == 8) {
                                                echo preg_replace('/(\d{5})(\d{3})/', '$1-$2', $cep);
                                            } else {
                                                echo htmlspecialchars($cep);
                                            }
                                            ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <?php if (temPermissao('clientes_editar')): ?>
                                            <button onclick="editarCliente(<?php echo $cliente_item['id']; ?>)" class="btn btn-warning btn-sm" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if (temPermissao('clientes_excluir')): ?>
                                            <button onclick="confirmarExclusao(<?php echo $cliente_item['id']; ?>, '<?php echo htmlspecialchars($cliente_item['nome']); ?>')" class="btn btn-danger btn-sm" title="Excluir">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($cliente_item['ativo'] == 0 && temPermissao('clientes_editar')): ?>
                                            <button onclick="reativarCliente(<?php echo $cliente_item['id']; ?>)" class="btn btn-success btn-sm" title="Reativar">
                                                <i class="fas fa-undo"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if (temPermissao('orcamentos_editar') && $cliente_item['ativo'] == 1): ?>
                                            <a href="orcamentos.php?acao=novo&cliente_id=<?php echo $cliente_item['id']; ?>" class="btn btn-info btn-sm" title="Novo Orçamento">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                            </a>
                                            <?php endif; ?>
                                            
                                            <?php if (temPermissao('os_editar') && $cliente_item['ativo'] == 1): ?>
                                            <a href="ordens_servico.php?acao=nova&cliente_id=<?php echo $cliente_item['id']; ?>" class="btn btn-success btn-sm" title="Nova OS">
                                                <i class="fas fa-tools"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($clientes)): ?>
                                <tr>
                                    <td colspan="6">
                                        <div class="empty-state">
                                            <i class="fas fa-users"></i>
                                            <h3>Nenhum cliente encontrado</h3>
                                            <p><?php echo $mostrarInativos ? 'Não há clientes cadastrados' : 'Não há clientes ativos cadastrados'; ?></p>
                                            <?php if (temPermissao('clientes_editar')): ?>
                                            <button onclick="abrirModal()" class="btn btn-success" style="margin-top: 16px;">
                                                <i class="fas fa-plus"></i> Cadastrar Cliente
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    
    <!-- Modal Cliente -->
    <div id="modalCliente" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus-circle"></i> <span id="modalTitulo">Novo Cliente</span></h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formCliente" method="POST">
                    <input type="hidden" name="acao" id="formAcao" value="adicionar">
                    <input type="hidden" name="id" id="clienteId">
                    <input type="hidden" name="estado_id" id="estado_id">
                    <input type="hidden" name="cidade_id" id="cidade_id">
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-user"></i> Informações Pessoais</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Nome Completo / Razão Social *</label>
                                <input type="text" name="nome" id="nome" class="form-control" required 
                                       placeholder="Nome do cliente ou razão social">
                            </div>
                            
                            <div class="form-group">
                                <label>Tipo *</label>
                                <select name="tipo" id="tipo" class="form-control" required onchange="toggleDocumentos()">
                                    <option value="Física">Pessoa Física</option>
                                    <option value="Jurídica">Pessoa Jurídica</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label id="labelDocumento">CPF *</label>
                                <input type="text" name="cpf_cnpj" id="cpf_cnpj" class="form-control" required 
                                       placeholder="000.000.000-00">
                            </div>
                            
                            <div class="form-group">
                                <label id="labelDocumento2">RG</label>
                                <input type="text" name="rg_ie" id="rg_ie" class="form-control" 
                                       placeholder="Número do documento">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-address-book"></i> Contato</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" id="email" class="form-control" 
                                       placeholder="email@exemplo.com">
                            </div>
                            
                            <div class="form-group">
                                <label>Telefone</label>
                                <input type="text" name="telefone" id="telefone" class="form-control" 
                                       placeholder="(11) 9999-9999">
                            </div>
                            
                            <div class="form-group">
                                <label>Celular</label>
                                <input type="text" name="celular" id="celular" class="form-control" 
                                       placeholder="(11) 99999-9999">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-map-marker-alt"></i> Endereço</h3>
                        
                        <div class="form-group">
                            <label>Endereço</label>
                            <input type="text" name="endereco" id="endereco" class="form-control" 
                                   placeholder="Rua, Avenida, etc.">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Número</label>
                                <input type="text" name="numero" id="numero" class="form-control" 
                                       placeholder="123">
                            </div>
                            
                            <div class="form-group">
                                <label>Complemento</label>
                                <input type="text" name="complemento" id="complemento" class="form-control" 
                                       placeholder="Apto, Sala, etc.">
                            </div>
                            
                            <div class="form-group">
                                <label>Bairro</label>
                                <input type="text" name="bairro" id="bairro" class="form-control" 
                                       placeholder="Bairro">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Estado *</label>
                                <select name="estado_select" id="estado_select" class="form-control" required onchange="carregarCidades(this.value)">
                                    <option value="">Selecione um estado</option>
                                    <?php foreach ($estados as $estado): ?>
                                        <option value="<?php echo $estado['id']; ?>" 
                                            <?php echo (isset($cliente_edicao['estado_id']) && $cliente_edicao['estado_id'] == $estado['id']) ? 'selected' : ''; ?>>
                                            <?php echo $estado['nome']; ?> (<?php echo $estado['uf']; ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Cidade *</label>
                                <select name="cidade" id="cidade" class="form-control" required>
                                    <option value="">Selecione um estado primeiro</option>
                                    <?php foreach ($cidades as $cidade): ?>
                                        <option value="<?php echo $cidade['nome']; ?>" 
                                            data-cidade-id="<?php echo $cidade['id']; ?>"
                                            <?php echo (isset($cliente_edicao['cidade_id']) && $cliente_edicao['cidade_id'] == $cidade['id']) ? 'selected' : ''; ?>>
                                            <?php echo $cidade['nome']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>CEP</label>
                                <input type="text" name="cep" id="cep" class="form-control" 
                                       placeholder="00000-000">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-sticky-note"></i> Observações</h3>
                        
                        <div class="form-group">
                            <textarea name="observacoes" id="observacoes" class="form-control" rows="3" 
                                      placeholder="Observações adicionais sobre o cliente"></textarea>
                        </div>
                    </div>

                    <div class="form-section" id="ativoField" style="display: none;">
                        <h3 class="section-title"><i class="fas fa-toggle-on"></i> Status</h3>
                        
                        <div class="checkbox-group">
                            <input type="checkbox" name="ativo" id="ativo" value="1" checked>
                            <label for="ativo">Cliente ativo</label>
                        </div>
                    </div>

                    <div style="margin-top: 32px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #6b7280; font-size: 14px;">* Campos obrigatórios</span>
                            <div>
                                <button type="button" onclick="fecharModal()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                                    <i class="fas fa-times"></i> Cancelar
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Salvar Cliente
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Modal de Confirmação de Exclusão -->
    <div id="confirmModal" class="confirm-modal">
        <div class="confirm-modal-content">
            <div class="confirm-modal-header">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Confirmar Exclusão</h3>
            </div>
            <div class="confirm-modal-body">
                <p id="confirmMessage">Tem certeza que deseja excluir este cliente?</p>
                <p style="color: #ef4444; font-weight: 500; margin-top: 10px;">
                    <i class="fas fa-info-circle"></i> Esta ação não pode ser desfeita. Todos os dados do cliente serão permanentemente removidos do sistema.
                </p>
            </div>
            <div class="confirm-modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharConfirmModal()">
                    <i class="fas fa-times"></i> Cancelar
                </button>
                <button type="button" class="btn-confirm-delete" onclick="confirmarExclusaoFinal()">
                    <i class="fas fa-trash-alt"></i> Sim, Excluir Cliente
                </button>
            </div>
        </div>
    </div>
    
    <script>
        // Variáveis globais
        let clienteIdParaExcluir = null;
        
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        // Aplicar máscaras
        $(document).ready(function() {
            // Máscara para CPF/CNPJ
            $('#cpf_cnpj').keyup(function() {
                const tipo = $('#tipo').val();
                if (tipo === 'Jurídica') {
                    $(this).mask('00.000.000/0000-00');
                } else {
                    $(this).mask('000.000.000-00');
                }
            });
            
            // Máscara para telefone e celular
            $('#telefone').mask('(00) 0000-0000');
            $('#celular').mask('(00) 00000-0000');
            
            // Máscara para CEP
            $('#cep').mask('00000-000');
            
            // Inicializar máscaras
            toggleDocumentos();
        });
        
        // Função para carregar cidades via AJAX
        function carregarCidades(estadoId) {
            const cidadeSelect = document.getElementById('cidade');
            const estadoSelect = document.getElementById('estado_select');
            
            // Atualizar estado_id hidden field
            document.getElementById('estado_id').value = estadoId;
            
            if (!estadoId) {
                cidadeSelect.innerHTML = '<option value="">Selecione um estado primeiro</option>';
                cidadeSelect.disabled = true;
                return;
            }
            
            // Mostrar loading
            cidadeSelect.innerHTML = '<option value="" class="loading-cidades">Carregando cidades...</option>';
            cidadeSelect.disabled = true;
            
            fetch(`ajax_cidades.php?estado_id=${estadoId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na requisição');
                    }
                    return response.json();
                })
                .then(cidades => {
                    let options = '<option value="">Selecione uma cidade</option>';
                    
                    if (cidades.error) {
                        options = `<option value="">Erro: ${cidades.error}</option>`;
                    } else {
                        cidades.forEach(cidade => {
                            options += `<option value="${cidade.nome}" data-cidade-id="${cidade.id}">${cidade.nome}</option>`;
                        });
                    }
                    
                    cidadeSelect.innerHTML = options;
                    cidadeSelect.disabled = false;
                })
                .catch(error => {
                    console.error('Erro ao carregar cidades:', error);
                    cidadeSelect.innerHTML = '<option value="">Erro ao carregar cidades</option>';
                    cidadeSelect.disabled = false;
                });
        }
        
        // Atualizar cidade_id quando uma cidade for selecionada
        document.getElementById('cidade').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const cidadeId = selectedOption.getAttribute('data-cidade-id');
            document.getElementById('cidade_id').value = cidadeId || '';
        });
        
        function abrirModal() {
            document.getElementById('modalCliente').style.display = 'block';
            document.getElementById('formAcao').value = 'adicionar';
            document.getElementById('modalTitulo').textContent = 'Novo Cliente';
            document.getElementById('ativoField').style.display = 'none';
            document.getElementById('formCliente').reset();
            toggleDocumentos();
            
            // Resetar selects
            document.getElementById('estado_select').value = '';
            document.getElementById('cidade').innerHTML = '<option value="">Selecione um estado primeiro</option>';
            document.getElementById('cidade').disabled = true;
            document.getElementById('estado_id').value = '';
            document.getElementById('cidade_id').value = '';
        }
        
        function fecharModal() {
            document.getElementById('modalCliente').style.display = 'none';
        }
        
        function toggleDocumentos() {
            const tipo = document.getElementById('tipo').value;
            if (tipo === 'Jurídica') {
                document.getElementById('labelDocumento').textContent = 'CNPJ *';
                document.getElementById('labelDocumento2').textContent = 'Inscrição Estadual';
                document.getElementById('cpf_cnpj').placeholder = '00.000.000/0000-00';
                $('#cpf_cnpj').mask('00.000.000/0000-00');
            } else {
                document.getElementById('labelDocumento').textContent = 'CPF *';
                document.getElementById('labelDocumento2').textContent = 'RG';
                document.getElementById('cpf_cnpj').placeholder = '000.000.000-00';
                $('#cpf_cnpj').mask('000.000.000-00');
            }
        }
        
        function buscarClientes() {
            const termo = document.getElementById('searchInput').value;
            const mostrarInativos = <?php echo $mostrarInativos ? '1' : '0'; ?>;
            window.location.href = 'clientes.php?filtro=' + encodeURIComponent(termo) + '&inativos=' + mostrarInativos;
        }
        
        function editarCliente(id) {
            // Mostrar loading
            const modal = document.getElementById('modalCliente');
            modal.style.display = 'block';
            document.getElementById('modalTitulo').textContent = 'Carregando...';
            
            fetch('ajax_clientes.php?acao=buscar&id=' + id)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Erro na requisição: ' + response.status);
                    }
                    return response.json();
                })
                .then(cliente => {
                    if (cliente.error) {
                        throw new Error(cliente.error);
                    }
                    
                    document.getElementById('clienteId').value = cliente.id;
                    document.getElementById('nome').value = cliente.nome || '';
                    document.getElementById('tipo').value = cliente.tipo || 'Física';
                    
                    // Preencher CPF/CNPJ (já vem sem máscara do banco)
                    document.getElementById('cpf_cnpj').value = cliente.cpf_cnpj || '';
                    
                    document.getElementById('rg_ie').value = cliente.rg_ie || '';
                    document.getElementById('email').value = cliente.email || '';
                    document.getElementById('telefone').value = cliente.telefone || '';
                    document.getElementById('celular').value = cliente.celular || '';
                    document.getElementById('endereco').value = cliente.endereco || '';
                    document.getElementById('numero').value = cliente.numero || '';
                    document.getElementById('complemento').value = cliente.complemento || '';
                    document.getElementById('bairro').value = cliente.bairro || '';
                    document.getElementById('cep').value = cliente.cep || '';
                    document.getElementById('observacoes').value = cliente.observacoes || '';
                    document.getElementById('ativo').checked = cliente.ativo == 1;
                    
                    // Preencher estado
                    if (cliente.estado_id) {
                        document.getElementById('estado_select').value = cliente.estado_id;
                        document.getElementById('estado_id').value = cliente.estado_id;
                        
                        // Carregar cidades e depois selecionar a cidade correta
                        carregarCidades(cliente.estado_id);
                        
                        // Aguardar um pouco para as cidades carregarem
                        setTimeout(() => {
                            const cidadeSelect = document.getElementById('cidade');
                            // Tentar encontrar pelo ID da cidade
                            if (cliente.cidade_id) {
                                for (let i = 0; i < cidadeSelect.options.length; i++) {
                                    const option = cidadeSelect.options[i];
                                    if (option.getAttribute('data-cidade-id') == cliente.cidade_id) {
                                        cidadeSelect.selectedIndex = i;
                                        document.getElementById('cidade_id').value = cliente.cidade_id;
                                        break;
                                    }
                                }
                            }
                            // Se não encontrou pelo ID, tentar pelo nome
                            else if (cliente.cidade) {
                                for (let i = 0; i < cidadeSelect.options.length; i++) {
                                    if (cidadeSelect.options[i].value === cliente.cidade) {
                                        cidadeSelect.selectedIndex = i;
                                        break;
                                    }
                                }
                            }
                        }, 800);
                    }
                    
                    document.getElementById('formAcao').value = 'editar';
                    document.getElementById('modalTitulo').textContent = 'Editar Cliente';
                    document.getElementById('ativoField').style.display = 'block';
                    
                    toggleDocumentos();
                })
                .catch(error => {
                    alert('Erro ao carregar dados do cliente: ' + error.message);
                    console.error('Erro detalhado:', error);
                    fecharModal();
                });
        }
        
        // Função para abrir modal de confirmação de exclusão
        function confirmarExclusao(id, nome) {
            clienteIdParaExcluir = id;
            document.getElementById('confirmMessage').textContent = `Tem certeza que deseja excluir o cliente "${nome}"?`;
            document.getElementById('confirmModal').style.display = 'block';
        }
        
        // Função para fechar modal de confirmação
        function fecharConfirmModal() {
            document.getElementById('confirmModal').style.display = 'none';
            clienteIdParaExcluir = null;
        }
        
        // Função para confirmar exclusão final
        function confirmarExclusaoFinal() {
            if (clienteIdParaExcluir) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${clienteIdParaExcluir}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function reativarCliente(id) {
            if (confirm('Tem certeza que deseja reativar este cliente?\n\nO cliente voltará a aparecer nas listas padrão.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="reativar">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalCliente');
            const confirmModal = document.getElementById('confirmModal');
            
            if (event.target === modal) {
                fecharModal();
            }
            if (event.target === confirmModal) {
                fecharConfirmModal();
            }
        }
        
        // Buscar ao pressionar Enter
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                buscarClientes();
            }
        });

        // Adicionar validação do formulário
        document.getElementById('formCliente').addEventListener('submit', function(e) {
            const cidadeSelect = document.getElementById('cidade');
            if (cidadeSelect.disabled || cidadeSelect.value === '') {
                e.preventDefault();
                alert('Por favor, selecione uma cidade válida.');
                cidadeSelect.focus();
                return false;
            }
        });
    </script>
</body>
</html>