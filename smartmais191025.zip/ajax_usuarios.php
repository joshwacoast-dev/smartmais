<?php
include 'config.php';
verificarLogin();

if (!temPermissao('usuarios_visualizar')) {
    http_response_code(403);
    exit();
}

if (isset($_GET['acao']) && $_GET['acao'] == 'buscar' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $usuario = $stmt->fetch();
    
    if ($usuario) {
        $usuario['permissoes'] = json_decode($usuario['permissoes'], true) ?: [];
        header('Content-Type: application/json');
        echo json_encode($usuario);
    } else {
        http_response_code(404);
    }
}
?>