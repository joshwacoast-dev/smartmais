<?php
include 'config.php';
verificarLogin();

if (!temPermissao('produtos_visualizar')) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'Sem permissão']);
    exit();
}

$acao = $_GET['acao'] ?? '';

if ($acao == 'buscar' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
    $stmt->execute([$id]);
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($produto) {
        echo json_encode($produto);
    } else {
        echo json_encode(['error' => 'Produto não encontrado']);
    }
    exit();
}

echo json_encode(['error' => 'Ação inválida']);
?>