<?php
include 'config.php';
verificarLogin();

// Processar nova venda
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nova_venda'])) {
    try {
        $pdo->beginTransaction();
        
        // Gerar número do cupom fiscal
        $numero_cupom = date('YmdHis') . rand(100, 999);
        
        // Calcular total dos produtos ANTES de inserir a venda
        $total_venda = 0;
        $produtos_data = [];
        
        if (isset($_POST['produtos'])) {
            foreach ($_POST['produtos'] as $produto) {
                if (!empty($produto['id']) && $produto['quantidade'] > 0) {
                    $item_total = $produto['quantidade'] * $produto['preco'];
                    $total_venda += $item_total;
                    $produtos_data[] = [
                        'id' => $produto['id'],
                        'quantidade' => $produto['quantidade'],
                        'preco' => $produto['preco'],
                        'total' => $item_total
                    ];
                }
            }
        }
        
        // Inserir nova venda
        $stmt = $pdo->prepare("
            INSERT INTO vendas 
            (cliente_id, usuario_id, total, forma_pagamento, observacoes, status, numero_cupom)
            VALUES (?, ?, ?, ?, ?, 'concluida', ?)
        ");
        
        $stmt->execute([
            $_POST['cliente_id'],
            $_SESSION['usuario_id'],
            $total_venda,
            $_POST['forma_pagamento'],
            $_POST['observacoes'],
            $numero_cupom
        ]);
        
        $venda_id = $pdo->lastInsertId();
        
        // Inserir itens da venda
        if (!empty($produtos_data)) {
            $stmt_item = $pdo->prepare("
                INSERT INTO venda_itens 
                (venda_id, produto_id, quantidade, preco_unitario, total)
                VALUES (?, ?, ?, ?, ?)
            ");
            
            foreach ($produtos_data as $produto) {
                $stmt_item->execute([
                    $venda_id,
                    $produto['id'],
                    $produto['quantidade'],
                    $produto['preco'],
                    $produto['total']
                ]);
                
                // Atualizar estoque
                $pdo->prepare("UPDATE produtos SET estoque = estoque - ? WHERE id = ?")
                    ->execute([$produto['quantidade'], $produto['id']]);
            }
        }
        
        $pdo->commit();
        header('Location: vendas.php?sucesso=1&cupom=' . $numero_cupom);
        exit;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $erro = "Erro ao processar venda: " . $e->getMessage();
    }
}

// Buscar dados da empresa
try {
    $empresa = $pdo->query("SELECT * FROM empresa LIMIT 1")->fetch();
    if (!$empresa) {
        $empresa = [
            'nome' => 'SmartMais Tecnologia',
            'cnpj' => '12.345.678/0001-90',
            'endereco' => 'Endereço não cadastrado',
            'telefone' => '(85) 3095-0064',
            'email' => 'contato@storessmart.com.br'
        ];
    }
} catch (PDOException $e) {
    $empresa = [
        'nome' => 'SmartMais Tecnologia',
        'cnpj' => '12.345.678/0001-90',
        'endereco' => 'Endereço não cadastrado',
        'telefone' => '(85) 3095-0064',
        'email' => 'contato@storessmart.com.br'
    ];
}

// Buscar dados reais do banco de dados
try {
    // Vendas do dia
    $vendas_hoje = $pdo->query("
        SELECT COUNT(*) as total, COALESCE(SUM(total), 0) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND DATE(data_criacao) = CURDATE()
    ")->fetch();
    
    // Vendas da semana
    $vendas_semana = $pdo->query("
        SELECT COUNT(*) as total, COALESCE(SUM(total), 0) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND YEARWEEK(data_criacao) = YEARWEEK(CURDATE())
    ")->fetch();
    
    // Vendas do mês
    $vendas_mes = $pdo->query("
        SELECT COUNT(*) as total, COALESCE(SUM(total), 0) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND MONTH(data_criacao) = MONTH(CURRENT_DATE())
        AND YEAR(data_criacao) = YEAR(CURRENT_DATE())
    ")->fetch();
    
    // Ticket médio
    $ticket_medio = $vendas_mes['total'] > 0 ? $vendas_mes['valor'] / $vendas_mes['total'] : 0;
    
    // Últimas vendas
    $ultimas_vendas = $pdo->query("
        SELECT v.*, c.nome as cliente_nome, c.telefone, u.nome as vendedor
        FROM vendas v
        LEFT JOIN clientes c ON v.cliente_id = c.id
        LEFT JOIN usuarios u ON v.usuario_id = u.id
        WHERE v.status = 'concluida'
        ORDER BY v.data_criacao DESC
        LIMIT 10
    ")->fetchAll();
    
    // Vendas por vendedor
    $vendas_vendedor = $pdo->query("
        SELECT u.nome as vendedor, COUNT(*) as total_vendas, COALESCE(SUM(v.total), 0) as valor_total
        FROM vendas v
        JOIN usuarios u ON v.usuario_id = u.id
        WHERE v.status = 'concluida'
        AND v.data_criacao >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
        GROUP BY u.id, u.nome
        ORDER BY valor_total DESC
    ")->fetchAll();
    
    // Produtos mais vendidos
    $produtos_vendidos = $pdo->query("
        SELECT p.nome, SUM(vi.quantidade) as quantidade, SUM(vi.quantidade * vi.preco_unitario) as valor
        FROM venda_itens vi
        JOIN produtos p ON vi.produto_id = p.id
        JOIN vendas v ON vi.venda_id = v.id
        WHERE v.status = 'concluida'
        AND v.data_criacao >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
        GROUP BY p.id, p.nome
        ORDER BY quantidade DESC
        LIMIT 10
    ")->fetchAll();
    
    // Vendas por forma de pagamento (últimos 30 dias)
    $vendas_pagamento = $pdo->query("
        SELECT 
            forma_pagamento,
            COUNT(*) as quantidade,
            COALESCE(SUM(total), 0) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND data_criacao >= DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)
        GROUP BY forma_pagamento
        ORDER BY valor DESC
    ")->fetchAll();
    
    // Vendas dos últimos 6 meses para gráfico
    $vendas_mensais = $pdo->query("
        SELECT 
            MONTH(data_criacao) as mes,
            YEAR(data_criacao) as ano,
            COUNT(*) as quantidade,
            COALESCE(SUM(total), 0) as valor
        FROM vendas 
        WHERE status = 'concluida'
        AND data_criacao >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)
        GROUP BY YEAR(data_criacao), MONTH(data_criacao)
        ORDER BY ano, mes
    ")->fetchAll();

} catch (PDOException $e) {
    // Em caso de erro, definir valores padrão
    $vendas_hoje = ['total' => 0, 'valor' => 0];
    $vendas_semana = ['total' => 0, 'valor' => 0];
    $vendas_mes = ['total' => 0, 'valor' => 0];
    $ticket_medio = 0;
    $ultimas_vendas = [];
    $vendas_vendedor = [];
    $produtos_vendidos = [];
    $vendas_pagamento = [];
    $vendas_mensais = [];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendas - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1400px;
        }
        
        /* Seção de Boas-vindas */
        .welcome-section {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            color: white;
            padding: 32px;
            border-radius: 12px;
            margin-bottom: 24px;
            position: relative;
            overflow: hidden;
        }
        
        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 200px;
            height: 200px;
            background: url('https://storessmart.com.br/mascote2.png') no-repeat center;
            background-size: contain;
            opacity: 0.1;
        }
        
        .welcome-content h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .welcome-content p {
            opacity: 0.9;
            margin-bottom: 4px;
        }
        
        /* Grid de Estatísticas */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }
        
        .stat-card {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .stat-card-primary::before { background: #3b82f6; }
        .stat-card-success::before { background: #10b981; }
        .stat-card-warning::before { background: #f59e0b; }
        .stat-card-danger::before { background: #ef4444; }
        .stat-card-info::before { background: #06b6d4; }
        .stat-card-purple::before { background: #8b5cf6; }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        
        .stat-primary .stat-icon { background: #dbeafe; color: #3b82f6; }
        .stat-success .stat-icon { background: #dcfce7; color: #16a34a; }
        .stat-warning .stat-icon { background: #fef3c7; color: #d97706; }
        .stat-danger .stat-icon { background: #fee2e2; color: #dc2626; }
        .stat-info .stat-icon { background: #cffafe; color: #0891b2; }
        .stat-purple .stat-icon { background: #e0e7ff; color: #7c3aed; }
        
        .stat-content h3 {
            font-size: 14px;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
            line-height: 1;
        }
        
        .stat-trend {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
        }
        
        .trend-up { color: #10b981; }
        .trend-down { color: #ef4444; }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Grid de Gráficos */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .chart-header h3 {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
        }
        
        .chart-actions {
            display: flex;
            gap: 8px;
        }
        
        .chart-btn {
            padding: 6px 12px;
            border: 1px solid #e2e8f0;
            background: white;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .chart-btn:hover {
            background: #f8fafc;
        }
        
        .chart-btn.active {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        
        /* Ações Rápidas */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .quick-action {
            background: white;
            padding: 24px;
            border-radius: 12px;
            text-align: center;
            text-decoration: none;
            color: #374151;
            border: 2px solid #f1f5f9;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
        }
        
        .quick-action:hover {
            transform: translateY(-4px);
            border-color: #3b82f6;
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.15);
        }
        
        .quick-action i {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
        
        .quick-action span {
            font-weight: 600;
            font-size: 14px;
            color: #374151;
        }
        
        /* Grid de Informações */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 24px;
        }
        
        .info-card {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
        }
        
        .info-card h3 {
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .info-card h3 i {
            color: #3b82f6;
        }
        
        .info-list {
            list-style: none;
        }
        
        .info-list li {
            padding: 12px 0;
            border-bottom: 1px solid #f1f5f9;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .info-list li:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: #64748b;
            font-size: 14px;
        }
        
        .info-value {
            font-weight: 600;
            color: #1e293b;
        }
        
        .badge {
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
        }
        
        /* Tabelas para dados reais */
        .table-responsive {
            overflow-x: auto;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th,
        .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .data-table th {
            background: #f8fafc;
            font-weight: 600;
            color: #1e293b;
            font-size: 14px;
        }
        
        .data-table tr:hover {
            background: #f8fafc;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-concluida { background: #dcfce7; color: #166534; }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Botões */
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            text-decoration: none;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-outline {
            background: white;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        
        .btn-outline:hover {
            background: #f9fafb;
            border-color: #9ca3af;
        }
        
        /* Itens de Venda */
        .venda-item {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 12px;
            transition: all 0.2s;
        }
        
        .venda-item:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
        }
        
        .venda-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        
        .venda-cliente {
            font-weight: 600;
            color: #1e293b;
            font-size: 16px;
        }
        
        .venda-valor {
            font-weight: 700;
            color: #059669;
            font-size: 18px;
        }
        
        .venda-detalhes {
            display: flex;
            gap: 16px;
            font-size: 14px;
            color: #64748b;
        }
        
        .venda-detalhes span {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        /* Modal Nova Venda */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 2% auto;
            padding: 0;
            border-radius: 12px;
            width: 95%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        
        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            margin: 0;
            color: #1e293b;
            font-size: 20px;
        }
        
        .close {
            color: #64748b;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            background: none;
            border: none;
        }
        
        .close:hover {
            color: #374151;
        }
        
        .modal-body {
            padding: 24px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .form-group label {
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-control {
            padding: 10px 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .produtos-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr auto;
            gap: 8px;
            margin-bottom: 16px;
            align-items: start;
        }
        
        .produtos-header {
            font-weight: 600;
            color: #374151;
            padding: 8px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px;
        }
        
        .produto-item {
            display: contents;
        }
        
        .produto-item select,
        .produto-item input {
            margin-bottom: 8px;
        }
        
        .total-venda {
            background: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            text-align: right;
        }
        
        .total-valor {
            font-size: 24px;
            font-weight: 700;
            color: #0369a1;
        }
        
        .modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            justify-content: flex-end;
        }
        
        /* Cupom Fiscal */
        .cupom-section {
            background: white;
            border: 2px solid #3b82f6;
            border-radius: 12px;
            padding: 24px;
            margin: 20px 0;
            text-align: center;
        }
        
        .cupom-header {
            border-bottom: 2px dashed #e2e8f0;
            padding-bottom: 16px;
            margin-bottom: 16px;
        }
        
        .cupom-numero {
            font-size: 18px;
            font-weight: 700;
            color: #3b82f6;
            margin: 8px 0;
        }
        
        .cupom-detalhes {
            text-align: left;
            margin: 16px 0;
        }
        
        .cupom-detalhes p {
            margin: 8px 0;
            display: flex;
            justify-content: space-between;
        }
        
        .cupom-total {
            border-top: 2px solid #e2e8f0;
            padding-top: 16px;
            margin-top: 16px;
            font-size: 18px;
            font-weight: 700;
            color: #059669;
        }
        
        /* Estilo para o Cupom Fiscal 80mm */
        .cupom-80mm {
            width: 80mm;
            min-height: 100mm;
            background: white;
            padding: 8px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.2;
            margin: 0 auto;
            border: 1px solid #ccc;
        }
        
        .cupom-header-80mm {
            text-align: center;
            border-bottom: 1px dashed #000;
            padding-bottom: 8px;
            margin-bottom: 8px;
        }
        
        .cupom-header-80mm .empresa-nome {
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 4px;
        }
        
        .cupom-header-80mm .empresa-cnpj {
            font-size: 10px;
            margin-bottom: 4px;
        }
        
        .cupom-header-80mm .empresa-endereco {
            font-size: 10px;
            margin-bottom: 4px;
        }
        
        .cupom-body-80mm {
            margin-bottom: 8px;
        }
        
        .cupom-item-80mm {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
            border-bottom: 1px dotted #ccc;
            padding-bottom: 4px;
        }
        
        .cupom-item-descricao {
            flex: 2;
        }
        
        .cupom-item-valores {
            flex: 1;
            text-align: right;
        }
        
        .cupom-total-80mm {
            border-top: 2px solid #000;
            padding-top: 8px;
            margin-top: 8px;
            text-align: center;
            font-weight: bold;
            font-size: 14px;
        }
        
        .cupom-footer-80mm {
            border-top: 1px dashed #000;
            padding-top: 8px;
            text-align: center;
            font-size: 10px;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-bold { font-weight: bold; }
        
        /* Overlay para impressão */
        .print-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .print-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            max-width: 90vw;
            max-height: 90vh;
            overflow: auto;
        }
        
        .print-actions {
            margin-top: 20px;
            text-align: center;
        }
        
        .no-print {
            display: block;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .cupom-80mm, .cupom-80mm * {
                visibility: visible;
            }
            .cupom-80mm {
                position: absolute;
                left: 0;
                top: 0;
                width: 80mm;
                box-shadow: none;
                margin: 0;
                padding: 8px;
            }
            .no-print {
                display: none !important;
            }
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .chart-container {
                height: 250px;
            }
            
            .quick-actions {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
            
            .venda-detalhes {
                flex-direction: column;
                gap: 8px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .produtos-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }
            
            .produtos-header {
                display: none;
            }
            
            .produto-item {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 8px;
                align-items: end;
            }
            
            .produto-item select,
            .produto-item input {
                margin-bottom: 0;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .welcome-section {
                padding: 24px;
            }
            
            .welcome-content h2 {
                font-size: 20px;
            }
            
            .stat-card {
                padding: 20px;
            }
            
            .stat-number {
                font-size: 28px;
            }
            
            .card-body {
                padding: 24px;
            }
            
            .quick-action {
                padding: 20px;
            }
            
            .info-card {
                padding: 20px;
            }
            
            .chart-container {
                height: 200px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="https://storessmart.com.br/logo.png" alt="SmartMais Logo">
                <h1>Smart<span>Mais</span></h1>
            </div>
        </div>
        
        <h1><i class="fas fa-shopping-cart"></i> Vendas</h1>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li class="active"><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <!-- Welcome Section -->
            <div class="welcome-section">
                <div class="welcome-content">
                    <h2>Controle de Vendas 💰</h2>
                    <p>Gerencie todas as vendas e acompanhe o desempenho comercial</p>
                    <p><strong>Período atual:</strong> <?php echo date('d/m/Y'); ?></p>
                </div>
            </div>
            
            <!-- Cupom Fiscal após venda - VERSÃO CORRIGIDA -->
            <?php if (isset($_GET['sucesso']) && isset($_GET['cupom'])): 
                // CORREÇÃO: Buscar dados da venda de forma mais simples e direta
                $cupom_venda = $pdo->prepare("
                    SELECT v.*, c.nome as cliente_nome, c.cpf_cnpj, c.endereco, 
                           u.nome as vendedor
                    FROM vendas v
                    LEFT JOIN clientes c ON v.cliente_id = c.id
                    LEFT JOIN usuarios u ON v.usuario_id = u.id
                    WHERE v.numero_cupom = ?
                ");
                $cupom_venda->execute([$_GET['cupom']]);
                $venda = $cupom_venda->fetch();
                
                if ($venda):
                    // Buscar itens da venda separadamente
                    $itens_venda = $pdo->prepare("
                        SELECT vi.*, p.nome as produto_nome
                        FROM venda_itens vi
                        LEFT JOIN produtos p ON vi.produto_id = p.id
                        WHERE vi.venda_id = ?
                    ");
                    $itens_venda->execute([$venda['id']]);
                    $dados_itens = $itens_venda->fetchAll();
                    
                    // Calcular subtotal corretamente
                    $subtotal_cupom = 0;
                    foreach ($dados_itens as $item) {
                        $subtotal_cupom += $item['total'];
                    }
            ?>
                <div class="cupom-section no-print">
                    <div class="cupom-header">
                        <h3><i class="fas fa-receipt"></i> CUPOM FISCAL - VENDA CONCLUÍDA</h3>
                        <div class="cupom-numero">Nº: <?php echo $venda['numero_cupom']; ?></div>
                        <p>Venda registrada com sucesso!</p>
                    </div>
                    
                    <div style="text-align: center; margin: 20px 0;">
                        <button class="btn btn-primary" onclick="visualizarCupom()">
                            <i class="fas fa-eye"></i> Visualizar Cupom
                        </button>
                        <button class="btn btn-success" onclick="imprimirCupom()">
                            <i class="fas fa-print"></i> Imprimir Cupom
                        </button>
                        <a href="vendas.php" class="btn btn-outline">
                            <i class="fas fa-arrow-left"></i> Voltar para Vendas
                        </a>
                    </div>
                </div>
                
                <!-- Overlay para visualização e impressão do cupom -->
                <div class="print-overlay" id="printOverlay">
                    <div class="print-container">
                        <!-- Cupom Fiscal 80mm - VERSÃO CORRIGIDA -->
                        <div class="cupom-80mm" id="cupom80mm">
                            <div class="cupom-header-80mm">
                                <div class="empresa-nome"><?php echo htmlspecialchars($empresa['nome']); ?></div>
                                <div class="empresa-cnpj">CNPJ: <?php echo htmlspecialchars($empresa['cnpj']); ?></div>
                                <div class="empresa-endereco"><?php echo htmlspecialchars($empresa['endereco']); ?></div>
                                <div class="empresa-telefone">Tel: <?php echo htmlspecialchars($empresa['telefone']); ?></div>
                            </div>
                            
                            <div class="cupom-body-80mm">
                                <div class="text-center text-bold">CUPOM NÃO FISCAL</div>
                                <div style="border-bottom: 1px dashed #000; margin: 8px 0; padding-bottom: 8px;">
                                    <div>Nº: <?php echo $venda['numero_cupom']; ?></div>
                                    <div>Data: <?php echo date('d/m/Y H:i', strtotime($venda['data_criacao'])); ?></div>
                                    <div>Cliente: <?php echo htmlspecialchars($venda['cliente_nome']); ?></div>
                                    <?php if ($venda['cpf_cnpj']): ?>
                                        <div>CPF/CNPJ: <?php echo htmlspecialchars($venda['cpf_cnpj']); ?></div>
                                    <?php endif; ?>
                                    <div>Vendedor: <?php echo htmlspecialchars($venda['vendedor']); ?></div>
                                </div>
                                
                                <div style="margin-bottom: 8px;">
                                    <div class="text-bold" style="border-bottom: 1px solid #000; padding-bottom: 4px; margin-bottom: 4px;">
                                        ITENS DA VENDA
                                    </div>
                                    <?php foreach ($dados_itens as $item): ?>
                                        <div class="cupom-item-80mm">
                                            <div class="cupom-item-descricao">
                                                <?php echo htmlspecialchars($item['produto_nome']); ?>
                                            </div>
                                            <div class="cupom-item-valores">
                                                <?php echo $item['quantidade']; ?> x R$ <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?>
                                            </div>
                                        </div>
                                        <div class="text-right" style="margin-bottom: 4px;">
                                            R$ <?php echo number_format($item['total'], 2, ',', '.'); ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div style="border-top: 1px dashed #000; padding-top: 8px;">
                                    <div class="cupom-item-80mm">
                                        <div>Subtotal:</div>
                                        <div>R$ <?php echo number_format($subtotal_cupom, 2, ',', '.'); ?></div>
                                    </div>
                                    <?php if (isset($venda['desconto']) && $venda['desconto'] > 0): ?>
                                    <div class="cupom-item-80mm">
                                        <div>Desconto:</div>
                                        <div>- R$ <?php echo number_format($venda['desconto'], 2, ',', '.'); ?></div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (isset($venda['acrescimo']) && $venda['acrescimo'] > 0): ?>
                                    <div class="cupom-item-80mm">
                                        <div>Acréscimo:</div>
                                        <div>+ R$ <?php echo number_format($venda['acrescimo'], 2, ',', '.'); ?></div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="cupom-total-80mm">
                                TOTAL: R$ <?php echo number_format($venda['total'], 2, ',', '.'); ?>
                            </div>
                            
                            <div class="cupom-footer-80mm">
                                <div style="margin-bottom: 4px;">
                                    <strong>FORMA DE PAGAMENTO:</strong><br>
                                    <?php echo strtoupper(str_replace('_', ' ', $venda['forma_pagamento'])); ?>
                                </div>
                                <?php if (!empty($venda['observacoes'])): ?>
                                <div style="margin-bottom: 4px;">
                                    <strong>OBSERVAÇÕES:</strong><br>
                                    <?php echo htmlspecialchars($venda['observacoes']); ?>
                                </div>
                                <?php endif; ?>
                                <div style="border-top: 1px dashed #000; padding-top: 8px; margin-top: 8px;">
                                    *** OBRIGADO PELA PREFERÊNCIA ***<br>
                                    Volte Sempre!
                                </div>
                                <div style="margin-top: 8px; font-size: 9px;">
                                    Emitido em: <?php echo date('d/m/Y H:i:s'); ?><br>
                                    Sistema: SmartMais
                                </div>
                            </div>
                        </div>
                        
                        <div class="print-actions no-print">
                            <button class="btn btn-success" onclick="imprimirCupomDireto()">
                                <i class="fas fa-print"></i> Imprimir
                            </button>
                            <button class="btn btn-outline" onclick="fecharVisualizacao()">
                                <i class="fas fa-times"></i> Fechar
                            </button>
                        </div>
                    </div>
                </div>
                
            <?php endif; endif; ?>
            
            <!-- Mensagens de Sucesso/Erro -->
            <?php if (isset($_GET['sucesso'])): ?>
                <div style="background: #dcfce7; color: #166534; padding: 16px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #bbf7d0;">
                    <i class="fas fa-check-circle"></i> Venda registrada com sucesso! Cupom: <?php echo $_GET['cupom'] ?? ''; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($erro)): ?>
                <div style="background: #fee2e2; color: #dc2626; padding: 16px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #fecaca;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $erro; ?>
                </div>
            <?php endif; ?>
            
            <!-- Stats Grid com Dados Reais -->
            <div class="stats-grid">
                <div class="stat-card stat-card-primary">
                    <div class="stat-header">
                        <div class="stat-content">
                            <h3>Vendas Hoje</h3>
                            <div class="stat-number"><?php echo $vendas_hoje['total']; ?></div>
                            <div class="stat-trend trend-up">
                                <i class="fas fa-dollar-sign"></i>
                                <span>R$ <?php echo number_format($vendas_hoje['valor'], 2, ',', '.'); ?></span>
                            </div>
                        </div>
                        <div class="stat-icon stat-primary">
                            <i class="fas fa-sun"></i>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-card-success">
                    <div class="stat-header">
                        <div class="stat-content">
                            <h3>Vendas da Semana</h3>
                            <div class="stat-number"><?php echo $vendas_semana['total']; ?></div>
                            <div class="stat-trend trend-up">
                                <i class="fas fa-chart-line"></i>
                                <span>R$ <?php echo number_format($vendas_semana['valor'], 2, ',', '.'); ?></span>
                            </div>
                        </div>
                        <div class="stat-icon stat-success">
                            <i class="fas fa-calendar-week"></i>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-card-info">
                    <div class="stat-header">
                        <div class="stat-content">
                            <h3>Vendas do Mês</h3>
                            <div class="stat-number"><?php echo $vendas_mes['total']; ?></div>
                            <div class="stat-trend trend-up">
                                <i class="fas fa-chart-bar"></i>
                                <span>R$ <?php echo number_format($vendas_mes['valor'], 2, ',', '.'); ?></span>
                            </div>
                        </div>
                        <div class="stat-icon stat-info">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card stat-card-purple">
                    <div class="stat-header">
                        <div class="stat-content">
                            <h3>Ticket Médio</h3>
                            <div class="stat-number">R$ <?php echo number_format($ticket_medio, 2, ',', '.'); ?></div>
                            <div class="stat-trend trend-up">
                                <i class="fas fa-receipt"></i>
                                <span>Por venda</span>
                            </div>
                        </div>
                        <div class="stat-icon stat-purple">
                            <i class="fas fa-receipt"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Botão Nova Venda -->
            <div style="margin-bottom: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
                <button class="btn btn-success" onclick="abrirModalVenda()">
                    <i class="fas fa-plus"></i> Nova Venda
                </button>
                <a href="relatorios.php?tipo=vendas" class="btn btn-primary">
                    <i class="fas fa-chart-pie"></i> Relatório de Vendas
                </a>
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-chart-bar"></i> Ver Dashboard
                </a>
            </div>
            
            <!-- Gráficos Interativos -->
            <div class="charts-grid">
                <!-- Gráfico de Vendas Mensais -->
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fas fa-chart-line"></i> Vendas dos Últimos 6 Meses</h3>
                        <div class="chart-actions">
                            <button class="chart-btn active" onclick="toggleChartType('vendasMensais', 'line')">Linha</button>
                            <button class="chart-btn" onclick="toggleChartType('vendasMensais', 'bar')">Barras</button>
                        </div>
                    </div>
                    <canvas id="vendasMensaisChart"></canvas>
                </div>
                
                <!-- Gráfico de Formas de Pagamento -->
                <div class="chart-container">
                    <div class="chart-header">
                        <h3><i class="fas fa-chart-pie"></i> Formas de Pagamento</h3>
                    </div>
                    <canvas id="pagamentoChart"></canvas>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-bolt"></i> Ações Rápidas</h2>
                </div>
                <div class="card-body">
                    <div class="quick-actions">
                        <a href="javascript:void(0)" class="quick-action" onclick="abrirModalVenda()">
                            <i class="fas fa-cash-register"></i>
                            <span>Nova Venda</span>
                        </a>
                        
                        <a href="orcamentos.php?acao=novo" class="quick-action">
                            <i class="fas fa-file-invoice"></i>
                            <span>Novo Orçamento</span>
                        </a>
                        
                        <a href="clientes.php?acao=novo" class="quick-action">
                            <i class="fas fa-user-plus"></i>
                            <span>Novo Cliente</span>
                        </a>
                        
                        <a href="relatorios.php?tipo=vendas" class="quick-action">
                            <i class="fas fa-chart-pie"></i>
                            <span>Relatórios</span>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Grid com Dados Reais -->
            <div class="info-grid">
                <!-- Últimas Vendas -->
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-history"></i> Últimas Vendas</h2>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($ultimas_vendas)): ?>
                            <?php foreach ($ultimas_vendas as $venda): ?>
                                <div class="venda-item">
                                    <div class="venda-header">
                                        <div class="venda-cliente">
                                            <?php echo $venda['cliente_nome']; ?>
                                            <small style="color: #64748b; font-weight: normal;"> - <?php echo $venda['vendedor']; ?></small>
                                        </div>
                                        <div class="venda-valor">
                                            R$ <?php echo number_format($venda['total'], 2, ',', '.'); ?>
                                        </div>
                                    </div>
                                    <div class="venda-detalhes">
                                        <span><i class="fas fa-receipt"></i> Cupom: <?php echo $venda['numero_cupom']; ?></span>
                                        <span><i class="fas fa-calendar"></i> <?php echo date('d/m/Y H:i', strtotime($venda['data_criacao'])); ?></span>
                                        <span><i class="fas fa-credit-card"></i> <?php echo ucfirst(str_replace('_', ' ', $venda['forma_pagamento'])); ?></span>
                                        <?php if ($venda['telefone']): ?>
                                            <span><i class="fas fa-phone"></i> <?php echo $venda['telefone']; ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="text-align: center; color: #64748b; padding: 20px;">Nenhuma venda encontrada</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Top Vendedores -->
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-trophy"></i> Top Vendedores</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Vendedor</th>
                                        <th class="text-right">Vendas</th>
                                        <th class="text-right">Valor Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($vendas_vendedor)): ?>
                                        <?php foreach ($vendas_vendedor as $vendedor): ?>
                                            <tr>
                                                <td><?php echo $vendedor['vendedor']; ?></td>
                                                <td class="text-right"><?php echo $vendedor['total_vendas']; ?></td>
                                                <td class="text-right">R$ <?php echo number_format($vendedor['valor_total'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center">Nenhum dado disponível</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Produtos Mais Vendidos -->
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-star"></i> Produtos Mais Vendidos</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Produto</th>
                                        <th class="text-right">Quantidade</th>
                                        <th class="text-right">Valor Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($produtos_vendidos)): ?>
                                        <?php foreach ($produtos_vendidos as $produto): ?>
                                            <tr>
                                                <td><?php echo $produto['nome']; ?></td>
                                                <td class="text-right"><?php echo $produto['quantidade']; ?></td>
                                                <td class="text-right">R$ <?php echo number_format($produto['valor'], 2, ',', '.'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center">Nenhum produto vendido</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Nova Venda -->
    <div id="modalVenda" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-cash-register"></i> Nova Venda</h2>
                <button class="close" onclick="fecharModalVenda()">&times;</button>
            </div>
            <div class="modal-body">
                <form id="formVenda" method="POST">
                    <input type="hidden" name="nova_venda" value="1">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="cliente_id">Cliente *</label>
                            <select name="cliente_id" id="cliente_id" class="form-control" required>
                                <option value="">Selecione um cliente</option>
                                <?php
                                $clientes = $pdo->query("SELECT id, nome FROM clientes WHERE ativo = 1 ORDER BY nome")->fetchAll();
                                foreach ($clientes as $cliente) {
                                    echo "<option value='{$cliente['id']}'>{$cliente['nome']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="forma_pagamento">Forma de Pagamento *</label>
                            <select name="forma_pagamento" id="forma_pagamento" class="form-control" required>
                                <option value="dinheiro">Dinheiro</option>
                                <option value="cartao_credito">Cartão de Crédito</option>
                                <option value="cartao_debito">Cartão de Débito</option>
                                <option value="pix">PIX</option>
                                <option value="boleto">Boleto</option>
                                <option value="transferencia">Transferência</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="observacoes">Observações</label>
                        <textarea name="observacoes" id="observacoes" class="form-control" rows="3" placeholder="Observações sobre a venda..."></textarea>
                    </div>
                    
                    <h3 style="margin: 20px 0 10px 0; color: #1e293b;">Produtos da Venda</h3>
                    
                    <div class="produtos-grid">
                        <div class="produtos-header">Produto</div>
                        <div class="produtos-header">Quantidade</div>
                        <div class="produtos-header">Preço Unit.</div>
                        <div class="produtos-header">Total</div>
                        <div class="produtos-header">Ações</div>
                        
                        <div id="produtos-container">
                            <!-- Produtos serão adicionados aqui via JavaScript -->
                        </div>
                    </div>
                    
                    <button type="button" class="btn btn-outline" onclick="adicionarProduto()" style="margin-bottom: 20px;">
                        <i class="fas fa-plus"></i> Adicionar Produto
                    </button>
                    
                    <div class="total-venda">
                        <strong>Total da Venda: </strong>
                        <span class="total-valor" id="total-venda">R$ 0,00</span>
                        <input type="hidden" name="total" id="total-input" value="0">
                    </div>
                    
                    <div class="modal-actions">
                        <button type="button" class="btn btn-outline" onclick="fecharModalVenda()">Cancelar</button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check"></i> Finalizar Venda
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="https://storessmart.com.br/logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 99258.9475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        // Fechar menu ao clicar fora (em telas pequenas)
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(event.target) && 
                !mobileMenuBtn.contains(event.target) &&
                sidebar.classList.contains('open')) {
                sidebar.classList.remove('open');
            }
        });

        // Dados para os gráficos
        const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        
        const vendasMensaisData = {
            labels: [],
            valores: []
        };

        const pagamentoData = {
            labels: [],
            valores: []
        };

        <?php
        // Preparar dados PHP para JavaScript - Vendas Mensais
        if (!empty($vendas_mensais)) {
            foreach ($vendas_mensais as $venda) {
                $mes = $venda['mes'];
                $ano = $venda['ano'];
                echo "vendasMensaisData.labels.push('" . $meses[$mes-1] . "/" . substr($ano, 2) . "');\n";
                echo "vendasMensaisData.valores.push(" . $venda['valor'] . ");\n";
            }
        }

        // Preparar dados PHP para JavaScript - Formas de Pagamento
        if (!empty($vendas_pagamento)) {
            foreach ($vendas_pagamento as $pagamento) {
                $forma = ucfirst(str_replace('_', ' ', $pagamento['forma_pagamento']));
                echo "pagamentoData.labels.push('" . $forma . "');\n";
                echo "pagamentoData.valores.push(" . $pagamento['valor'] . ");\n";
            }
        }
        ?>

        // Inicializar gráficos
        let vendasMensaisChart, pagamentoChart;

        function initCharts() {
            // Gráfico de Vendas Mensais
            const vendasMensaisCtx = document.getElementById('vendasMensaisChart').getContext('2d');
            vendasMensaisChart = new Chart(vendasMensaisCtx, {
                type: 'line',
                data: {
                    labels: vendasMensaisData.labels,
                    datasets: [{
                        label: 'Valor em Vendas (R$)',
                        data: vendasMensaisData.valores,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'R$ ' + context.parsed.y.toLocaleString('pt-BR', {minimumFractionDigits: 2});
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Valor (R$)'
                            }
                        }
                    }
                }
            });

            // Gráfico de Formas de Pagamento
            const pagamentoCtx = document.getElementById('pagamentoChart').getContext('2d');
            pagamentoChart = new Chart(pagamentoCtx, {
                type: 'doughnut',
                data: {
                    labels: pagamentoData.labels,
                    datasets: [{
                        data: pagamentoData.valores,
                        backgroundColor: [
                            '#3b82f6',
                            '#8b5cf6',
                            '#10b981',
                            '#f59e0b',
                            '#ef4444',
                            '#06b6d4'
                        ],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((context.parsed / total) * 100);
                                    return `${context.label}: R$ ${context.parsed.toLocaleString('pt-BR', {minimumFractionDigits: 2})} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        }

        // Alternar tipo de gráfico
        function toggleChartType(chartName, type) {
            if (chartName === 'vendasMensais') {
                // Atualizar botões
                document.querySelectorAll('#vendasMensaisChart').closest('.chart-container').find('.chart-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                event.target.classList.add('active');
                
                // Mudar tipo do gráfico
                vendasMensaisChart.config.type = type;
                vendasMensaisChart.update();
            }
        }

        // Modal de Venda
        let produtoCount = 0;
        
        function abrirModalVenda() {
            document.getElementById('modalVenda').style.display = 'block';
            produtoCount = 0;
            document.getElementById('produtos-container').innerHTML = '';
            adicionarProduto(); // Adiciona o primeiro produto automaticamente
            atualizarTotal();
        }
        
        function fecharModalVenda() {
            document.getElementById('modalVenda').style.display = 'none';
        }
        
        function adicionarProduto() {
            produtoCount++;
            const produtoHtml = `
                <div class="produto-item" id="produto-${produtoCount}">
                    <select name="produtos[${produtoCount}][id]" class="form-control" onchange="atualizarPreco(${produtoCount})" required>
                        <option value="">Selecione um produto</option>
                        <?php
                        $produtos = $pdo->query("SELECT id, nome, preco_venda, estoque FROM produtos WHERE ativo = 1 AND estoque > 0 ORDER BY nome")->fetchAll();
                        foreach ($produtos as $produto) {
                            echo "<option value='{$produto['id']}' data-preco='{$produto['preco_venda']}' data-estoque='{$produto['estoque']}'>{$produto['nome']} (Estoque: {$produto['estoque']})</option>";
                        }
                        ?>
                    </select>
                    <input type="number" name="produtos[${produtoCount}][quantidade]" class="form-control" min="1" value="1" onchange="calcularTotalProduto(${produtoCount})" required>
                    <input type="number" name="produtos[${produtoCount}][preco]" class="form-control preco-unitario" step="0.01" min="0" onchange="calcularTotalProduto(${produtoCount})" required>
                    <input type="text" class="form-control total-produto" readonly value="R$ 0,00">
                    <button type="button" class="btn btn-outline" onclick="removerProduto(${produtoCount})" style="padding: 8px 12px;">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            document.getElementById('produtos-container').insertAdjacentHTML('beforeend', produtoHtml);
        }
        
        function removerProduto(id) {
            document.getElementById(`produto-${id}`).remove();
            atualizarTotal();
        }
        
        function atualizarPreco(id) {
            const select = document.querySelector(`#produto-${id} select`);
            const precoInput = document.querySelector(`#produto-${id} .preco-unitario`);
            const selectedOption = select.options[select.selectedIndex];
            
            if (selectedOption.value) {
                const preco = selectedOption.getAttribute('data-preco');
                precoInput.value = parseFloat(preco).toFixed(2);
                calcularTotalProduto(id);
            }
        }
        
        function calcularTotalProduto(id) {
            const quantidadeInput = document.querySelector(`#produto-${id} input[name="produtos[${id}][quantidade]"]`);
            const precoInput = document.querySelector(`#produto-${id} .preco-unitario`);
            const totalElement = document.querySelector(`#produto-${id} .total-produto`);
            
            const quantidade = parseFloat(quantidadeInput.value) || 0;
            const preco = parseFloat(precoInput.value) || 0;
            const total = quantidade * preco;
            
            totalElement.value = 'R$ ' + total.toLocaleString('pt-BR', {minimumFractionDigits: 2});
            atualizarTotal();
        }
        
        function atualizarTotal() {
            let total = 0;
            const totalElements = document.querySelectorAll('.total-produto');
            
            totalElements.forEach(element => {
                const valor = element.value.replace('R$ ', '').replace('.', '').replace(',', '.');
                total += parseFloat(valor) || 0;
            });
            
            document.getElementById('total-venda').textContent = 'R$ ' + total.toLocaleString('pt-BR', {minimumFractionDigits: 2});
            document.getElementById('total-input').value = total;
        }
        
        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalVenda');
            if (event.target === modal) {
                fecharModalVenda();
            }
        }

        // Funções para o cupom fiscal
        function visualizarCupom() {
            document.getElementById('printOverlay').style.display = 'flex';
        }
        
        function fecharVisualizacao() {
            document.getElementById('printOverlay').style.display = 'none';
        }
        
        function imprimirCupom() {
            visualizarCupom();
        }
        
        function imprimirCupomDireto() {
            const cupomElement = document.getElementById('cupom80mm');
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Cupom Fiscal - <?php echo $empresa['nome']; ?></title>
                    <style>
                        body {
                            margin: 0;
                            padding: 0;
                            font-family: 'Courier New', monospace;
                            font-size: 12px;
                            line-height: 1.2;
                        }
                        .cupom-80mm {
                            width: 80mm;
                            min-height: 100mm;
                            background: white;
                            padding: 8px;
                        }
                        .cupom-header-80mm {
                            text-align: center;
                            border-bottom: 1px dashed #000;
                            padding-bottom: 8px;
                            margin-bottom: 8px;
                        }
                        .cupom-header-80mm .empresa-nome {
                            font-weight: bold;
                            font-size: 14px;
                            margin-bottom: 4px;
                        }
                        .cupom-header-80mm .empresa-cnpj {
                            font-size: 10px;
                            margin-bottom: 4px;
                        }
                        .cupom-header-80mm .empresa-endereco {
                            font-size: 10px;
                            margin-bottom: 4px;
                        }
                        .cupom-body-80mm {
                            margin-bottom: 8px;
                        }
                        .cupom-item-80mm {
                            display: flex;
                            justify-content: space-between;
                            margin-bottom: 4px;
                            border-bottom: 1px dotted #ccc;
                            padding-bottom: 4px;
                        }
                        .cupom-item-descricao { flex: 2; }
                        .cupom-item-valores { flex: 1; text-align: right; }
                        .cupom-total-80mm {
                            border-top: 2px solid #000;
                            padding-top: 8px;
                            margin-top: 8px;
                            text-align: center;
                            font-weight: bold;
                            font-size: 14px;
                        }
                        .cupom-footer-80mm {
                            border-top: 1px dashed #000;
                            padding-top: 8px;
                            text-align: center;
                            font-size: 10px;
                        }
                        .text-center { text-align: center; }
                        .text-right { text-align: right; }
                        .text-bold { font-weight: bold; }
                        @media print {
                            body { margin: 0; padding: 0; }
                            .cupom-80mm { 
                                width: 80mm !important; 
                                margin: 0 !important;
                                padding: 8px !important;
                                box-shadow: none !important;
                            }
                        }
                    </style>
                </head>
                <body>
                    ${cupomElement.outerHTML}
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() {
                                window.close();
                            }, 1000);
                        };
                    <\/script>
                </body>
                </html>
            `);
            
            printWindow.document.close();
        }
        
        // Fechar overlay ao clicar fora
        document.getElementById('printOverlay').addEventListener('click', function(e) {
            if (e.target === this) {
                fecharVisualizacao();
            }
        });

        // Inicializar gráficos quando a página carregar
        document.addEventListener('DOMContentLoaded', function() {
            initCharts();
        });
    </script>
</body>
</html>