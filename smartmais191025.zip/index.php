<?php
// index.php - Redirecionamento automático
header("Location: login.php");
exit();
?>