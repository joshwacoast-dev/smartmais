<?php
// logout.php
session_start();

// Registrar log de saída se o usuário estiver logado
if (isset($_SESSION['usuario_id'])) {
    // Incluir config para usar a função registrarLog
    include 'config.php';
    registrarLog('Logout do sistema', 'Usuário: ' . $_SESSION['usuario_nome']);
}

// Destruir todas as variáveis de sessão
$_SESSION = array();

// Se deseja destruir a sessão completamente, apague também o cookie de sessão.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finalmente, destruir a sessão
session_destroy();

// Redirecionar para a página de login
header("Location: login.php");
exit();
?>