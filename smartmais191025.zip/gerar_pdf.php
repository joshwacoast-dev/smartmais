<?php
include 'config.php';

$tipo = $_GET['tipo'] ?? '';
$id = intval($_GET['id'] ?? 0);
$token = $_GET['token'] ?? '';

// Verificar se é um acesso via link compartilhado
$acesso_compartilhado = false;
$acesso_publico = false;

if (!empty($token)) {
    $stmt = $pdo->prepare("SELECT * FROM documentos_compartilhados WHERE token = ? AND expira_em > NOW()");
    $stmt->execute([$token]);
    $compartilhamento = $stmt->fetch();
    
    if ($compartilhamento) {
        $acesso_compartilhado = true;
        $acesso_publico = true; // Acesso público via token
        $tipo = $compartilhamento['tipo_documento'];
        $id = $compartilhamento['documento_id'];
        
        // Registrar visualização
        $stmt = $pdo->prepare("UPDATE documentos_compartilhados SET visualizacoes = visualizacoes + 1 WHERE token = ?");
        $stmt->execute([$token]);
    } else {
        die("Link expirado ou inválido!");
    }
} else {
    // Se não tem token, verificar se o usuário está logado
    session_start();
    if (!isset($_SESSION['usuario_id'])) {
        // Se não está logado e tenta acessar diretamente, redirecionar para login
        if ($tipo == 'os' && $id > 0) {
            // Para OS, permitir criar link público se não tiver token
            $stmt = $pdo->prepare("SELECT token FROM documentos_compartilhados WHERE tipo_documento = 'os' AND documento_id = ?");
            $stmt->execute([$id]);
            $token_existente = $stmt->fetchColumn();
            
            if ($token_existente) {
                // Redirecionar para a versão pública
                header("Location: ?tipo=os&id=$id&token=$token_existente");
                exit;
            }
        }
        header("Location: login.php");
        exit;
    }
    verificarLogin();
}

// Verificar se documento está assinado
$documento_assinado = false;
if ($tipo == 'orcamento' && $id > 0) {
    $stmt = $pdo->prepare("
        SELECT o.*, c.nome as cliente_nome, c.cpf_cnpj, c.endereco, c.telefone, c.email, c.cidade, c.estado,
               e.nome_empresa, e.cnpj as empresa_cnpj, e.endereco as empresa_endereco, 
               e.telefone as empresa_telefone, e.email as empresa_email, e.logo_path,
               a.nome as assinatura_nome, a.email as assinatura_email, a.ip as assinatura_ip, 
               a.data_assinatura as assinatura_data,
               CASE WHEN a.id IS NOT NULL THEN 1 ELSE 0 END as documento_assinado
        FROM orcamentos o 
        LEFT JOIN clientes c ON o.cliente_id = c.id 
        LEFT JOIN empresa_info e ON e.id = 1 
        LEFT JOIN assinaturas_digitais a ON a.documento_id = o.id AND a.tipo_documento = 'orcamento'
        WHERE o.id = ?
    ");
    $stmt->execute([$id]);
    $dados = $stmt->fetch();
    
    if (!$dados) die("Orçamento não encontrado!");
    
    $documento_assinado = (bool)$dados['documento_assinado'];
    
    $itens = $pdo->prepare("SELECT * FROM orcamento_itens WHERE orcamento_id = ?");
    $itens->execute([$id]);
    $itens_data = $itens->fetchAll();
    
    $titulo = "ORÇAMENTO";
    $numero_doc = $dados['numero'];
    $data_principal = "Data de Emissão: " . formatarData($dados['data_emissao']);
    $data_secundaria = "Validade: " . formatarData($dados['valido_ate']);

} elseif ($tipo == 'os' && $id > 0) {
    $stmt = $pdo->prepare("
        SELECT os.*, c.nome as cliente_nome, c.cpf_cnpj, c.endereco, c.telefone, c.email, c.cidade, c.estado,
               e.nome_empresa, e.cnpj as empresa_cnpj, e.endereco as empresa_endereco, 
               e.telefone as empresa_telefone, e.email as empresa_email, e.logo_path,
               a.nome as assinatura_nome, a.email as assinatura_email, a.ip as assinatura_ip, 
               a.data_assinatura as assinatura_data,
               CASE WHEN a.id IS NOT NULL THEN 1 ELSE 0 END as documento_assinado
        FROM ordens_servico os 
        LEFT JOIN clientes c ON os.cliente_id = c.id 
        LEFT JOIN empresa_info e ON e.id = 1 
        LEFT JOIN assinaturas_digitais a ON a.documento_id = os.id AND a.tipo_documento = 'os'
        WHERE os.id = ?
    ");
    $stmt->execute([$id]);
    $dados = $stmt->fetch();
    
    if (!$dados) die("Ordem de Serviço não encontrada!");
    
    $documento_assinado = (bool)$dados['documento_assinado'];
    
    $itens = $pdo->prepare("SELECT * FROM os_itens WHERE ordem_servico_id = ?");
    $itens->execute([$id]);
    $itens_data = $itens->fetchAll();
    
    $titulo = "ORDEM DE SERVIÇO";
    $numero_doc = $dados['numero'];
    $data_principal = "Data de Entrada: " . formatarData($dados['data_entrada']);
    $data_secundaria = "Previsão de Entrega: " . formatarData($dados['data_previsao']);

} else {
    die("Parâmetros inválidos!");
}

$subtotal = 0;
foreach ($itens_data as $item) {
    $subtotal += $item['total'];
}
$total_geral = $subtotal - ($dados['desconto'] ?? 0);

// Verificar se o logo existe e é acessível
$logo_url = '';
if (!empty($dados['logo_path']) && file_exists($dados['logo_path'])) {
    $logo_url = $dados['logo_path'];
}

// Gerar códigos de controle FIXOS baseados no ID e tipo
$codigo_controle = strtoupper(substr(md5($id . $tipo . 'FIXO2024'), 0, 12));
$codigo_barras_numero = $id . str_pad($tipo == 'orcamento' ? 1001 : 2001, 4, '0', STR_PAD_LEFT);

// Calcular totais por tipo de item
$totais_por_tipo = [];
foreach ($itens_data as $item) {
    $tipo_item = $item['tipo'];
    if (!isset($totais_por_tipo[$tipo_item])) {
        $totais_por_tipo[$tipo_item] = 0;
    }
    $totais_por_tipo[$tipo_item] += $item['total'];
}

// Dados padrão para campos que não existem no banco
$responsavel_tecnico = "Técnico Responsável";
$registro_profissional = "CREA/CRC/CFT";

// Gerar token para compartilhamento se não existe (apenas para usuários logados)
if (!$acesso_compartilhado && !$acesso_publico) {
    $stmt = $pdo->prepare("SELECT token FROM documentos_compartilhados WHERE tipo_documento = ? AND documento_id = ?");
    $stmt->execute([$tipo, $id]);
    $token_existente = $stmt->fetchColumn();
    
    if (!$token_existente) {
        $token_existente = bin2hex(random_bytes(16));
        $stmt = $pdo->prepare("INSERT INTO documentos_compartilhados (tipo_documento, documento_id, token, expira_em) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))");
        $stmt->execute([$tipo, $id, $token_existente]);
    }
    
    $link_compartilhamento = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . "?tipo=$tipo&id=$id&token=$token_existente";
} else {
    $link_compartilhamento = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . "?tipo=$tipo&id=$id&token=$token";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo . ' ' . $numero_doc; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --accent: #e74c3c;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #27ae60;
            --warning: #f39c12;
            --gray: #6c757d;
            --border: #e9ecef;
        }
        
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
        }
        
        body { 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            padding: 40px 20px;
            font-weight: 400;
        }
        
        .glass-container {
            max-width: 1200px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        /* Header Premium */
        .premium-header {
            background: linear-gradient(135deg, var(--primary), #34495e);
            color: white;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }
        
        .premium-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.05)"/></svg>');
            background-size: cover;
        }
        
        .header-content {
            position: relative;
            z-index: 2;
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 40px;
            align-items: start;
        }
        
        .company-brand {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        
        .logo-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }
        
        .logo-premium {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .logo-placeholder {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
            border: 4px solid rgba(255, 255, 255, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .company-text {
            flex: 1;
        }
        
        .company-name {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }
        
        .company-details {
            font-size: 14px;
            opacity: 0.9;
            line-height: 1.5;
        }
        
        .document-badge {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            min-width: 320px;
        }
        
        .document-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .document-number {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .document-dates {
            font-size: 14px;
            opacity: 0.9;
        }
        
        /* Códigos de Controle */
        .control-codes {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 20px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
        }
        
        .code-item {
            text-align: center;
        }
        
        .code-label {
            font-size: 11px;
            text-transform: uppercase;
            opacity: 0.8;
            margin-bottom: 5px;
        }
        
        .code-value {
            font-size: 14px;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .barcode-container {
            background: white;
            padding: 10px;
            border-radius: 8px;
            margin-top: 5px;
        }
        
        /* Status Badge */
        .status-premium {
            display: inline-flex;
            align-items: center;
            padding: 8px 20px;
            background: var(--success);
            color: white;
            border-radius: 25px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 10px;
        }
        
        /* Acesso Público Badge */
        .public-access-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            background: linear-gradient(135deg, #9b59b6, #8e44ad);
            color: white;
            border-radius: 15px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-left: 10px;
        }
        
        /* Content Sections */
        .content-section {
            padding: 30px 40px;
            border-bottom: 1px solid var(--border);
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-title::before {
            content: "";
            width: 4px;
            height: 20px;
            background: var(--secondary);
            border-radius: 2px;
        }
        
        /* Informações Expandidas */
        .info-grid-expanded {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .info-card-large {
            background: var(--light);
            padding: 20px;
            border-radius: 12px;
            border-left: 4px solid var(--secondary);
        }
        
        .info-label {
            font-size: 12px;
            font-weight: 600;
            color: var(--gray);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }
        
        .info-value {
            font-size: 15px;
            font-weight: 500;
            color: var(--dark);
        }
        
        /* Resumo Financeiro */
        .financial-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .financial-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            border: 1px solid var(--border);
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .financial-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--primary);
            margin: 10px 0;
        }
        
        .financial-label {
            font-size: 12px;
            color: var(--gray);
            text-transform: uppercase;
        }
        
        /* Premium Table */
        .premium-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 25px 0;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        
        .premium-table thead {
            background: linear-gradient(135deg, var(--primary), #34495e);
        }
        
        .premium-table th {
            padding: 18px 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .premium-table td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }
        
        .premium-table tbody tr {
            transition: all 0.3s ease;
        }
        
        .premium-table tbody tr:hover {
            background: rgba(52, 152, 219, 0.05);
            transform: translateY(-1px);
        }
        
        .premium-table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        
        /* Totals Section */
        .totals-section {
            background: var(--light);
            border-radius: 12px;
            padding: 25px;
            margin: 25px 0;
        }
        
        .total-line {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid var(--border);
        }
        
        .total-line:last-child {
            border-bottom: none;
        }
        
        .grand-total {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            background: linear-gradient(135deg, var(--secondary), #2980b9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        /* Observations */
        .observations-card {
            background: linear-gradient(135deg, #fff3cd, #ffeaa7);
            border-left: 4px solid var(--warning);
            border-radius: 12px;
            padding: 25px;
        }
        
        /* Footer Expandido */
        .premium-footer {
            background: var(--primary);
            color: white;
            padding: 30px 40px;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-section h4 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 15px;
            opacity: 0.9;
        }
        
        .footer-section p {
            font-size: 12px;
            opacity: 0.8;
            line-height: 1.5;
            margin-bottom: 8px;
        }
        
        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.2);
            padding-top: 20px;
            text-align: center;
        }
        
        .signature-area {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
            text-align: center;
        }
        
        .signature-line {
            width: 400px;
            border-bottom: 1px solid var(--gray);
            margin: 0 auto 10px;
            padding-top: 40px;
        }
        
        /* Action Buttons */
        .action-buttons {
            position: fixed;
            bottom: 30px;
            right: 30px;
            display: flex;
            gap: 15px;
            z-index: 1000;
        }
        
        .btn-premium {
            padding: 15px 25px;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        
        .btn-print {
            background: linear-gradient(135deg, var(--secondary), #2980b9);
            color: white;
        }
        
        .btn-close {
            background: linear-gradient(135deg, var(--accent), #c0392b);
            color: white;
        }
        
        .btn-share {
            background: linear-gradient(135deg, var(--success), #27ae60);
            color: white;
        }
        
        .btn-pdf {
            background: linear-gradient(135deg, #9b59b6, #8e44ad);
            color: white;
        }
        
        .btn-premium:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }
        
        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            transform: translateY(20px);
            transition: transform 0.3s ease;
        }
        
        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }
        
        .modal-header {
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
        }
        
        .form-input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 20px 0;
        }
        
        .checkbox-input {
            width: 18px;
            height: 18px;
        }
        
        .checkbox-label {
            font-size: 14px;
            color: var(--dark);
        }
        
        .signature-preview {
            margin: 20px 0;
            padding: 20px;
            background: var(--light);
            border-radius: 10px;
            text-align: center;
        }
        
        .signature-name {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .signature-details {
            font-size: 12px;
            color: var(--gray);
        }
        
        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 25px;
        }
        
        .btn-modal {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: var(--secondary);
            color: white;
        }
        
        .btn-secondary {
            background: var(--light);
            color: var(--dark);
        }
        
        /* Link compartilhamento */
        .share-link-container {
            background: var(--light);
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
        }
        
        .share-link {
            display: flex;
            gap: 10px;
        }
        
        .share-input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 14px;
            background: white;
        }
        
        .btn-copy {
            background: var(--secondary);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 0 15px;
            cursor: pointer;
            font-weight: 600;
        }
        
        /* Documento Fixo */
        .documento-fixo-badge {
            background: linear-gradient(135deg, var(--success), #27ae60);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-left: 10px;
        }
        
        /* Acesso Público Info */
        .public-access-info {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            border-left: 4px solid var(--secondary);
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            font-size: 14px;
        }
        
        /* Print Styles */
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .glass-container {
                box-shadow: none;
                border-radius: 0;
                border: none;
            }
            
            .action-buttons,
            .modal-overlay {
                display: none;
            }
            
            .premium-header {
                background: var(--primary) !important;
                -webkit-print-color-adjust: exact;
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 20px 10px;
            }
            
            .header-content {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .company-brand {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .document-badge {
                min-width: auto;
                width: 100%;
            }
            
            .control-codes {
                grid-template-columns: 1fr;
            }
            
            .footer-grid {
                grid-template-columns: 1fr;
            }
            
            .content-section {
                padding: 20px;
            }
            
            .action-buttons {
                position: static;
                justify-content: center;
                margin-top: 30px;
                flex-wrap: wrap;
            }
            
            .signature-line {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Modal de Compartilhamento -->
    <div class="modal-overlay" id="shareModal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Compartilhar Documento</div>
                <p>Compartilhe este documento online com seu cliente</p>
            </div>
            
            <div class="form-group">
                <label class="form-label">Link de Compartilhamento</label>
                <div class="share-link-container">
                    <div class="share-link">
                        <input type="text" class="share-input" id="shareLink" value="<?php echo $link_compartilhamento; ?>" readonly>
                        <button class="btn-copy" onclick="copiarLink()">Copiar</button>
                    </div>
                </div>
                <p style="font-size: 12px; color: var(--gray); margin-top: 10px;">
                    Este link expira em 30 dias e pode ser acessado <strong>sem necessidade de login</strong>.
                </p>
                
                <?php if ($tipo == 'os'): ?>
                <div class="public-access-info">
                    <strong>📋 Ordem de Serviço Pública</strong><br>
                    Seu cliente poderá visualizar esta OS, acompanhar o andamento e assinar digitalmente sem precisar fazer login no sistema.
                </div>
                <?php endif; ?>
            </div>
            
            <div class="modal-actions">
                <button class="btn-modal btn-secondary" onclick="fecharModal('shareModal')">Fechar</button>
            </div>
        </div>
    </div>
    
    <!-- Modal de Assinatura Digital -->
    <div class="modal-overlay" id="signatureModal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Assinatura Digital</div>
                <p>Confirme suas informações para assinar digitalmente</p>
            </div>
            
            <form id="signatureForm">
                <div class="form-group">
                    <label class="form-label">Nome Completo</label>
                    <input type="text" class="form-input" id="signatureName" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">E-mail</label>
                    <input type="email" class="form-input" id="signatureEmail" required>
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" class="checkbox-input" id="signatureAgreement" required>
                    <label class="checkbox-label">
                        Confirmo que li e concordo com os termos deste documento,  conforme a MP 2.200-2/2001 (ICP-Brasil), com validade jurídica e garantia de autenticidade e integridade.
                    </label>
                </div>
                
                <div class="signature-preview" id="signaturePreview" style="display: none;">
                    <div class="signature-name" id="previewName"></div>
                    <div class="signature-details">
                        Assinado digitalmente em <span id="previewDate"></span>
                    </div>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-modal btn-secondary" onclick="fecharModal('signatureModal')">Cancelar</button>
                    <button type="submit" class="btn-modal btn-primary">Assinar Digitalmente</button>
                </div>
            </form>
        </div>
    </div>

    <div class="action-buttons">
        <?php if (!$acesso_publico): ?>
            <?php if (!$acesso_compartilhado): ?>
                <button onclick="abrirModal('shareModal')" class="btn-premium btn-share">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
                        <polyline points="16 6 12 2 8 6"/>
                        <line x1="12" y1="2" x2="12" y2="15"/>
                    </svg>
                    Compartilhar
                </button>
                
                <?php if (!$documento_assinado): ?>
               
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="public-access-badge">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
                Acesso Público
            </div>
        <?php endif; ?>
        
        <button onclick="window.print()" class="btn-premium btn-print">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/>
                <path d="M6 14h12v8H6z"/>
            </svg>
            Imprimir
        </button>
        
        <?php if (($acesso_compartilhado || $acesso_publico) && empty($dados['assinatura_nome'])): ?>
            <button onclick="abrirModal('signatureModal')" class="btn-premium" style="background: linear-gradient(135deg, #f39c12, #e67e22); color: white;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M7 7h10"/>
                </svg>
                Assinar Digitalmente
            </button>
        <?php endif; ?>
        
        <button onclick="window.close()" class="btn-premium btn-close">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
            Fechar
        </button>

        <?php if ($documento_assinado): ?>
        <div class="documento-fixo-badge">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            Documento Fixo
        </div>
        <?php endif; ?>
    </div>

    <div class="glass-container" id="documentContent">
        <!-- Premium Header -->
        <div class="premium-header">
            <div class="header-content">
                <div class="company-brand">
                    <div class="logo-container">
                        <?php if (!empty($logo_url)): ?>
                            <img src="<?php echo $logo_url; ?>" class="logo-premium" alt="Logo <?php echo $dados['nome_empresa']; ?>" 
                                 onerror="this.style.display='none'; document.getElementById('logo-placeholder').style.display='flex';">
                        <?php endif; ?>
                        
                        <div id="logo-placeholder" class="logo-placeholder" style="<?php echo empty($logo_url) ? 'display: flex;' : 'display: none;'; ?>">
                            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
                            </svg>
                        </div>
                    </div>
                    
                    <div class="company-text">
                        <div class="company-name"><?php echo $dados['nome_empresa']; ?>
                            <?php if ($documento_assinado): ?>
                            <span class="documento-fixo-badge">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                                </svg>
                                ASSINADO E FIXADO
                            </span>
                            <?php endif; ?>
                            
                            <?php if ($acesso_publico): ?>
                            <span class="public-access-badge">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                                ACESSO PÚBLICO
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="company-details">
                            CNPJ: <?php echo $dados['empresa_cnpj']; ?> • 
                            <?php echo $dados['empresa_endereco']; ?> • 
                            Tel: <?php echo $dados['empresa_telefone']; ?><br>
                            Email: <?php echo $dados['empresa_email']; ?> • 
                            Responsável: <?php echo $responsavel_tecnico; ?>
                        </div>
                    </div>
                </div>
                
                <div class="document-badge">
                    <div class="document-title"><?php echo $titulo; ?></div>
                    <div class="document-number">Nº <?php echo $numero_doc; ?></div>
                    <div class="document-dates">
                        <div><?php echo $data_principal; ?></div>
                        <div><?php echo $data_secundaria; ?></div>
                    </div>
                    
                    <?php if ($tipo == 'os'): ?>
                        <div class="status-premium">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                                <polyline points="22 4 12 14.01 9 11.01"/>
                            </svg>
                            <?php echo $dados['status']; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($documento_assinado): ?>
                    <div class="status-premium" style="background: var(--success);">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                            <polyline points="22 4 12 14.01 9 11.01"/>
                        </svg>
                        DOCUMENTO ASSINADO DIGITALMENTE
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($acesso_publico): ?>
                    <div class="status-premium" style="background: linear-gradient(135deg, #9b59b6, #8e44ad);">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                        ACESSO PÚBLICO - SEM LOGIN
                    </div>
                    <?php endif; ?>
                    
                    <div class="control-codes">
                        <div class="code-item">
                            <div class="code-label">Código de Controle</div>
                            <div class="code-value"><?php echo $codigo_controle; ?></div>
                        </div>
                        <div class="code-item">
                            <div class="code-label">Código de Barras</div>
                            <div class="code-value"><?php echo $codigo_barras_numero; ?></div>
                            <div class="barcode-container">
                                <svg id="barcode"></svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Resumo Financeiro -->
        <div class="content-section">
            <div class="section-title">Resumo Financeiro</div>
            <div class="financial-summary">
                <div class="financial-card">
                    <div class="financial-label">Total de Itens</div>
                    <div class="financial-value"><?php echo count($itens_data); ?></div>
                    <div class="financial-label">itens listados</div>
                </div>
                <div class="financial-card">
                    <div class="financial-label">Subtotal</div>
                    <div class="financial-value">R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></div>
                    <div class="financial-label">valor bruto</div>
                </div>
                <?php if (($dados['desconto'] ?? 0) > 0): ?>
                <div class="financial-card">
                    <div class="financial-label">Desconto</div>
                    <div class="financial-value" style="color: var(--accent);">- R$ <?php echo number_format($dados['desconto'], 2, ',', '.'); ?></div>
                    <div class="financial-label">valor descontado</div>
                </div>
                <?php endif; ?>
                <div class="financial-card">
                    <div class="financial-label">Total Geral</div>
                    <div class="financial-value" style="color: var(--success);">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></div>
                    <div class="financial-label">valor final</div>
                </div>
            </div>
        </div>
        
        <!-- Informações do Cliente Expandidas -->
        <div class="content-section">
            <div class="section-title">Informações do Cliente</div>
            <div class="info-grid-expanded">
                <div class="info-card-large">
                    <div class="info-label">Dados Pessoais</div>
                    <div class="info-value"><?php echo $dados['cliente_nome']; ?></div>
                    <div class="info-value" style="font-size: 13px; margin-top: 5px;">CPF/CNPJ: <?php echo $dados['cpf_cnpj']; ?></div>
                </div>
                <div class="info-card-large">
                    <div class="info-label">Endereço Completo</div>
                    <div class="info-value"><?php echo $dados['endereco']; ?></div>
                    <div class="info-value" style="font-size: 13px; margin-top: 5px;"><?php echo $dados['cidade']; ?> - <?php echo $dados['estado']; ?></div>
                </div>
                <div class="info-card-large">
                    <div class="info-label">Contatos</div>
                    <div class="info-value">Telefone: <?php echo $dados['telefone']; ?></div>
                    <div class="info-value" style="font-size: 13px; margin-top: 5px;">Email: <?php echo $dados['email']; ?></div>
                </div>
            </div>
        </div>
        
        <!-- Equipment Information (OS only) -->
        <?php if ($tipo == 'os'): ?>
        <div class="content-section">
            <div class="section-title">Detalhes do Equipamento</div>
            <div class="info-grid-expanded">
                <div class="info-card-large">
                    <div class="info-label">Equipamento</div>
                    <div class="info-value"><?php echo $dados['equipamento']; ?></div>
                </div>
                <div class="info-card-large">
                    <div class="info-label">Modelo</div>
                    <div class="info-value"><?php echo $dados['modelo'] ?: 'Não informado'; ?></div>
                </div>
                <div class="info-card-large">
                    <div class="info-label">Número de Série</div>
                    <div class="info-value"><?php echo $dados['numero_serie'] ?: 'Não informado'; ?></div>
                </div>
                <div class="info-card-large" style="grid-column: 1 / -1;">
                    <div class="info-label">Defeito Relatado</div>
                    <div class="info-value"><?php echo nl2br($dados['defeito_relatado']); ?></div>
                </div>
                <?php if (!empty($dados['diagnostico_tecnico'])): ?>
                <div class="info-card-large" style="grid-column: 1 / -1;">
                    <div class="info-label">Diagnóstico Técnico</div>
                    <div class="info-value"><?php echo nl2br($dados['diagnostico_tecnico']); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Items Table -->
        <div class="content-section">
            <div class="section-title">Itens e Serviços Detalhados</div>
            <table class="premium-table">
                <thead>
                    <tr>
                        <th width="10%">Tipo</th>
                        <th width="45%">Descrição</th>
                        <th width="10%" class="text-center">Qtd</th>
                        <th width="15%" class="text-right">Preço Unitário</th>
                        <th width="20%" class="text-right">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($itens_data as $item): ?>
                    <tr>
                        <td style="font-weight: 600; color: var(--secondary);"><?php echo ucfirst($item['tipo']); ?></td>
                        <td><?php echo $item['descricao']; ?></td>
                        <td class="text-center"><?php echo $item['quantidade']; ?></td>
                        <td class="text-right">R$ <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?></td>
                        <td class="text-right" style="font-weight: 600;">R$ <?php echo number_format($item['total'], 2, ',', '.'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Resumo por Tipo -->
            <?php if (!empty($totais_por_tipo)): ?>
            <div style="margin-top: 20px; padding: 15px; background: var(--light); border-radius: 8px;">
                <div style="font-weight: 600; margin-bottom: 10px; color: var(--primary);">Resumo por Tipo:</div>
                <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                    <?php foreach ($totais_por_tipo as $tipo_item => $total): ?>
                    <div style="font-size: 13px;">
                        <span style="font-weight: 600;"><?php echo ucfirst($tipo_item); ?>:</span>
                        R$ <?php echo number_format($total, 2, ',', '.'); ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Totais -->
        <div class="content-section">
            <div class="totals-section">
                <div class="total-line">
                    <span>Subtotal</span>
                    <span>R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></span>
                </div>
                
                <?php if (($dados['desconto'] ?? 0) > 0): ?>
                <div class="total-line">
                    <span>Desconto</span>
                    <span style="color: var(--accent);">- R$ <?php echo number_format($dados['desconto'], 2, ',', '.'); ?></span>
                </div>
                <?php endif; ?>
                
                <div class="total-line" style="border-top: 2px solid var(--border); padding-top: 15px;">
                    <span class="grand-total">Total Geral</span>
                    <span class="grand-total">R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Assinatura Digital (se existir) -->
        <?php if (!empty($dados['assinatura_nome'])): ?>
        <div class="content-section">
            <div class="section-title">Assinatura Digital</div>
            <div class="signature-preview">
                <div class="signature-name"><?php echo $dados['assinatura_nome']; ?></div>
                <div class="signature-details">
                    Assinado digitalmente em <?php echo formatarData($dados['assinatura_data']); ?> • 
                    IP: <?php echo $dados['assinatura_ip']; ?> • 
                    Email: <?php echo $dados['assinatura_email']; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Observations -->
        <?php if (!empty($dados['observacoes'])): ?>
        <div class="content-section">
            <div class="observations-card">
                <div class="section-title">Observações e Condições</div>
                <div style="font-size: 14px; line-height: 1.6;">
                    <?php echo nl2br($dados['observacoes']); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Signature Area -->
        <div class="content-section">
            <div class="signature-area">
                <div class="signature-line"></div>
                <div style="font-size: 12px; color: var(--gray); margin-bottom: 20px;">
                    Assinatura do Responsável Técnico
                </div>
                <div style="font-size: 11px; color: var(--gray);">
                    <?php echo $responsavel_tecnico; ?> - 
                    <?php echo $registro_profissional; ?>
                </div>
            </div>
        </div>
        
        <!-- Footer Expandido -->
        <div class="premium-footer">
            <div class="footer-grid">
                <div class="footer-section">
                    <h4>Informações da Empresa</h4>
                    <p><strong><?php echo $dados['nome_empresa']; ?></strong></p>
                    <p>CNPJ: <?php echo $dados['empresa_cnpj']; ?></p>
                    <p><?php echo $dados['empresa_endereco']; ?></p>
                    <p>Tel: <?php echo $dados['empresa_telefone']; ?> | Email: <?php echo $dados['empresa_email']; ?></p>
                </div>
                
                <div class="footer-section">
                    <h4>Documento</h4>
                    <p><strong><?php echo $titulo; ?> Nº <?php echo $numero_doc; ?></strong></p>
                    <p>Código: <?php echo $codigo_controle; ?></p>
                    <p>Emitido em: <?php echo date('d/m/Y H:i:s'); ?></p>
                    <p>Valor: R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></p>
                </div>
                
                <div class="footer-section">
                    <h4>Controle</h4>
                    <p>Responsável: <?php echo $responsavel_tecnico; ?></p>
                    <p>Registro: <?php echo $registro_profissional; ?></p>
                    <p>Cliente: <?php echo $dados['cliente_nome']; ?></p>
                    <p>Documento válido e controlado</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p style="font-size: 11px; opacity: 0.7;">
                    Emitido via SmartMais Sistema de Gestão • 
                    <?php echo $dados['nome_empresa']; ?> • 
                    CNPJ: <?php echo $dados['empresa_cnpj']; ?> • 
                    Documento gerado automaticamente
                </p>
            </div>
        </div>
    </div>

    <script>
        // Variáveis globais para controle do documento
        const tipo = '<?php echo $tipo; ?>';
        const id = <?php echo $id; ?>;
        const documentoAssinado = <?php echo $documento_assinado ? 'true' : 'false'; ?>;
        const acessoPublico = <?php echo $acesso_publico ? 'true' : 'false'; ?>;

        // Gerenciamento do localStorage para documentos assinados
        function gerenciarStorageDocumento() {
            const chaveDocumento = `documento_${tipo}_${id}`;
            
            // Se o documento está assinado, remove do localStorage e marca como fixo
            if (documentoAssinado) {
                localStorage.removeItem(chaveDocumento);
                console.log('Documento assinado - removido do localStorage:', chaveDocumento);
            } else if (!acessoPublico) {
                // Se não está assinado e não é acesso público, salva no localStorage para rastreamento
                const dadosDocumento = {
                    tipo: '<?php echo $tipo; ?>',
                    id: <?php echo $id; ?>,
                    numero: '<?php echo $numero_doc; ?>',
                    cliente: '<?php echo $dados['cliente_nome']; ?>',
                    dataAcesso: new Date().toISOString(),
                    assinado: false
                };
                localStorage.setItem(chaveDocumento, JSON.stringify(dadosDocumento));
                console.log('Documento não assinado - salvo no localStorage:', chaveDocumento);
            }
        }

        function marcarDocumentoComoFixo() {
            // Adiciona indicador visual de documento fixo/assinado
            const actionButtons = document.querySelector('.action-buttons');
            if (actionButtons && !document.querySelector('.documento-fixo-badge')) {
                const badgeFixo = document.createElement('div');
                badgeFixo.className = 'documento-fixo-badge';
                badgeFixo.innerHTML = `
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    </svg>
                    Documento Fixo
                `;
                actionButtons.appendChild(badgeFixo);
            }
        }

        // Função para limpar documentos não assinados antigos do localStorage
        function limparDocumentosAntigos() {
            const umaSemanaAtras = new Date();
            umaSemanaAtras.setDate(umaSemanaAtras.getDate() - 7);
            
            for (let i = 0; i < localStorage.length; i++) {
                const chave = localStorage.key(i);
                if (chave && chave.startsWith('documento_')) {
                    try {
                        const dados = JSON.parse(localStorage.getItem(chave));
                        if (dados && !dados.assinado) {
                            const dataAcesso = new Date(dados.dataAcesso);
                            if (dataAcesso < umaSemanaAtras) {
                                localStorage.removeItem(chave);
                                console.log('Documento antigo removido:', chave);
                            }
                        }
                    } catch (e) {
                        // Se houver erro ao parsear, remove o item
                        localStorage.removeItem(chave);
                    }
                }
            }
        }

        // Função chamada quando o documento é assinado
        function onDocumentoAssinado() {
            const chaveDocumento = `documento_${tipo}_${id}`;
            
            // Remove do localStorage
            localStorage.removeItem(chaveDocumento);
            console.log('Documento assinado - removido do localStorage:', chaveDocumento);
            
            // Marca como fixo
            marcarDocumentoComoFixo();
            
            // Atualiza a interface
            const assinaturaBtn = document.querySelector('.btn-premium[onclick*="signatureModal"]');
            if (assinaturaBtn) {
                assinaturaBtn.style.display = 'none';
            }
            
            // Mostra mensagem de sucesso
            alert('Documento assinado com sucesso! Agora ele está fixo no sistema.');
        }

        // Gerar código de barras
        JsBarcode("#barcode", "<?php echo $codigo_barras_numero; ?>", {
            format: "CODE128",
            width: 2,
            height: 40,
            displayValue: true,
            fontSize: 12,
            margin: 5
        });
        
        // Funções para modais
        function abrirModal(modalId) {
            document.getElementById(modalId).classList.add('active');
        }
        
        function fecharModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        // Copiar link para área de transferência
        function copiarLink() {
            const linkInput = document.getElementById('shareLink');
            linkInput.select();
            linkInput.setSelectionRange(0, 99999);
            document.execCommand('copy');
            
            // Feedback visual
            const btn = document.querySelector('.btn-copy');
            const originalText = btn.textContent;
            btn.textContent = 'Copiado!';
            setTimeout(() => {
                btn.textContent = originalText;
            }, 2000);
        }
        
        // Gerar PDF
        function gerarPDF() {
            const element = document.getElementById('documentContent');
            const options = {
                margin: [10, 10, 10, 10],
                filename: '<?php echo $titulo . '_' . $numero_doc; ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            html2pdf().set(options).from(element).save();
        }
        
        // Preview da assinatura
        document.getElementById('signatureName').addEventListener('input', function() {
            const name = this.value;
            const preview = document.getElementById('signaturePreview');
            const previewName = document.getElementById('previewName');
            
            if (name.trim() !== '') {
                previewName.textContent = name;
                preview.style.display = 'block';
                
                // Atualizar data
                const now = new Date();
                document.getElementById('previewDate').textContent = 
                    now.toLocaleDateString('pt-BR') + ' às ' + now.toLocaleTimeString('pt-BR');
            } else {
                preview.style.display = 'none';
            }
        });
        
        // Envio do formulário de assinatura
        document.getElementById('signatureForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('signatureName').value;
            const email = document.getElementById('signatureEmail').value;
            const agreement = document.getElementById('signatureAgreement').checked;
            
            if (!agreement) {
                alert('Você precisa concordar com os termos para assinar o documento.');
                return;
            }
            
            // Enviar dados para o servidor
            const formData = new FormData();
            formData.append('tipo', '<?php echo $tipo; ?>');
            formData.append('id', '<?php echo $id; ?>');
            formData.append('nome', name);
            formData.append('email', email);
            formData.append('token', '<?php echo $token ?? ''; ?>');
            
            fetch('assinar_documento.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Chama a função para fixar o documento
                    onDocumentoAssinado();
                    
                    alert('Documento assinado com sucesso e fixado no sistema!');
                    fecharModal('signatureModal');
                    location.reload();
                } else {
                    alert('Erro ao assinar documento: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Erro:', error);
                alert('Erro ao processar assinatura.');
            });
        });
        
        // Fechar modal ao clicar fora
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        });
        
        // Inicialização quando a página carrega
        window.onload = function() {
            // Gerenciar storage do documento
            gerenciarStorageDocumento();
            
            // Limpar documentos antigos
            limparDocumentosAntigos();
            
            // Se o documento já está assinado, marca como fixo
            if (documentoAssinado) {
                marcarDocumentoComoFixo();
            }
            
            setTimeout(function() {
                // Auto-print apenas para usuários logados (não públicos)
                if (!acessoPublico) {
                    // window.print();
                }
            }, 1500);
        };
    </script>
</body>
</html>