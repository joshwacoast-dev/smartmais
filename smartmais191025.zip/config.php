<?php
// config.php - CORRIGIDO
session_start();

// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'nquxqpgi_construsis');
define('DB_USER', 'nquxqpgi_construsis');
define('DB_PASS', 'josue0500');

// Configurações do sistema
define('SISTEMA_NOME', 'SmartMais');
define('SISTEMA_VERSAO', '1.0');
define('BASE_URL', ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http") . "://$_SERVER[HTTP_HOST]".str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']));

// Conexão com o banco de dados
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

// Função para verificar login
function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header("Location: login.php");
        exit();
    }
}

// Função para verificar permissão
function temPermissao($codigo_permissao) {
    if (!isset($_SESSION['permissoes'])) {
        return false;
    }
    
    // Administrador tem todas as permissões
    if (isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'Administrador') {
        return true;
    }
    
    return in_array($codigo_permissao, $_SESSION['permissoes']);
}

// Função para carregar permissões do usuário
function carregarPermissoesUsuario($usuario_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT tipo_usuario, permissoes FROM usuarios WHERE id = ?");
    $stmt->execute([$usuario_id]);
    $usuario = $stmt->fetch();
    
    if ($usuario) {
        $_SESSION['usuario_tipo'] = $usuario['tipo_usuario'];
        $_SESSION['permissoes'] = json_decode($usuario['permissoes'], true) ?: [];
    }
}

// Função para gerar número único
function gerarNumeroUnico($prefixo) {
    return $prefixo . date('Ymd') . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
}

// Função para obter próximo número
function obterProximoNumero($tabela, $campo, $prefixo) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT $campo FROM $tabela WHERE $campo LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$prefixo . date('Ymd') . '%']);
    $ultimo = $stmt->fetch();
    
    if ($ultimo) {
        $numero = intval(substr($ultimo[$campo], -3)) + 1;
    } else {
        $numero = 1;
    }
    
    return $prefixo . date('Ymd') . str_pad($numero, 3, '0', STR_PAD_LEFT);
}

// Função para formatar moeda
function formatarMoeda($valor) {
    if (!$valor) return 'R$ 0,00';
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Função para formatar data
function formatarData($data, $formato = 'd/m/Y') {
    if (!$data || $data == '0000-00-00') return '';
    return date($formato, strtotime($data));
}

// Função para registrar log
function registrarLog($acao, $detalhes = '') {
    global $pdo;
    
    // Criar tabela de logs se não existir
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS logs (
            id INT PRIMARY KEY AUTO_INCREMENT,
            usuario_id INT,
            acao VARCHAR(255),
            detalhes TEXT,
            ip VARCHAR(45),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        if (isset($_SESSION['usuario_id'])) {
            $stmt = $pdo->prepare("INSERT INTO logs (usuario_id, acao, detalhes, ip) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['usuario_id'],
                $acao,
                $detalhes,
                $_SERVER['REMOTE_ADDR']
            ]);
        }
    } catch (Exception $e) {
        // Ignora erros de log para não quebrar o sistema
    }
}

// Carregar permissões se o usuário estiver logado
if (isset($_SESSION['usuario_id'])) {
    carregarPermissoesUsuario($_SESSION['usuario_id']);
}

// Adicionar cabeçalho para prevenir cache
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
?>