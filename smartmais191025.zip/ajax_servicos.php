<?php
include 'config.php';
verificarLogin();

if (isset($_GET['acao']) && $_GET['acao'] == 'buscar' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM servicos WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $servico = $stmt->fetch();
    
    if ($servico) {
        header('Content-Type: application/json');
        echo json_encode($servico);
    } else {
        http_response_code(404);
    }
    exit();
}
?>