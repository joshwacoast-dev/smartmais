<?php
include 'config.php';

if (isset($_GET['estado_id'])) {
    $estado_id = $_GET['estado_id'];
    
    // Buscar cidades do estado
    $stmt = $pdo->prepare("SELECT * FROM cidades WHERE estado_id = ? AND ativo = 1 ORDER BY nome");
    $stmt->execute([$estado_id]);
    $cidades = $stmt->fetchAll();
    
    if (empty($cidades)) {
        // Se não houver cidades, buscar via API do IBGE
        $cidades = buscarCidadesViaAPI($estado_id, $pdo);
    }
    
    echo json_encode($cidades);
}

function buscarCidadesViaAPI($estado_id, $pdo) {
    // Buscar UF do estado
    $stmt = $pdo->prepare("SELECT uf FROM estados WHERE id = ?");
    $stmt->execute([$estado_id]);
    $estado = $stmt->fetch();
    
    if ($estado) {
        $uf = $estado['uf'];
        
        // API do IBGE para buscar cidades
        $url = "https://servicodados.ibge.gov.br/api/v1/localidades/estados/{$uf}/municipios";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);
        
        $cidades_api = json_decode($response, true);
        $cidades = [];
        
        if (is_array($cidades_api)) {
            foreach ($cidades_api as $cidade_api) {
                $nome_cidade = $cidade_api['nome'];
                
                // Inserir no banco de dados
                $stmt = $pdo->prepare("INSERT INTO cidades (nome, estado_id) VALUES (?, ?)");
                $stmt->execute([$nome_cidade, $estado_id]);
                
                $cidades[] = [
                    'id' => $pdo->lastInsertId(),
                    'nome' => $nome_cidade,
                    'estado_id' => $estado_id
                ];
            }
        }
        
        return $cidades;
    }
    
    return [];
}
?>