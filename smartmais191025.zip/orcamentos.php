<?php
include 'config.php';
verificarLogin();

if (!temPermissao('orcamentos_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? 0;
$cliente_id = $_GET['cliente_id'] ?? 0;

// Processar formulário
if ($_POST) {
    $dados = $_POST;
    
    if ($dados['acao'] == 'adicionar' && temPermissao('orcamentos_editar')) {
        // Gerar número do orçamento
        $numero = obterProximoNumero('orcamentos', 'numero', 'ORC');
        
        $stmt = $pdo->prepare("INSERT INTO orcamentos (numero, cliente_id, data_emissao, valido_ate, observacoes, created_by) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $numero, $dados['cliente_id'], $dados['data_emissao'],
            $dados['valido_ate'], $dados['observacoes'], $_SESSION['usuario_id']
        ]);
        
        $orcamento_id = $pdo->lastInsertId();
        
        // Processar itens
        if (isset($dados['itens'])) {
            foreach ($dados['itens'] as $item) {
                if ($item['tipo'] && $item['quantidade'] > 0) {
                    $stmt = $pdo->prepare("INSERT INTO orcamento_itens (orcamento_id, tipo, item_id, quantidade, preco_unitario, total, descricao) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $orcamento_id, $item['tipo'], $item['item_id'],
                        $item['quantidade'], $item['preco_unitario'],
                        $item['total'], $item['descricao']
                    ]);
                }
            }
        }
        
        registrarLog('Criação de orçamento', 'Orçamento: ' . $numero);
        header("Location: orcamentos.php?sucesso=Orçamento criado com sucesso!" . ($cliente_id ? "&cliente_id=" . $cliente_id : ""));
        exit();
    }
    elseif ($dados['acao'] == 'editar' && temPermissao('orcamentos_editar')) {
        // Atualizar orçamento
        $stmt = $pdo->prepare("UPDATE orcamentos SET cliente_id = ?, data_emissao = ?, valido_ate = ?, observacoes = ? WHERE id = ?");
        $stmt->execute([
            $dados['cliente_id'], $dados['data_emissao'],
            $dados['valido_ate'], $dados['observacoes'], $dados['id']
        ]);
        
        // Remover itens antigos
        $stmt = $pdo->prepare("DELETE FROM orcamento_itens WHERE orcamento_id = ?");
        $stmt->execute([$dados['id']]);
        
        // Adicionar novos itens
        if (isset($dados['itens'])) {
            foreach ($dados['itens'] as $item) {
                if ($item['tipo'] && $item['quantidade'] > 0) {
                    $stmt = $pdo->prepare("INSERT INTO orcamento_itens (orcamento_id, tipo, item_id, quantidade, preco_unitario, total, descricao) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $dados['id'], $item['tipo'], $item['item_id'],
                        $item['quantidade'], $item['preco_unitario'],
                        $item['total'], $item['descricao']
                    ]);
                }
            }
        }
        
        registrarLog('Edição de orçamento', 'Orçamento ID: ' . $dados['id']);
        header("Location: orcamentos.php?sucesso=Orçamento atualizado com sucesso!" . ($cliente_id ? "&cliente_id=" . $cliente_id : ""));
        exit();
    }
    elseif ($dados['acao'] == 'excluir' && temPermissao('orcamentos_editar')) {
        // Buscar número do orçamento para o log
        $stmt = $pdo->prepare("SELECT numero FROM orcamentos WHERE id = ?");
        $stmt->execute([$dados['id']]);
        $orcamento = $stmt->fetch();
        
        // Excluir itens primeiro
        $stmt = $pdo->prepare("DELETE FROM orcamento_itens WHERE orcamento_id = ?");
        $stmt->execute([$dados['id']]);
        
        // Excluir orçamento
        $stmt = $pdo->prepare("DELETE FROM orcamentos WHERE id = ?");
        $stmt->execute([$dados['id']]);
        
        registrarLog('Exclusão de orçamento', 'Orçamento: ' . $orcamento['numero']);
        header("Location: orcamentos.php?sucesso=Orçamento excluído com sucesso!" . ($cliente_id ? "&cliente_id=" . $cliente_id : ""));
        exit();
    }
    elseif ($dados['acao'] == 'alterar_status' && temPermissao('orcamentos_aprovar')) {
        $stmt = $pdo->prepare("UPDATE orcamentos SET status = ? WHERE id = ?");
        $stmt->execute([$dados['status'], $dados['id']]);
        
        registrarLog('Alteração status orçamento', 'Orçamento ID: ' . $dados['id'] . ' - Status: ' . $dados['status']);
        header("Location: orcamentos.php?sucesso=Status do orçamento atualizado!" . ($cliente_id ? "&cliente_id=" . $cliente_id : ""));
        exit();
    }
}

// Buscar orçamentos
$status_filtro = $_GET['status'] ?? '';
$cliente_filtro = $_GET['cliente_id'] ?? '';
$where = "1=1";
$params = [];

if ($status_filtro) {
    $where .= " AND status = ?";
    $params[] = $status_filtro;
}

if ($cliente_filtro) {
    $where .= " AND cliente_id = ?";
    $params[] = $cliente_filtro;
}

$sql = "SELECT o.*, c.nome as cliente_nome 
        FROM orcamentos o 
        LEFT JOIN clientes c ON o.cliente_id = c.id 
        WHERE $where 
        ORDER BY o.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orcamentos = $stmt->fetchAll();

// Buscar clientes para select
$clientes = $pdo->query("SELECT id, nome FROM clientes WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Buscar produtos e serviços para itens
$produtos = $pdo->query("SELECT id, codigo, nome, preco_venda as preco FROM produtos WHERE ativo = 1 ORDER BY nome")->fetchAll();
$servicos = $pdo->query("SELECT id, codigo, nome, preco FROM servicos WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Buscar informações do cliente específico se estiver filtrando
$cliente_info = null;
if ($cliente_filtro) {
    $stmt = $pdo->prepare("SELECT id, nome FROM clientes WHERE id = ?");
    $stmt->execute([$cliente_filtro]);
    $cliente_info = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orçamentos - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1400px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 1px 3px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-info {
            background: #06b6d4;
            color: white;
            box-shadow: 0 1px 3px rgba(6, 182, 212, 0.3);
        }
        
        .btn-info:hover {
            background: #0891b2;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #64748b;
            color: white;
            box-shadow: 0 1px 3px rgba(100, 116, 139, 0.3);
        }
        
        .btn-secondary:hover {
            background: #475569;
            transform: translateY(-1px);
        }
        
        .btn-sm {
            padding: 6px 10px;
            font-size: 12px;
        }
        
        /* Formulários */
        .filters {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-info { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .badge-primary { 
            background: #e0e7ff; 
            color: #3730a3; 
            border: 1px solid #c7d2fe;
        }
        
        .badge-secondary { 
            background: #f3f4f6; 
            color: #374151; 
            border: 1px solid #e5e7eb;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        /* Formulário */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 24px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        .actions {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        
        .orc-number {
            font-family: 'Monaco', 'Consolas', monospace;
            font-weight: 700;
            color: #3b82f6;
            background: #eff6ff;
            padding: 4px 8px;
            border-radius: 6px;
            border: 1px solid #dbeafe;
        }
        
        .total-section {
            background: #f8fafc;
            padding: 24px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-top: 24px;
        }
        
        .total-display {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .item-row {
            display: grid;
            grid-template-columns: 120px 1fr 100px 120px 120px 1fr 60px;
            gap: 12px;
            align-items: end;
            margin-bottom: 16px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
        
        .item-row select, .item-row input {
            width: 100%;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        .cliente-filter-badge {
            background: #3b82f6;
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-left: 12px;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
            .item-row {
                grid-template-columns: 1fr;
                gap: 8px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
            
            .card-header {
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-header {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-file-invoice-dollar"></i> Orçamentos</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li class="active"><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
            
  
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2>
                        <i class="fas fa-file-invoice-dollar"></i> 
                        <?php if ($cliente_info): ?>
                            Orçamentos do Cliente: 
                            <span class="cliente-filter-badge">
                                <i class="fas fa-user"></i>
                                <?php echo htmlspecialchars($cliente_info['nome']); ?>
                            </span>
                        <?php else: ?>
                            Lista de Orçamentos
                        <?php endif; ?>
                    </h2>
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <?php if ($cliente_info): ?>
                            <a href="orcamentos.php" class="btn btn-secondary" title="Ver todos os orçamentos">
                                <i class="fas fa-times"></i> Limpar Filtro
                            </a>
                        <?php endif; ?>
                        <?php if (temPermissao('orcamentos_editar')): ?>
                        <button onclick="abrirModal()" class="btn btn-success">
                            <i class="fas fa-plus"></i> Novo Orçamento
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="card-body">
                    <div class="filters">
                        <select id="statusFilter" class="form-control" style="width: auto;" onchange="filtrarOrcamentos()">
                            <option value="">Todos os status</option>
                            <option value="Pendente" <?php echo $status_filtro == 'Pendente' ? 'selected' : ''; ?>>Pendentes</option>
                            <option value="Aprovado" <?php echo $status_filtro == 'Aprovado' ? 'selected' : ''; ?>>Aprovados</option>
                            <option value="Rejeitado" <?php echo $status_filtro == 'Rejeitado' ? 'selected' : ''; ?>>Rejeitados</option>
                            <option value="Expirado" <?php echo $status_filtro == 'Expirado' ? 'selected' : ''; ?>>Expirados</option>
                        </select>
                        
                        <?php if (!$cliente_info): ?>
                        <select id="clienteFilter" class="form-control" style="width: auto;" onchange="filtrarPorCliente()">
                            <option value="">Todos os clientes</option>
                            <?php foreach ($clientes as $cli): ?>
                            <option value="<?php echo $cli['id']; ?>" <?php echo $cliente_filtro == $cli['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cli['nome']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <?php endif; ?>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Número</th>
                                    <th>Cliente</th>
                                    <th>Data Emissão</th>
                                    <th>Validade</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orcamentos as $orc): ?>
                                <tr>
                                    <td>
                                        <span class="orc-number"><?php echo $orc['numero']; ?></span>
                                    </td>
                                    <td>
                                        <div style="font-weight: 600; color: #1e293b;">
                                            <?php echo htmlspecialchars($orc['cliente_nome']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="font-weight: 500; color: #374151;">
                                            <?php echo formatarData($orc['data_emissao']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="font-weight: 500; color: #374151;">
                                            <?php echo formatarData($orc['valido_ate']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="font-weight: 700; color: #059669;">
                                            <?php 
                                            // Calcular total do orçamento somando os itens
                                            $stmt = $pdo->prepare("SELECT SUM(total) as total FROM orcamento_itens WHERE orcamento_id = ?");
                                            $stmt->execute([$orc['id']]);
                                            $total = $stmt->fetch()['total'] ?? 0;
                                            echo formatarMoeda($total);
                                            ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge 
                                            <?php echo $orc['status'] == 'Aprovado' ? 'badge-success' : 
                                                  ($orc['status'] == 'Rejeitado' ? 'badge-danger' : 
                                                  ($orc['status'] == 'Expirado' ? 'badge-secondary' : 'badge-warning')); ?>">
                                            <i class="fas fa-<?php echo $orc['status'] == 'Aprovado' ? 'check' : 
                                                             ($orc['status'] == 'Rejeitado' ? 'times' : 
                                                             ($orc['status'] == 'Expirado' ? 'clock' : 'hourglass-half')); ?>"></i>
                                            <?php echo $orc['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <a href="gerar_pdf.php?tipo=orcamento&id=<?php echo $orc['id']; ?>" class="btn btn-info btn-sm" target="_blank" title="Imprimir">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            
                                            <!-- BOTÕES DE EDITAR E EXCLUIR - AGORA APARECEM EM QUALQUER STATUS -->
                                            <?php if (temPermissao('orcamentos_editar')): ?>
                                            <button onclick="editarOrcamento(<?php echo $orc['id']; ?>)" class="btn btn-warning btn-sm" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button onclick="excluirOrcamento(<?php echo $orc['id']; ?>)" class="btn btn-danger btn-sm" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if (temPermissao('orcamentos_aprovar') && $orc['status'] == 'Pendente'): ?>
                                            <button onclick="aprovarOrcamento(<?php echo $orc['id']; ?>)" class="btn btn-success btn-sm" title="Aprovar">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button onclick="rejeitarOrcamento(<?php echo $orc['id']; ?>)" class="btn btn-danger btn-sm" title="Rejeitar">
                                                <i class="fas fa-times"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if (temPermissao('os_editar') && $orc['status'] == 'Aprovado'): ?>
                                            <a href="ordens_servico.php?acao=nova&orcamento_id=<?php echo $orc['id']; ?><?php echo $cliente_filtro ? '&cliente_id=' . $cliente_filtro : ''; ?>" class="btn btn-primary btn-sm" title="Criar OS">
                                                <i class="fas fa-tools"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($orcamentos)): ?>
                                <tr>
                                    <td colspan="7">
                                        <div class="empty-state">
                                            <i class="fas fa-file-invoice-dollar"></i>
                                            <h3>Nenhum orçamento encontrado</h3>
                                            <p><?php echo $cliente_info ? 'Este cliente ainda não possui orçamentos.' : 'Comece criando seu primeiro orçamento'; ?></p>
                                            <?php if (temPermissao('orcamentos_editar')): ?>
                                            <button onclick="abrirModal()" class="btn btn-success" style="margin-top: 16px;">
                                                <i class="fas fa-plus"></i> Criar Orçamento
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Modal Orçamento -->
    <div id="modalOrcamento" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus-circle"></i> <span id="modalTitulo">Novo Orçamento</span></h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formOrcamento" method="POST">
                    <input type="hidden" name="acao" id="formAcao" value="adicionar">
                    <input type="hidden" name="id" id="orcamentoId" value="">
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-user"></i> Informações do Cliente</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Cliente</label>
                                <select name="cliente_id" id="cliente_id" class="form-control" required>
                                    <option value="">Selecione um cliente</option>
                                    <?php foreach ($clientes as $cli): ?>
                                    <option value="<?php echo $cli['id']; ?>" <?php echo ($cliente_id == $cli['id'] || $cliente_filtro == $cli['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cli['nome']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Data de Emissão</label>
                                <input type="date" name="data_emissao" id="data_emissao" class="form-control" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Válido Até</label>
                                <input type="date" name="valido_ate" id="valido_ate" class="form-control" 
                                       value="<?php echo date('Y-m-d', strtotime('+15 days')); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-shopping-cart"></i> Itens do Orçamento</h3>
                        
                        <div id="itensContainer">
                            <div class="item-row">
                                <div class="form-group">
                                    <label>Tipo</label>
                                    <select name="itens[0][tipo]" class="item-tipo form-control" onchange="carregarItens(this, 0)" required>
                                        <option value="">Tipo</option>
                                        <option value="produto">Produto</option>
                                        <option value="servico">Serviço</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Item</label>
                                    <select name="itens[0][item_id]" class="item-select form-control" required onchange="atualizarPreco(this, 0)">
                                        <option value="">Selecione...</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Qtd</label>
                                    <input type="number" name="itens[0][quantidade]" class="item-quantidade form-control" value="1" min="1" step="0.01" onchange="calcularTotal(0)" required>
                                </div>
                                <div class="form-group">
                                    <label>Preço Unit.</label>
                                    <input type="text" name="itens[0][preco_unitario]" class="item-preco form-control money" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Total</label>
                                    <input type="text" name="itens[0][total]" class="item-total form-control money" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Descrição</label>
                                    <input type="text" name="itens[0][descricao]" class="item-descricao form-control" placeholder="Descrição">
                                </div>
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="button" class="btn btn-danger" onclick="removerItem(this)" style="background: #ef4444;">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <button type="button" class="btn btn-primary" onclick="adicionarItem()">
                            <i class="fas fa-plus"></i> Adicionar Item
                        </button>

                        <div class="total-section">
                            <div class="total-display">
                                <span>Total do Orçamento:</span>
                                <span id="totalGeral" style="color: #059669;">R$ 0,00</span>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-sticky-note"></i> Observações</h3>
                        
                        <div class="form-group">
                            <textarea name="observacoes" id="observacoes" class="form-control" rows="3" 
                                      placeholder="Observações adicionais sobre o orçamento"></textarea>
                        </div>
                    </div>

                    <div style="margin-top: 32px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <button type="button" onclick="fecharModal()" class="btn btn-secondary" style="margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <span id="btnSalvarTexto">Salvar Orçamento</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        let itemCount = 1;
        const produtos = <?php echo json_encode($produtos); ?>;
        const servicos = <?php echo json_encode($servicos); ?>;

        function abrirModal() {
            document.getElementById('modalOrcamento').style.display = 'block';
            document.getElementById('modalTitulo').textContent = 'Novo Orçamento';
            document.getElementById('formAcao').value = 'adicionar';
            document.getElementById('btnSalvarTexto').textContent = 'Salvar Orçamento';
            document.getElementById('formOrcamento').reset();
            document.getElementById('orcamentoId').value = '';
            
            // Limpa os itens
            document.getElementById('itensContainer').innerHTML = `
                <div class="item-row">
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="itens[0][tipo]" class="item-tipo form-control" onchange="carregarItens(this, 0)" required>
                            <option value="">Tipo</option>
                            <option value="produto">Produto</option>
                            <option value="servico">Serviço</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Item</label>
                        <select name="itens[0][item_id]" class="item-select form-control" required onchange="atualizarPreco(this, 0)">
                            <option value="">Selecione...</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Qtd</label>
                        <input type="number" name="itens[0][quantidade]" class="item-quantidade form-control" value="1" min="1" step="0.01" onchange="calcularTotal(0)" required>
                    </div>
                    <div class="form-group">
                        <label>Preço Unit.</label>
                        <input type="text" name="itens[0][preco_unitario]" class="item-preco form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="itens[0][total]" class="item-total form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Descrição</label>
                        <input type="text" name="itens[0][descricao]" class="item-descricao form-control" placeholder="Descrição">
                    </div>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" class="btn btn-danger" onclick="removerItem(this)" style="background: #ef4444;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            itemCount = 1;
            calcularTotalGeral();
            
            // Pre-selecionar cliente se veio de um cliente específico
            <?php if ($cliente_filtro): ?>
            document.getElementById('cliente_id').value = '<?php echo $cliente_filtro; ?>';
            <?php endif; ?>
            
            // Define datas padrão
            const hoje = new Date().toISOString().split('T')[0];
            const quinzeDias = new Date();
            quinzeDias.setDate(quinzeDias.getDate() + 15);
            const quinzeDiasStr = quinzeDias.toISOString().split('T')[0];
            
            document.getElementById('data_emissao').value = hoje;
            document.getElementById('valido_ate').value = quinzeDiasStr;
        }

        function editarOrcamento(id) {
            // Carrega os dados do orçamento
            fetch(`carregar_orcamento.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        abrirModalEdicao(data.orcamento, data.itens);
                    } else {
                        alert('Erro ao carregar orçamento: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao carregar orçamento');
                });
        }

        function abrirModalEdicao(orcamento, itens) {
            document.getElementById('modalOrcamento').style.display = 'block';
            document.getElementById('modalTitulo').textContent = 'Editar Orçamento';
            document.getElementById('formAcao').value = 'editar';
            document.getElementById('orcamentoId').value = orcamento.id;
            document.getElementById('btnSalvarTexto').textContent = 'Atualizar Orçamento';
            
            // Preenche os dados do formulário
            document.getElementById('cliente_id').value = orcamento.cliente_id;
            document.getElementById('data_emissao').value = orcamento.data_emissao;
            document.getElementById('valido_ate').value = orcamento.valido_ate;
            document.getElementById('observacoes').value = orcamento.observacoes || '';
            
            // Limpa e preenche os itens
            document.getElementById('itensContainer').innerHTML = '';
            itemCount = 0;
            
            if (itens.length === 0) {
                adicionarItem();
            } else {
                itens.forEach((item, index) => {
                    adicionarItem();
                    const row = document.querySelectorAll('.item-row')[index];
                    
                    // Define o tipo e carrega os itens
                    row.querySelector('.item-tipo').value = item.tipo;
                    carregarItens(row.querySelector('.item-tipo'), index);
                    
                    // Timeout para garantir que os selects sejam carregados
                    setTimeout(() => {
                        row.querySelector('.item-select').value = item.item_id;
                        row.querySelector('.item-quantidade').value = item.quantidade;
                        row.querySelector('.item-preco').value = item.preco_unitario;
                        row.querySelector('.item-total').value = item.total;
                        row.querySelector('.item-descricao').value = item.descricao || '';
                        
                        calcularTotal(index);
                    }, 100);
                });
            }
            
            calcularTotalGeral();
        }

        function excluirOrcamento(id) {
            if (confirm('Tem certeza que deseja excluir este orçamento?\n\nEsta ação não pode ser desfeita.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function filtrarOrcamentos() {
            const status = document.getElementById('statusFilter').value;
            let url = 'orcamentos.php';
            const params = [];
            
            if (status) {
                params.push('status=' + encodeURIComponent(status));
            }
            
            <?php if ($cliente_filtro): ?>
            params.push('cliente_id=<?php echo $cliente_filtro; ?>');
            <?php endif; ?>
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }

        function filtrarPorCliente() {
            const cliente = document.getElementById('clienteFilter').value;
            const status = document.getElementById('statusFilter').value;
            
            let url = 'orcamentos.php';
            const params = [];
            
            if (cliente) {
                params.push('cliente_id=' + encodeURIComponent(cliente));
            }
            
            if (status) {
                params.push('status=' + encodeURIComponent(status));
            }
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            window.location.href = url;
        }

        function aprovarOrcamento(id) {
            if (confirm('Deseja aprovar este orçamento?\n\nEsta ação não pode ser desfeita.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="alterar_status">
                    <input type="hidden" name="id" value="${id}">
                    <input type="hidden" name="status" value="Aprovado">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function rejeitarOrcamento(id) {
            if (confirm('Deseja rejeitar este orçamento?\n\nEsta ação não pode ser desfeita.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="alterar_status">
                    <input type="hidden" name="id" value="${id}">
                    <input type="hidden" name="status" value="Rejeitado">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Funções para itens
        function adicionarItem() {
            const html = `
                <div class="item-row">
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="itens[${itemCount}][tipo]" class="item-tipo form-control" onchange="carregarItens(this, ${itemCount})" required>
                            <option value="">Tipo</option>
                            <option value="produto">Produto</option>
                            <option value="servico">Serviço</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Item</label>
                        <select name="itens[${itemCount}][item_id]" class="item-select form-control" required onchange="atualizarPreco(this, ${itemCount})">
                            <option value="">Selecione...</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Qtd</label>
                        <input type="number" name="itens[${itemCount}][quantidade]" class="item-quantidade form-control" value="1" min="1" step="0.01" onchange="calcularTotal(${itemCount})" required>
                    </div>
                    <div class="form-group">
                        <label>Preço Unit.</label>
                        <input type="text" name="itens[${itemCount}][preco_unitario]" class="item-preco form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="itens[${itemCount}][total]" class="item-total form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Descrição</label>
                        <input type="text" name="itens[${itemCount}][descricao]" class="item-descricao form-control" placeholder="Descrição">
                    </div>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" class="btn btn-danger" onclick="removerItem(this)" style="background: #ef4444;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            document.getElementById('itensContainer').insertAdjacentHTML('beforeend', html);
            itemCount++;
        }

        function carregarItens(select, index) {
            const tipo = select.value;
            const itemSelect = select.parentNode.parentNode.querySelector('.item-select');
            itemSelect.innerHTML = '<option value="">Selecione...</option>';
            
            const itens = tipo === 'produto' ? produtos : servicos;
            itens.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = `${item.codigo} - ${item.nome} (${formatarMoeda(item.preco)})`;
                option.setAttribute('data-preco', item.preco);
                option.setAttribute('data-descricao', item.nome);
                itemSelect.appendChild(option);
            });
        }

        function atualizarPreco(select, index) {
            const selectedOption = select.options[select.selectedIndex];
            const preco = selectedOption.getAttribute('data-preco');
            const descricao = selectedOption.getAttribute('data-descricao');
            
            const row = select.parentNode.parentNode;
            row.querySelector('.item-preco').value = preco;
            row.querySelector('.item-descricao').value = descricao;
            
            calcularTotal(index);
        }

        function calcularTotal(index) {
            const rows = document.querySelectorAll('.item-row');
            const row = rows[index];
            const quantidade = parseFloat(row.querySelector('.item-quantidade').value) || 0;
            const preco = parseFloat(row.querySelector('.item-preco').value) || 0;
            const total = quantidade * preco;
            
            row.querySelector('.item-total').value = total.toFixed(2);
            calcularTotalGeral();
        }

        function calcularTotalGeral() {
            let totalGeral = 0;
            document.querySelectorAll('.item-total').forEach(input => {
                totalGeral += parseFloat(input.value) || 0;
            });
            document.getElementById('totalGeral').textContent = formatarMoeda(totalGeral);
        }

        function removerItem(button) {
            if (document.querySelectorAll('.item-row').length > 1) {
                button.parentNode.parentNode.remove();
                calcularTotalGeral();
            }
        }

        function formatarMoeda(valor) {
            return 'R$ ' + parseFloat(valor).toLocaleString('pt-BR', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalOrcamento');
            if (event.target === modal) {
                fecharModal();
            }
        }

        function fecharModal() {
            document.getElementById('modalOrcamento').style.display = 'none';
        }

        // CORREÇÃO DAS MÁSCARAS DE PREÇO
        document.addEventListener('DOMContentLoaded', function() {
            // Função para formatar valores monetários
            function formatarValorMonetario(valor) {
                // Remove tudo que não é número
                let valorNumerico = valor.replace(/\D/g, '');
                
                // Se estiver vazio, retorna 0
                if (valorNumerico === '') return '0,00';
                
                // Adiciona zeros à esquerda para garantir pelo menos 3 dígitos
                while (valorNumerico.length < 3) {
                    valorNumerico = '0' + valorNumerico;
                }
                
                // Separa reais e centavos
                const centavos = valorNumerico.slice(-2);
                const reais = valorNumerico.slice(0, -2) || '0';
                
                // Formata os reais com separadores de milhar
                const reaisFormatado = reais.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                
                return reaisFormatado + ',' + centavos;
            }

            // Aplica a máscara aos inputs de moeda
            document.querySelectorAll('.money').forEach(input => {
                // Formata o valor inicial se existir
                if (input.value && !isNaN(parseFloat(input.value))) {
                    input.value = formatarValorMonetario(input.value);
                }

                // Evento de input para formatação em tempo real
                input.addEventListener('input', function(e) {
                    const cursorPosition = e.target.selectionStart;
                    const valorOriginal = e.target.value;
                    
                    // Aplica a formatação
                    e.target.value = formatarValorMonetario(valorOriginal);
                    
                    // Mantém a posição do cursor
                    const novoCursorPosition = cursorPosition + (e.target.value.length - valorOriginal.length);
                    e.target.setSelectionRange(novoCursorPosition, novoCursorPosition);
                });

                // Evento de blur para garantir formatação correta
                input.addEventListener('blur', function(e) {
                    if (e.target.value) {
                        e.target.value = formatarValorMonetario(e.target.value);
                    }
                });
            });
        });
    </script>
</body>
</html>