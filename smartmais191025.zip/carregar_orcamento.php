<?php
include 'config.php';
verificarLogin();

if (!temPermissao('orcamentos_visualizar')) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Sem permissão']);
    exit();
}

$id = $_GET['id'] ?? 0;

if ($id > 0) {
    // Buscar orçamento
    $stmt = $pdo->prepare("SELECT * FROM orcamentos WHERE id = ?");
    $stmt->execute([$id]);
    $orcamento = $stmt->fetch();
    
    if ($orcamento) {
        // Buscar itens do orçamento
        $stmt = $pdo->prepare("SELECT * FROM orcamento_itens WHERE orcamento_id = ?");
        $stmt->execute([$id]);
        $itens = $stmt->fetchAll();
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'orcamento' => $orcamento,
            'itens' => $itens
        ]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Orçamento não encontrado']);
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
}