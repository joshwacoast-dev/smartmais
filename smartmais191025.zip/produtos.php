<?php
include 'config.php';
verificarLogin();

if (!temPermissao('produtos_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? 0;

// Limpar itens da nota fiscal se solicitado
if (isset($_GET['limpar_nota'])) {
    unset($_SESSION['itens_nota_fiscal']);
    header("Location: produtos.php");
    exit();
}

// Função para converter valor monetário do formato brasileiro para decimal
function converterMoedaParaDecimal($valor) {
    if (empty($valor) || $valor === 'R$ 0,00') return 0;
    
    // Remove "R$" e espaços
    $valor = str_replace(['R$', ' '], '', $valor);
    
    // Remove pontos (separadores de milhar)
    $valor = str_replace('.', '', $valor);
    
    // Substitui vírgula por ponto para formato decimal
    $valor = str_replace(',', '.', $valor);
    
    return floatval($valor);
}

// Processar formulário
if ($_POST) {
    $dados = $_POST;
    
    if (isset($dados['cadastrar_itens_nota'])) {
        // Processar cadastro dos itens da nota fiscal
        if (temPermissao('produtos_editar')) {
            $itens_cadastrar = $dados['itens_cadastrar'] ?? [];
            $itens_nota = $_SESSION['itens_nota_fiscal'] ?? [];
            $percentual_acrescimo = floatval($dados['percentual_acrescimo'] ?? 0) / 100;
            
            $sucessos = 0;
            $erros = 0;
            
            foreach ($itens_cadastrar as $index) {
                if (isset($itens_nota[$index])) {
                    $item = $itens_nota[$index];
                    
                    // Gerar código automático se não existir
                    $codigo = $item['codigo'] ?? 'NF' . date('YmdHis') . $index;
                    
                    // Verificar se o código já existe
                    $stmt_check = $pdo->prepare("SELECT id FROM produtos WHERE codigo = ?");
                    $stmt_check->execute([$codigo]);
                    if ($stmt_check->fetch()) {
                        $codigo = $codigo . '_' . $index;
                    }
                    
                    $stmt = $pdo->prepare("INSERT INTO produtos (codigo, nome, descricao, preco_custo, preco_venda, estoque, unidade, categoria, marca, fornecedor) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    $preco_custo = floatval($item['preco'] ?? 0);
                    $preco_venda = $preco_custo * (1 + $percentual_acrescimo);
                    
                    $result = $stmt->execute([
                        $codigo,
                        $item['nome'] ?? 'Produto sem nome',
                        $item['descricao'] ?? '',
                        $preco_custo,
                        $preco_venda,
                        $item['quantidade'] ?? 1,
                        $item['unidade'] ?? 'UN',
                        $item['categoria'] ?? 'Nota Fiscal',
                        $item['marca'] ?? '',
                        $item['fornecedor'] ?? ''
                    ]);
                    
                    if ($result) {
                        $sucessos++;
                    } else {
                        $erros++;
                    }
                }
            }
            
            unset($_SESSION['itens_nota_fiscal']);
            
            if ($sucessos > 0) {
                registrarLog('Cadastro automático de produtos via nota fiscal', $sucessos . ' produtos cadastrados');
                header("Location: produtos.php?sucesso=" . $sucessos . " produtos cadastrados automaticamente da nota fiscal!");
            } else {
                header("Location: produtos.php?erro=Nenhum produto pôde ser cadastrado.");
            }
            exit();
        }
    }
    
    // REMOVIDA A VALIDAÇÃO OBRIGATÓRIA DA CATEGORIA
    if ($dados['acao'] == 'adicionar' && temPermissao('produtos_editar')) {
        $preco_custo = converterMoedaParaDecimal($dados['preco_custo'] ?? '');
        $preco_venda = converterMoedaParaDecimal($dados['preco_venda'] ?? '');
        
        $stmt = $pdo->prepare("INSERT INTO produtos (codigo, nome, descricao, preco_custo, preco_venda, estoque, estoque_minimo, unidade, categoria, marca, fornecedor) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $result = $stmt->execute([
            $dados['codigo'], 
            $dados['nome'], 
            $dados['descricao'] ?? '', 
            $preco_custo,
            $preco_venda,
            $dados['estoque'] ?? 0, 
            $dados['estoque_minimo'] ?? 0, 
            $dados['unidade'] ?? 'UN',
            trim($dados['categoria'] ?? ''),
            $dados['marca'] ?? '',
            $dados['fornecedor'] ?? ''
        ]);
        
        if ($result) {
            registrarLog('Cadastro de produto', 'Produto: ' . $dados['nome']);
            header("Location: produtos.php?sucesso=Produto cadastrado com sucesso!");
        } else {
            header("Location: produtos.php?erro=Erro ao cadastrar produto!");
        }
        exit();
    }
    elseif ($dados['acao'] == 'editar' && temPermissao('produtos_editar')) {
        $preco_custo = converterMoedaParaDecimal($dados['preco_custo'] ?? '');
        $preco_venda = converterMoedaParaDecimal($dados['preco_venda'] ?? '');
        
        $stmt = $pdo->prepare("UPDATE produtos SET codigo=?, nome=?, descricao=?, preco_custo=?, preco_venda=?, estoque=?, estoque_minimo=?, unidade=?, categoria=?, marca=?, fornecedor=?, ativo=? WHERE id=?");
        $result = $stmt->execute([
            $dados['codigo'], 
            $dados['nome'], 
            $dados['descricao'] ?? '',
            $preco_custo,
            $preco_venda,
            $dados['estoque'] ?? 0, 
            $dados['estoque_minimo'] ?? 0, 
            $dados['unidade'] ?? 'UN',
            trim($dados['categoria'] ?? ''),
            $dados['marca'] ?? '',
            $dados['fornecedor'] ?? '',
            $dados['ativo'] ?? 1, 
            $dados['id']
        ]);
        
        if ($result) {
            registrarLog('Edição de produto', 'Produto ID: ' . $dados['id']);
            header("Location: produtos.php?sucesso=Produto atualizado com sucesso!");
        } else {
            header("Location: produtos.php?erro=Erro ao atualizar produto!");
        }
        exit();
    }
    elseif ($dados['acao'] == 'excluir' && temPermissao('produtos_excluir')) {
        $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
        $result = $stmt->execute([$dados['id']]);
        
        if ($result) {
            registrarLog('Exclusão definitiva de produto', 'Produto ID: ' . $dados['id']);
            header("Location: produtos.php?sucesso=Produto excluído com sucesso!");
        } else {
            header("Location: produtos.php?erro=Erro ao excluir produto!");
        }
        exit();
    }
}

// Processar upload de nota fiscal
if (isset($_FILES['nota_fiscal']) && $_FILES['nota_fiscal']['error'] === UPLOAD_ERR_OK) {
    if (temPermissao('produtos_editar')) {
        $arquivo = $_FILES['nota_fiscal'];
        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        
        if (in_array($extensao, ['txt', 'xml', 'csv'])) {
            $conteudo = file_get_contents($arquivo['tmp_name']);
            $itens_nota = processarNotaFiscal($conteudo, $extensao);
            
            if (!empty($itens_nota)) {
                $_SESSION['itens_nota_fiscal'] = $itens_nota;
                header("Location: produtos.php?sucesso=" . count($itens_nota) . " itens encontrados na nota fiscal. Revise e confirme o cadastro.");
            } else {
                header("Location: produtos.php?erro=Nenhum item válido encontrado na nota fiscal.");
            }
        } else {
            header("Location: produtos.php?erro=Formato de arquivo não suportado. Use TXT, XML ou CSV.");
        }
        exit();
    }
}

// Função para processar nota fiscal - MELHORADA PARA LER NFC-e, DANFE SAT E OUTROS FORMATOS
function processarNotaFiscal($conteudo, $tipo) {
    $itens = [];
    
    if ($tipo === 'txt') {
        $linhas = explode("\n", $conteudo);
        $cabecalho_encontrado = false;
        
        foreach ($linhas as $linha) {
            $linha = trim($linha);
            if (empty($linha)) continue;
            
            // Verificar se é cabeçalho com SKU | DESCRIÇÃO | UN | QTD | PREÇO_UNIT (BRL) | TOTAL (BRL)
            if (preg_match('/(SKU|CÓDIGO|COD).*DESCRIÇÃO.*(UN|UNID).*(QTD|QUANT).*PREÇO.*TOTAL/i', $linha)) {
                $cabecalho_encontrado = true;
                continue;
            }
            
            if ($cabecalho_encontrado) {
                // Tentar padrão com separadores | ou ;
                if (preg_match('/^([^|;]+)[|;]([^|;]+)[|;]([^|;]+)[|;]([^|;]+)[|;]([^|;]+)[|;]([^|;]+)$/', $linha, $matches)) {
                    $itens[] = [
                        'codigo' => trim($matches[1]),
                        'nome' => trim($matches[2]),
                        'unidade' => trim($matches[3]),
                        'quantidade' => floatval(str_replace(',', '.', trim($matches[4]))),
                        'preco' => floatval(str_replace(['R$', '.', ','], ['', '', '.'], trim($matches[5]))),
                        'descricao' => trim($matches[2])
                    ];
                }
                // Padrões mais flexíveis para capturar preços
                elseif (preg_match('/(.+?)\s+R\$\s*([0-9.,]+)/', $linha, $matches)) {
                    $itens[] = [
                        'nome' => trim($matches[1]),
                        'preco' => str_replace(',', '.', str_replace('.', '', $matches[2])),
                        'quantidade' => 1,
                        'unidade' => 'UN',
                        'descricao' => trim($matches[1])
                    ];
                } elseif (preg_match('/(.+?)\s+([0-9.,]+)\s*$/', $linha, $matches)) {
                    $itens[] = [
                        'nome' => trim($matches[1]),
                        'preco' => str_replace(',', '.', str_replace('.', '', $matches[2])),
                        'quantidade' => 1,
                        'unidade' => 'UN',
                        'descricao' => trim($matches[1])
                    ];
                } elseif (preg_match('/(.+?)\s+(\d+)\s+([0-9.,]+)/', $linha, $matches)) {
                    $itens[] = [
                        'nome' => trim($matches[1]),
                        'quantidade' => intval($matches[2]),
                        'preco' => str_replace(',', '.', str_replace('.', '', $matches[3])),
                        'unidade' => 'UN',
                        'descricao' => trim($matches[1])
                    ];
                }
            }
        }
    } elseif ($tipo === 'xml') {
        $xml = simplexml_load_string($conteudo);
        if ($xml) {
            $namespaces = $xml->getNamespaces(true);
            
            // NFC-e e NFe padrão
            if (isset($xml->NFe)) {
                $nfe = $xml->NFe;
                $infNFe = $nfe->infNFe;
                
                // Buscar itens em diferentes estruturas possíveis
                $dets = $xml->xpath('//det') ?: $xml->xpath('//prod') ?: $xml->xpath('//produto') ?: [];
                
                foreach ($dets as $det) {
                    $prod = $det->prod ?? $det;
                    
                    $itens[] = [
                        'codigo' => (string)($prod->cProd ?? $prod->codigo ?? ''),
                        'nome' => (string)($prod->xProd ?? $prod->descricao ?? 'Produto sem nome'),
                        'quantidade' => (float)($prod->qCom ?? $prod->quantidade ?? 1),
                        'unidade' => (string)($prod->uCom ?? $prod->unidade ?? 'UN'),
                        'preco' => (float)($prod->vUnCom ?? $prod->preco ?? 0),
                        'descricao' => (string)($prod->xProd ?? $prod->descricao ?? '')
                    ];
                }
            }
            // DANFE SAT
            elseif (isset($xml->CFe)) {
                $cfe = $xml->CFe;
                $infCFe = $cfe->infCFe;
                
                // Itens do SAT
                $dets = $xml->xpath('//det') ?: [];
                foreach ($dets as $det) {
                    $prod = $det->prod;
                    $itens[] = [
                        'codigo' => (string)($prod->cProd ?? ''),
                        'nome' => (string)($prod->xProd ?? 'Produto sem nome'),
                        'quantidade' => (float)($prod->qCom ?? 1),
                        'unidade' => (string)($prod->uCom ?? 'UN'),
                        'preco' => (float)($prod->vUnCom ?? 0),
                        'descricao' => (string)($prod->xProd ?? '')
                    ];
                }
            }
            // Outros formatos XML
            else {
                // Tentar outros formatos XML comuns
                $products = $xml->xpath('//product') ?: $xml->xpath('//item') ?: $xml->xpath('//produto') ?: $xml->xpath('//Produto') ?: [];
                foreach ($products as $product) {
                    $itens[] = [
                        'codigo' => (string)($product->code ?? $product->codigo ?? $product->sku ?? ''),
                        'nome' => (string)($product->name ?? $product->nome ?? $product->descricao ?? 'Produto sem nome'),
                        'quantidade' => (float)($product->quantity ?? $product->quantidade ?? $product->qtd ?? 1),
                        'unidade' => (string)($product->unit ?? $product->unidade ?? $product->un ?? 'UN'),
                        'preco' => (float)($product->price ?? $product->preco ?? $product->preco_unitario ?? 0),
                        'descricao' => (string)($product->description ?? $product->descricao ?? '')
                    ];
                }
                
                // Se ainda não encontrou itens, tentar estrutura genérica
                if (empty($itens)) {
                    $dets = $xml->xpath('//*[contains(name(), "prod") or contains(name(), "item")]') ?: [];
                    foreach ($dets as $det) {
                        $itens[] = [
                            'codigo' => (string)($det->cProd ?? $det->codigo ?? $det->sku ?? ''),
                            'nome' => (string)($det->xProd ?? $det->nome ?? $det->descricao ?? 'Produto sem nome'),
                            'quantidade' => (float)($det->qCom ?? $det->quantidade ?? $det->qtd ?? 1),
                            'unidade' => (string)($det->uCom ?? $det->unidade ?? $det->un ?? 'UN'),
                            'preco' => (float)($det->vUnCom ?? $det->preco ?? $det->preco_unitario ?? 0),
                            'descricao' => (string)($det->xProd ?? $det->descricao ?? '')
                        ];
                    }
                }
            }
        }
        
    } elseif ($tipo === 'csv') {
        $linhas = explode("\n", $conteudo);
        if (count($linhas) > 0) {
            // Detectar delimitador
            $delimitador = detectarDelimitadorCSV($linhas[0]);
            $cabecalho = str_getcsv($linhas[0], $delimitador);
            
            // Mapear colunas
            $colunas = mapearColunasCSV($cabecalho);
            
            for ($i = 1; $i < count($linhas); $i++) {
                if (empty(trim($linhas[$i]))) continue;
                
                $dados = str_getcsv($linhas[$i], $delimitador);
                if (count($dados) >= 2) {
                    $item = [];
                    
                    // Preencher dados baseado no mapeamento
                    if (isset($colunas['codigo']) && isset($dados[$colunas['codigo']])) {
                        $item['codigo'] = trim($dados[$colunas['codigo']]);
                    }
                    
                    if (isset($colunas['nome']) && isset($dados[$colunas['nome']])) {
                        $item['nome'] = trim($dados[$colunas['nome']]);
                        $item['descricao'] = $item['nome'];
                    } elseif (!empty($dados[0])) {
                        $item['nome'] = trim($dados[0]);
                        $item['descricao'] = $item['nome'];
                    }
                    
                    if (isset($colunas['quantidade']) && isset($dados[$colunas['quantidade']])) {
                        $item['quantidade'] = floatval(str_replace(',', '.', trim($dados[$colunas['quantidade']])));
                    } else {
                        $item['quantidade'] = 1;
                    }
                    
                    if (isset($colunas['unidade']) && isset($dados[$colunas['unidade']])) {
                        $item['unidade'] = trim($dados[$colunas['unidade']]);
                    } else {
                        $item['unidade'] = 'UN';
                    }
                    
                    if (isset($colunas['preco']) && isset($dados[$colunas['preco']])) {
                        $preco = trim($dados[$colunas['preco']]);
                        $item['preco'] = floatval(str_replace(['R$', '.', ','], ['', '', '.'], $preco));
                    } else {
                        // Procurar por coluna de preço
                        for ($j = 1; $j < count($dados); $j++) {
                            $valor = $dados[$j];
                            if (is_numeric(str_replace(['.', ','], '', $valor))) {
                                $item['preco'] = floatval(str_replace(',', '.', str_replace('.', '', $valor)));
                                break;
                            }
                        }
                    }
                    
                    if (!empty($item['nome']) && isset($item['preco'])) {
                        $itens[] = $item;
                    }
                }
            }
        }
    }
    
    return array_filter($itens, function($item) {
        return !empty($item['nome']) && $item['nome'] !== 'Produto sem nome' && floatval($item['preco']) > 0;
    });
}

// Função para detectar delimitador CSV
function detectarDelimitadorCSV($linha) {
    $delimitadores = [',', ';', '|', "\t"];
    $counts = [];
    
    foreach ($delimitadores as $delim) {
        $counts[$delim] = count(str_getcsv($linha, $delim));
    }
    
    return array_search(max($counts), $counts);
}

// Função para mapear colunas CSV baseado no cabeçalho
function mapearColunasCSV($cabecalho) {
    $mapeamento = [];
    $padroes = [
        'codigo' => ['codigo', 'cod', 'sku', 'código', 'cprod', 'code'],
        'nome' => ['nome', 'produto', 'descricao', 'xprod', 'descrição', 'product', 'name'],
        'quantidade' => ['quantidade', 'qtd', 'qcom', 'quantity', 'qtde'],
        'unidade' => ['unidade', 'un', 'ucom', 'unit', 'unid'],
        'preco' => ['preco', 'preço', 'vuncom', 'preco_unitario', 'preço_unitário', 'price', 'valor', 'precounit']
    ];
    
    foreach ($cabecalho as $index => $coluna) {
        $coluna_limpa = strtolower(trim($coluna));
        
        foreach ($padroes as $tipo => $sinonimos) {
            foreach ($sinonimos as $sinonimo) {
                if (strpos($coluna_limpa, $sinonimo) !== false) {
                    $mapeamento[$tipo] = $index;
                    break 2;
                }
            }
        }
    }
    
    return $mapeamento;
}

// Buscar produto específico para edição
$produto = null;
if ($id && $acao == 'editar') {
    $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
    $stmt->execute([$id]);
    $produto = $stmt->fetch();
    
    // Se estiver editando, preencher o formulário automaticamente
    if ($produto) {
        echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            abrirModalEditar(" . json_encode($produto) . ");
        });
        </script>";
    }
}

// Buscar todos os produtos
$filtro = $_GET['filtro'] ?? '';
$categoria_filtro = $_GET['categoria'] ?? '';
$estoque_baixo = isset($_GET['estoque_baixo']);
$mostrar_inativos = isset($_GET['mostrar_inativos']);

// Construir WHERE dinamicamente
$where = "1=1";
$params = [];

if (!$mostrar_inativos) {
    $where .= " AND ativo = 1";
}

if ($filtro) {
    $where .= " AND (nome LIKE ? OR codigo LIKE ? OR descricao LIKE ?)";
    $termo = "%$filtro%";
    $params = array_merge($params, [$termo, $termo, $termo]);
}

if ($categoria_filtro) {
    $where .= " AND categoria = ?";
    $params[] = $categoria_filtro;
}

if ($estoque_baixo) {
    $where .= " AND estoque <= estoque_minimo AND estoque_minimo > 0";
}

// ORDENAÇÃO ALFABÉTICA
$sql = "SELECT * FROM produtos WHERE $where ORDER BY ativo DESC, nome ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$produtos = $stmt->fetchAll();

// Buscar categorias únicas
$categorias = $pdo->query("SELECT DISTINCT categoria FROM produtos WHERE categoria IS NOT NULL AND categoria != '' ORDER BY categoria ASC")->fetchAll();

// Unidades padrão para o select
$unidades = ['UN' => 'Unidade', 'PC' => 'Peça', 'KG' => 'Quilograma', 'GR' => 'Grama', 'LT' => 'Litro', 'MT' => 'Metro', 'M2' => 'Metro Quadrado', 'M3' => 'Metro Cúbico', 'CX' => 'Caixa', 'FD' => 'Fardo', 'PCT' => 'Pacote'];
?>

<!-- O RESTANTE DO CÓDIGO HTML PERMANECE IGUAL -->

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1400px;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 1px 3px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-info {
            background: #06b6d4;
            color: white;
            box-shadow: 0 1px 3px rgba(6, 182, 212, 0.3);
        }
        
        .btn-info:hover {
            background: #0891b2;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }
        
        .btn-sm {
            padding: 8px 12px;
            font-size: 13px;
        }
        
        .filters {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-info { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .badge-primary { 
            background: #e0e7ff; 
            color: #3730a3; 
            border: 1px solid #c7d2fe;
        }
        
        .badge-secondary { 
            background: #f3f4f6; 
            color: #374151; 
            border: 1px solid #e5e7eb;
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 24px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .produto-code {
            font-family: 'Monaco', 'Consolas', monospace;
            font-weight: 700;
            color: #3b82f6;
            background: #eff6ff;
            padding: 4px 8px;
            border-radius: 6px;
            border: 1px solid #dbeafe;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 2px solid #d1d5db;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            font-weight: 500;
            color: #374151;
            cursor: pointer;
        }
        
        .stock-low {
            background: #fffbeb !important;
            border-left: 4px solid #f59e0b;
        }
        
        .stock-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .stock-min {
            font-size: 12px;
            color: #6b7280;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
        }

        /* ESTILOS PARA NOTA FISCAL */
        .upload-section {
            background: #f8fafc;
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            padding: 32px;
            text-align: center;
            margin-bottom: 24px;
            transition: all 0.3s;
        }
        
        .upload-section:hover {
            border-color: #3b82f6;
            background: #f0f9ff;
        }
        
        .upload-icon {
            font-size: 48px;
            color: #6b7280;
            margin-bottom: 16px;
        }
        
        .upload-text {
            color: #374151;
            margin-bottom: 16px;
        }
        
        .file-input {
            display: none;
        }
        
        .file-label {
            background: #3b82f6;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        
        .file-label:hover {
            background: #2563eb;
        }
        
        .itens-nota-table {
            margin-top: 24px;
        }
        
        .item-selecionado {
            background: #f0f9ff !important;
        }
        
        .checkbox-item {
            width: 20px;
            height: 20px;
        }
        
        .modal-wide {
            max-width: 1200px;
        }
        
        .unidade-select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            background: white;
            color: #374151;
        }
        
        .categoria-combobox {
            position: relative;
        }
        
        .categoria-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        .categoria-suggestion {
            padding: 12px 16px;
            cursor: pointer;
            border-bottom: 1px solid #f3f4f6;
            transition: background-color 0.2s;
        }
        
        .categoria-suggestion:hover {
            background: #f9fafb;
        }
        
        .filter-options {
            display: flex;
            gap: 16px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
        }
        
        .percentual-acrescimo {
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .percentual-acrescimo label {
            font-weight: 600;
            color: #ea580c;
            margin-bottom: 8px;
            display: block;
        }
        
        .percentual-info {
            font-size: 14px;
            color: #9a3412;
            margin-top: 8px;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-box"></i> Produtos</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
  <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li class="active"><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['erro'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $_GET['erro']; ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Seção de Upload de Nota Fiscal -->
            <?php if (temPermissao('produtos_editar')): ?>
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-file-invoice"></i> Importar Nota Fiscal</h2>
                </div>
                <div class="card-body">
                    <form id="formNotaFiscal" method="POST" enctype="multipart/form-data">
                        <div class="upload-section">
                            <div class="upload-icon">
                                <i class="fas fa-file-upload"></i>
                            </div>
                            <h3 class="upload-text">Arraste ou clique para fazer upload da nota fiscal</h3>
                            <p style="color: #6b7280; margin-bottom: 20px;">
                                Formatos suportados: TXT, XML, CSV<br>
                                <small>O sistema tentará extrair automaticamente os preços e descrições dos produtos</small>
                            </p>
                            <input type="file" name="nota_fiscal" id="nota_fiscal" class="file-input" accept=".txt,.xml,.csv">
                            <label for="nota_fiscal" class="file-label">
                                <i class="fas fa-search"></i> Selecionar Arquivo
                            </label>
                            <div id="fileName" style="margin-top: 12px; color: #374151; font-weight: 500;"></div>
                        </div>
                        <div style="text-align: center;">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-upload"></i> Processar Nota Fiscal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-list"></i> Lista de Produtos</h2>
                    <?php if (temPermissao('produtos_editar')): ?>
                    <button onclick="abrirModal()" class="btn btn-success">
                        <i class="fas fa-plus"></i> Novo Produto
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <div class="filters">
                        <input type="text" id="searchInput" class="form-control" placeholder="Buscar produtos..." 
                               value="<?php echo htmlspecialchars($filtro); ?>" style="width: 300px;">
                        <select id="categoriaSelect" class="form-control" style="width: 200px;">
                            <option value="">Todas as categorias</option>
                            <?php foreach ($categorias as $cat): ?>
                                <option value="<?php echo $cat['categoria']; ?>" <?php echo $categoria_filtro == $cat['categoria'] ? 'selected' : ''; ?>>
                                    <?php echo $cat['categoria']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="filter-options">
                            <div class="filter-checkbox">
                                <input type="checkbox" id="estoqueBaixoCheck" <?php echo $estoque_baixo ? 'checked' : ''; ?>>
                                <label for="estoqueBaixoCheck">Estoque Baixo</label>
                            </div>
                            <div class="filter-checkbox">
                                <input type="checkbox" id="mostrarInativosCheck" <?php echo $mostrar_inativos ? 'checked' : ''; ?>>
                                <label for="mostrarInativosCheck">Mostrar Inativos</label>
                            </div>
                        </div>
                        <button onclick="filtrarProdutos()" class="btn btn-primary">
                            <i class="fas fa-search"></i> Filtrar
                        </button>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Nome</th>
                                    <th>Preço Venda</th>
                                    <th>Estoque</th>
                                    <th>Categoria</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($produtos as $prod): ?>
                                <tr class="<?php echo ($prod['estoque'] <= $prod['estoque_minimo'] && $prod['estoque_minimo'] > 0) ? 'stock-low' : ''; ?>">
                                    <td>
                                        <span class="produto-code"><?php echo $prod['codigo']; ?></span>
                                    </td>
                                    <td>
                                        <div style="font-weight: 600; color: #1e293b;">
                                            <?php echo htmlspecialchars($prod['nome']); ?>
                                        </div>
                                        <?php if ($prod['descricao']): ?>
                                        <div style="font-size: 14px; color: #6b7280; margin-top: 4px;">
                                            <?php echo substr($prod['descricao'], 0, 80); ?>...
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div style="font-weight: 700; color: #059669;">
                                            R$ <?php echo number_format($prod['preco_venda'], 2, ',', '.'); ?>
                                        </div>
                                        <div style="font-size: 12px; color: #6b7280;">
                                            Custo: R$ <?php echo number_format($prod['preco_custo'], 2, ',', '.'); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="stock-info">
                                            <span style="font-weight: 600; color: #374151;">
                                                <?php echo $prod['estoque']; ?> <?php echo $prod['unidade'] ?: 'UN'; ?>
                                            </span>
                                            <?php if ($prod['estoque_minimo'] > 0): ?>
                                            <span class="stock-min">
                                                Mín: <?php echo $prod['estoque_minimo']; ?>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($prod['categoria']): ?>
                                        <span class="badge badge-secondary">
                                            <?php echo $prod['categoria']; ?>
                                        </span>
                                        <?php else: ?>
                                        <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $prod['ativo'] ? 'badge-success' : 'badge-danger'; ?>">
                                            <i class="fas fa-<?php echo $prod['ativo'] ? 'check' : 'times'; ?>"></i>
                                            <?php echo $prod['ativo'] ? 'Ativo' : 'Inativo'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <?php if (temPermissao('produtos_editar')): ?>
                                            <button onclick="editarProduto(<?php echo $prod['id']; ?>)" class="btn btn-warning btn-sm" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                            <?php if (temPermissao('produtos_excluir')): ?>
                                            <button onclick="excluirProduto(<?php echo $prod['id']; ?>)" class="btn btn-danger btn-sm" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($produtos)): ?>
                                <tr>
                                    <td colspan="7">
                                        <div class="empty-state">
                                            <i class="fas fa-box"></i>
                                            <h3>Nenhum produto encontrado</h3>
                                            <p>Comece cadastrando seu primeiro produto</p>
                                            <?php if (temPermissao('produtos_editar')): ?>
                                            <button onclick="abrirModal()" class="btn btn-success" style="margin-top: 16px;">
                                                <i class="fas fa-plus"></i> Cadastrar Produto
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Modal Produto -->
    <div id="modalProduto" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus-circle"></i> <span id="modalTitulo">Novo Produto</span></h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formProduto" method="POST">
                    <input type="hidden" name="acao" id="formAcao" value="adicionar">
                    <input type="hidden" name="id" id="produtoId">
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-info-circle"></i> Informações Básicas</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Código</label>
                                <input type="text" name="codigo" id="codigo" class="form-control" 
                                       placeholder="Ex: PRD001">
                            </div>
                            <div class="form-group">
                                <label>Nome *</label>
                                <input type="text" name="nome" id="nome" class="form-control" required 
                                       placeholder="Nome do produto">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-align-left"></i> Descrição</h3>
                        
                        <div class="form-group">
                            <textarea name="descricao" id="descricao" class="form-control" rows="3" 
                                      placeholder="Descrição detalhada do produto"></textarea>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-tag"></i> Preços</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Preço de Custo</label>
                                <input type="text" name="preco_custo" id="preco_custo" class="form-control money-input" 
                                       placeholder="R$ 0,00">
                            </div>
                            <div class="form-group">
                                <label>Preço de Venda *</label>
                                <input type="text" name="preco_venda" id="preco_venda" class="form-control money-input" required 
                                       placeholder="R$ 0,00">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-boxes"></i> Estoque</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Estoque Atual</label>
                                <input type="number" name="estoque" id="estoque" class="form-control" value="0" min="0" 
                                       placeholder="Quantidade em estoque">
                            </div>
                            <div class="form-group">
                                <label>Estoque Mínimo</label>
                                <input type="number" name="estoque_minimo" id="estoque_minimo" class="form-control" value="0" min="0" 
                                       placeholder="Estoque mínimo alerta">
                            </div>
                            <div class="form-group">
                                <label>Unidade</label>
                                <select name="unidade" id="unidade" class="unidade-select">
                                    <?php foreach ($unidades as $valor => $label): ?>
                                        <option value="<?php echo $valor; ?>"><?php echo $label; ?> (<?php echo $valor; ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-folder"></i> Categorização</h3>
                        
                        <div class="form-row">
                            <div class="form-group categoria-combobox">
                                <label>Categoria</label>
                                <input type="text" name="categoria" id="categoria" class="form-control"
                                       placeholder="Ex: Eletrônicos, Informática" autocomplete="off">
                                <div class="categoria-suggestions" id="categoriaSuggestions"></div>
                            </div>
                            <div class="form-group">
                                <label>Marca</label>
                                <input type="text" name="marca" id="marca" class="form-control" 
                                       placeholder="Marca do produto">
                            </div>
                            <div class="form-group">
                                <label>Fornecedor</label>
                                <input type="text" name="fornecedor" id="fornecedor" class="form-control" 
                                       placeholder="Fornecedor principal">
                            </div>
                        </div>
                    </div>

                    <div class="form-section" id="ativoField">
                        <h3 class="section-title"><i class="fas fa-toggle-on"></i> Status</h3>
                        
                        <div class="checkbox-group">
                            <input type="checkbox" name="ativo" id="ativo" value="1" checked>
                            <label for="ativo">Produto ativo</label>
                        </div>
                    </div>

                    <div style="margin-top: 32px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <button type="button" onclick="fecharModal()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Salvar Produto
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Itens Nota Fiscal -->
    <?php if (isset($_SESSION['itens_nota_fiscal']) && !empty($_SESSION['itens_nota_fiscal'])): ?>
    <div id="modalItensNota" class="modal" style="display: block;">
        <div class="modal-content modal-wide">
            <div class="modal-header">
                <h2><i class="fas fa-file-invoice"></i> Itens da Nota Fiscal</h2>
                <button class="close" onclick="fecharModalItens()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form method="POST" id="formItensNota">
                    <input type="hidden" name="cadastrar_itens_nota" value="1">
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <span>Selecione os itens que deseja cadastrar automaticamente no sistema.</span>
                    </div>
                    
                    <div class="percentual-acrescimo">
                        <label for="percentual_acrescimo">Percentual de Acréscimo para Preço de Venda (%)</label>
                        <input type="number" name="percentual_acrescimo" id="percentual_acrescimo" class="form-control" 
                               value="30" min="0" max="500" step="0.1" style="max-width: 200px;">
                        <div class="percentual-info">
                            <i class="fas fa-info-circle"></i> 
                            O preço de venda será calculado automaticamente: Preço Custo + este percentual
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 50px;">
                                        <input type="checkbox" id="selecionarTodos" onchange="selecionarTodosItens(this)">
                                    </th>
                                    <th>Nome do Produto</th>
                                    <th>Preço Unitário</th>
                                    <th>Quantidade</th>
                                    <th>Unidade</th>
                                    <th>Código</th>
                                    <th>Preço Venda Calculado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $percentual = 30; // Percentual padrão
                                foreach ($_SESSION['itens_nota_fiscal'] as $index => $item): 
                                    $preco_custo = floatval($item['preco'] ?? 0);
                                    $preco_venda = $preco_custo * (1 + $percentual/100);
                                ?>
                                <tr id="item-<?php echo $index; ?>" onclick="toggleItem(<?php echo $index; ?>)">
                                    <td>
                                        <input type="checkbox" name="itens_cadastrar[]" value="<?php echo $index; ?>" 
                                               class="checkbox-item" id="item-check-<?php echo $index; ?>">
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($item['nome'] ?? 'Produto sem nome'); ?></strong>
                                        <?php if (!empty($item['descricao'])): ?>
                                        <div style="font-size: 12px; color: #6b7280; margin-top: 4px;">
                                            <?php echo htmlspecialchars($item['descricao']); ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span style="font-weight: 600; color: #dc2626;">
                                            R$ <?php echo number_format($preco_custo, 2, ',', '.'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span style="font-weight: 600;">
                                            <?php echo $item['quantidade'] ?? 1; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary">
                                            <?php echo $item['unidade'] ?? 'UN'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <code><?php echo $item['codigo'] ?? 'AUTO'; ?></code>
                                    </td>
                                    <td>
                                        <span style="font-weight: 700; color: #059669;">
                                            R$ <?php echo number_format($preco_venda, 2, ',', '.'); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div style="margin-top: 24px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <button type="button" onclick="fecharModalItens()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-plus-circle"></i> Cadastrar Itens Selecionados
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        // Categorias disponíveis para sugestões
        const categoriasDisponiveis = <?php echo json_encode(array_column($categorias, 'categoria')); ?>;
        
        function abrirModal() {
            document.getElementById('modalProduto').style.display = 'block';
            document.getElementById('formAcao').value = 'adicionar';
            document.getElementById('modalTitulo').textContent = 'Novo Produto';
            document.getElementById('ativoField').style.display = 'block';
            document.getElementById('formProduto').reset();
            document.getElementById('unidade').value = 'UN';
            document.getElementById('produtoId').value = '';
        }
        
        function abrirModalEditar(produto) {
            document.getElementById('modalProduto').style.display = 'block';
            document.getElementById('formAcao').value = 'editar';
            document.getElementById('modalTitulo').textContent = 'Editar Produto';
            document.getElementById('produtoId').value = produto.id;
            document.getElementById('codigo').value = produto.codigo;
            document.getElementById('nome').value = produto.nome;
            document.getElementById('descricao').value = produto.descricao;
            
            // Formatar preços para o formato brasileiro
            document.getElementById('preco_custo').value = formatarMoeda(produto.preco_custo);
            document.getElementById('preco_venda').value = formatarMoeda(produto.preco_venda);
            
            document.getElementById('estoque').value = produto.estoque;
            document.getElementById('estoque_minimo').value = produto.estoque_minimo;
            document.getElementById('unidade').value = produto.unidade || 'UN';
            document.getElementById('categoria').value = produto.categoria;
            document.getElementById('marca').value = produto.marca;
            document.getElementById('fornecedor').value = produto.fornecedor;
            document.getElementById('ativo').checked = produto.ativo == 1;
        }
        
        function formatarMoeda(valor) {
            return 'R$ ' + parseFloat(valor).toFixed(2).replace('.', ',').replace(/\d(?=(\d{3})+,)/g, '$&.');
        }
        
        function fecharModal() {
            document.getElementById('modalProduto').style.display = 'none';
        }
        
        function fecharModalItens() {
            window.location.href = 'produtos.php?limpar_nota=1';
        }
        
        function filtrarProdutos() {
            const filtro = document.getElementById('searchInput').value;
            const categoria = document.getElementById('categoriaSelect').value;
            const estoqueBaixo = document.getElementById('estoqueBaixoCheck').checked;
            const mostrarInativos = document.getElementById('mostrarInativosCheck').checked;
            
            let url = 'produtos.php?';
            if (filtro) url += 'filtro=' + encodeURIComponent(filtro) + '&';
            if (categoria) url += 'categoria=' + encodeURIComponent(categoria) + '&';
            if (estoqueBaixo) url += 'estoque_baixo=1&';
            if (mostrarInativos) url += 'mostrar_inativos=1&';
            
            window.location.href = url;
        }
        
        function editarProduto(id) {
            window.location.href = 'produtos.php?acao=editar&id=' + id;
        }
        
        function excluirProduto(id) {
            if (confirm('Tem certeza que deseja EXCLUIR DEFINITIVAMENTE este produto?\n\nEsta ação não pode ser desfeita!')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // MÁSCARA DE MOEDA
        function aplicarMascaraMoeda(input) {
            input.addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                if (value === '') {
                    e.target.value = 'R$ 0,00';
                    return;
                }
                while (value.length < 3) {
                    value = '0' + value;
                }
                const cents = value.slice(-2);
                let reais = value.slice(0, -2);
                reais = reais.replace(/^0+/, '') || '0';
                reais = reais.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                e.target.value = `R$ ${reais},${cents}`;
            });
        }

        // Aplicar máscara aos campos de preço
        document.addEventListener('DOMContentLoaded', function() {
            const moneyInputs = document.querySelectorAll('.money-input');
            moneyInputs.forEach(aplicarMascaraMoeda);
            
            // Atualizar preços calculados quando o percentual mudar
            const percentualInput = document.getElementById('percentual_acrescimo');
            if (percentualInput) {
                percentualInput.addEventListener('input', atualizarPrecosCalculados);
            }
            
            // Se estiver no modo de edição e temos um produto, preencher o modal
            <?php if ($produto): ?>
            abrirModalEditar(<?php echo json_encode($produto); ?>);
            <?php endif; ?>
        });

        // Atualizar preços calculados na tabela de itens da nota fiscal
        function atualizarPrecosCalculados() {
            const percentual = parseFloat(document.getElementById('percentual_acrescimo').value) || 0;
            const linhas = document.querySelectorAll('#modalItensNota tbody tr');
            
            linhas.forEach(linha => {
                const precoCustoText = linha.querySelector('td:nth-child(3) span').textContent;
                const precoCusto = parseFloat(precoCustoText.replace('R$', '').replace('.', '').replace(',', '.').trim());
                
                if (!isNaN(precoCusto)) {
                    const precoVenda = precoCusto * (1 + percentual/100);
                    const precoVendaFormatado = 'R$ ' + precoVenda.toFixed(2).replace('.', ',').replace(/\d(?=(\d{3})+,)/g, '$&.');
                    linha.querySelector('td:nth-child(7) span').textContent = precoVendaFormatado;
                }
            });
        }

        // SUGESTÕES DE CATEGORIA
        document.getElementById('categoria').addEventListener('input', function(e) {
            const valor = e.target.value.toLowerCase();
            const suggestions = document.getElementById('categoriaSuggestions');
            suggestions.innerHTML = '';
            
            if (valor.length > 1) {
                const matches = categoriasDisponiveis.filter(cat => 
                    cat.toLowerCase().includes(valor)
                );
                
                if (matches.length > 0) {
                    matches.forEach(cat => {
                        const div = document.createElement('div');
                        div.className = 'categoria-suggestion';
                        div.textContent = cat;
                        div.onclick = function() {
                            document.getElementById('categoria').value = cat;
                            suggestions.style.display = 'none';
                        };
                        suggestions.appendChild(div);
                    });
                    suggestions.style.display = 'block';
                } else {
                    suggestions.style.display = 'none';
                }
            } else {
                suggestions.style.display = 'none';
            }
        });

        // Fechar sugestões ao clicar fora
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.categoria-combobox')) {
                document.getElementById('categoriaSuggestions').style.display = 'none';
            }
        });

        // MOSTRAR NOME DO ARQUIVO SELECIONADO
        document.getElementById('nota_fiscal').addEventListener('change', function(e) {
            const fileName = document.getElementById('fileName');
            if (this.files.length > 0) {
                fileName.textContent = 'Arquivo selecionado: ' + this.files[0].name;
                fileName.style.color = '#059669';
            }
        });

        // FUNÇÕES PARA MODAL DE ITENS DA NOTA FISCAL
        function toggleItem(index) {
            const checkbox = document.getElementById('item-check-' + index);
            const row = document.getElementById('item-' + index);
            checkbox.checked = !checkbox.checked;
            if (checkbox.checked) {
                row.classList.add('item-selecionado');
            } else {
                row.classList.remove('item-selecionado');
            }
        }
        
        function selecionarTodosItens(checkbox) {
            const checkboxes = document.querySelectorAll('.checkbox-item');
            const rows = document.querySelectorAll('tbody tr[id^="item-"]');
            checkboxes.forEach(cb => cb.checked = checkbox.checked);
            rows.forEach(row => {
                if (checkbox.checked) {
                    row.classList.add('item-selecionado');
                } else {
                    row.classList.remove('item-selecionado');
                }
            });
        }

        // Permitir busca com Enter
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') filtrarProdutos();
        });

        // REMOVIDA A VALIDAÇÃO OBRIGATÓRIA DA CATEGORIA
        document.getElementById('formProduto').addEventListener('submit', function(e) {
            // Validação básica mantida apenas para campos realmente obrigatórios
            const nome = document.getElementById('nome').value.trim();
            if (!nome) {
                e.preventDefault();
                alert('O campo nome é obrigatório!');
                document.getElementById('nome').focus();
                return false;
            }
        });

        console.log('Sistema de produtos carregado com sucesso!');
    </script>
</body>
</html>