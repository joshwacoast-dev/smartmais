<?php
include 'config.php';
verificarLogin();

if (!temPermissao('os_visualizar')) {
    header("Location: dashboard.php");
    exit();
}

$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? 0;
$cliente_id = $_GET['cliente_id'] ?? 0;
$orcamento_id = $_GET['orcamento_id'] ?? 0;

// Processar formulário
if ($_POST) {
    $dados = $_POST;
    
    if ($dados['acao'] == 'adicionar' && temPermissao('os_editar')) {
        $numero = obterProximoNumero('ordens_servico', 'numero', 'OS');
        
        $stmt = $pdo->prepare("INSERT INTO ordens_servico (numero, cliente_id, equipamento, modelo, numero_serie, defeito_relatado, diagnostico_tecnico, observacoes, prioridade, data_entrada, data_previsao, tecnico_id, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $numero, $dados['cliente_id'], $dados['equipamento'],
            $dados['modelo'], $dados['numero_serie'], $dados['defeito_relatado'],
            $dados['diagnostico_tecnico'], $dados['observacoes'], $dados['prioridade'],
            $dados['data_entrada'], $dados['data_previsao'], $dados['tecnico_id'],
            $_SESSION['usuario_id']
        ]);
        
        $os_id = $pdo->lastInsertId();
        
        // Processar itens se existirem
        if (isset($dados['itens'])) {
            foreach ($dados['itens'] as $item) {
                if ($item['tipo'] && $item['quantidade'] > 0) {
                    $stmt = $pdo->prepare("INSERT INTO os_itens (ordem_servico_id, tipo, item_id, quantidade, preco_unitario, total, descricao) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $os_id, $item['tipo'], $item['item_id'],
                        $item['quantidade'], $item['preco_unitario'],
                        $item['total'], $item['descricao']
                    ]);
                }
            }
        }
        
        registrarLog('Criação de OS', 'OS: ' . $numero);
        header("Location: ordens_servico.php?sucesso=Ordem de serviço criada com sucesso!");
        exit();
    }
    elseif ($dados['acao'] == 'alterar_status' && temPermissao('os_editar')) {
        $stmt = $pdo->prepare("UPDATE ordens_servico SET status = ?, data_conclusao = ? WHERE id = ?");
        $data_conclusao = $dados['status'] == 'Concluída' ? date('Y-m-d') : null;
        $stmt->execute([$dados['status'], $data_conclusao, $dados['id']]);
        
        registrarLog('Alteração status OS', 'OS ID: ' . $dados['id'] . ' - Status: ' . $dados['status']);
        header("Location: ordens_servico.php?sucesso=Status da OS atualizado!");
        exit();
    }
    elseif ($dados['acao'] == 'excluir' && temPermissao('os_excluir')) {
        // Buscar dados da OS antes de excluir para o log
        $stmt = $pdo->prepare("SELECT numero FROM ordens_servico WHERE id = ?");
        $stmt->execute([$dados['id']]);
        $os = $stmt->fetch();
        
        // Excluir itens da OS primeiro (devido à chave estrangeira)
        $stmt = $pdo->prepare("DELETE FROM os_itens WHERE ordem_servico_id = ?");
        $stmt->execute([$dados['id']]);
        
        // Excluir a OS
        $stmt = $pdo->prepare("DELETE FROM ordens_servico WHERE id = ?");
        $stmt->execute([$dados['id']]);
        
        registrarLog('Exclusão de OS', 'OS: ' . $os['numero']);
        header("Location: ordens_servico.php?sucesso=Ordem de serviço excluída com sucesso!");
        exit();
    }
}

// Buscar ordens de serviço
$status_filtro = $_GET['status'] ?? '';
$where = "1=1";
$params = [];

if ($status_filtro) {
    $where .= " AND status = ?";
    $params[] = $status_filtro;
}

$sql = "SELECT os.*, c.nome as cliente_nome, u.nome as tecnico_nome 
        FROM ordens_servico os 
        LEFT JOIN clientes c ON os.cliente_id = c.id 
        LEFT JOIN usuarios u ON os.tecnico_id = u.id 
        WHERE $where 
        ORDER BY os.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$ordens_servico = $stmt->fetchAll();

// Buscar dados para formulário
$clientes = $pdo->query("SELECT id, nome FROM clientes WHERE ativo = 1 ORDER BY nome")->fetchAll();
$tecnicos = $pdo->query("SELECT id, nome FROM usuarios WHERE ativo = 1 AND tipo_usuario IN ('Técnico', 'Administrador') ORDER BY nome")->fetchAll();
$produtos = $pdo->query("SELECT id, codigo, nome, preco_venda as preco FROM produtos WHERE ativo = 1 ORDER BY nome")->fetchAll();
$servicos = $pdo->query("SELECT id, codigo, nome, preco FROM servicos WHERE ativo = 1 ORDER BY nome")->fetchAll();

// Se veio de orçamento, carregar dados
$orcamento = null;
if ($orcamento_id) {
    $stmt = $pdo->prepare("SELECT o.*, c.id as cliente_id, c.nome as cliente_nome FROM orcamentos o LEFT JOIN clientes c ON o.cliente_id = c.id WHERE o.id = ?");
    $stmt->execute([$orcamento_id]);
    $orcamento = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ordens de Serviço - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1400px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 1px 3px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 1px 3px rgba(245, 158, 11, 0.3);
        }
        
        .btn-warning:hover {
            background: #d97706;
            transform: translateY(-1px);
        }
        
        .btn-info {
            background: #06b6d4;
            color: white;
            box-shadow: 0 1px 3px rgba(6, 182, 212, 0.3);
        }
        
        .btn-info:hover {
            background: #0891b2;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
        }
        
        .btn-sm {
            padding: 8px 12px;
            font-size: 13px;
        }
        
        /* Formulários */
        .filters {
            display: flex;
            gap: 16px;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Badges */
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .badge-warning { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .badge-danger { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        .badge-info { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .badge-primary { 
            background: #e0e7ff; 
            color: #3730a3; 
            border: 1px solid #c7d2fe;
        }
        
        .priority-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .priority-baixa { 
            background: #dcfce7; 
            color: #166534; 
            border: 1px solid #bbf7d0;
        }
        
        .priority-normal { 
            background: #dbeafe; 
            color: #1e40af; 
            border: 1px solid #bfdbfe;
        }
        
        .priority-alta { 
            background: #fef3c7; 
            color: #92400e; 
            border: 1px solid #fde68a;
        }
        
        .priority-urgente { 
            background: #fee2e2; 
            color: #991b1b; 
            border: 1px solid #fecaca;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow-y: auto;
            backdrop-filter: blur(4px);
        }
        
        .modal-content {
            background: white;
            margin: 40px auto;
            padding: 0;
            border-radius: 12px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }
        
        .modal-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
        }
        
        .modal-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .modal-header h2 i {
            color: #3b82f6;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #6b7280;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .close:hover {
            background: #f3f4f6;
            color: #374151;
        }
        
        .modal-body {
            padding: 32px;
        }
        
        /* Formulário */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        .item-row {
            display: grid;
            grid-template-columns: 120px 1fr 100px 120px 120px 1fr 60px;
            gap: 12px;
            align-items: end;
            margin-bottom: 16px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
        
        .item-row select, .item-row input {
            width: 100%;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 24px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        .actions {
            display: flex;
            gap: 8px;
        }
        
        .os-number {
            font-family: 'Monaco', 'Consolas', monospace;
            font-weight: 700;
            color: #3b82f6;
            background: #eff6ff;
            padding: 4px 8px;
            border-radius: 6px;
            border: 1px solid #dbeafe;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        
        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #374151;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-info {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .footer-contact, .footer-credits {
            text-align: center;
        }
        
        .footer-contact h4, .footer-credits h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #cbd5e1;
        }
        
        .footer-contact p, .footer-credits p {
            font-size: 14px;
            color: #94a3b8;
            margin-bottom: 5px;
        }
        
        .footer-contact a {
            color: #3b82f6;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-contact a:hover {
            color: #60a5fa;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
            .main-content {
                margin-left: 240px;
            }
            footer {
                margin-left: 240px;
            }
            .item-row {
                grid-template-columns: 1fr;
                gap: 8px;
            }
        }
        
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            .filters {
                flex-direction: column;
                align-items: stretch;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .footer-info {
                flex-direction: column;
                gap: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-header {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <h5><i class="fas fa-clipboard-list"></i> Ordens de Serviço</h5>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
  <!-- Sidebar -->
      <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li class="active"><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
           
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if (isset($_GET['sucesso'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $_GET['sucesso']; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['erro'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $_GET['erro']; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-list"></i> Lista de Ordens de Serviço</h2>
                    <?php if (temPermissao('os_editar')): ?>
                    <button onclick="abrirModal()" class="btn btn-success">
                        <i class="fas fa-plus"></i> Nova OS
                    </button>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <div class="filters">
                        <select id="statusFilter" class="form-control" style="width: auto;" onchange="filtrarOS()">
                            <option value="">Todas as OS</option>
                            <option value="Aberta" <?php echo $status_filtro == 'Aberta' ? 'selected' : ''; ?>>Abertas</option>
                            <option value="Em Andamento" <?php echo $status_filtro == 'Em Andamento' ? 'selected' : ''; ?>>Em Andamento</option>
                            <option value="Aguardando Peças" <?php echo $status_filtro == 'Aguardando Peças' ? 'selected' : ''; ?>>Aguardando Peças</option>
                            <option value="Concluída" <?php echo $status_filtro == 'Concluída' ? 'selected' : ''; ?>>Concluídas</option>
                        </select>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Número</th>
                                    <th>Cliente</th>
                                    <th>Equipamento</th>
                                    <th>Defeito</th>
                                    <th>Técnico</th>
                                    <th>Prioridade</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ordens_servico as $os): ?>
                                <tr>
                                    <td>
                                        <span class="os-number"><?php echo $os['numero']; ?></span>
                                    </td>
                                    <td>
                                        <div style="font-weight: 600; color: #1e293b;">
                                            <?php echo htmlspecialchars($os['cliente_nome']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="font-weight: 500; color: #374151;">
                                            <?php echo htmlspecialchars($os['equipamento']); ?>
                                        </div>
                                        <?php if ($os['modelo']): ?>
                                        <div style="font-size: 13px; color: #6b7280;">
                                            <?php echo $os['modelo']; ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($os['defeito_relatado']): ?>
                                        <div style="max-width: 200px;">
                                            <span title="<?php echo htmlspecialchars($os['defeito_relatado']); ?>">
                                                <?php echo substr($os['defeito_relatado'], 0, 50); ?>...
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($os['tecnico_nome']): ?>
                                        <span style="color: #374151;"><?php echo $os['tecnico_nome']; ?></span>
                                        <?php else: ?>
                                        <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="priority-badge priority-<?php echo strtolower($os['prioridade']); ?>">
                                            <i class="fas fa-<?php echo $os['prioridade'] == 'Urgente' ? 'exclamation-triangle' : 
                                                             ($os['prioridade'] == 'Alta' ? 'arrow-up' : 
                                                             ($os['prioridade'] == 'Normal' ? 'minus' : 'arrow-down')); ?>"></i>
                                            <?php echo $os['prioridade']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge 
                                            <?php echo $os['status'] == 'Concluída' ? 'badge-success' : 
                                                  ($os['status'] == 'Em Andamento' ? 'badge-primary' : 
                                                  ($os['status'] == 'Aguardando Peças' ? 'badge-warning' : 'badge-info')); ?>">
                                            <i class="fas fa-<?php echo $os['status'] == 'Concluída' ? 'check' : 
                                                             ($os['status'] == 'Em Andamento' ? 'play' : 
                                                             ($os['status'] == 'Aguardando Peças' ? 'clock' : 'folder-open')); ?>"></i>
                                            <?php echo $os['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <a href="gerar_pdf.php?tipo=os&id=<?php echo $os['id']; ?>" class="btn btn-info btn-sm" target="_blank" title="Imprimir">
                                                <i class="fas fa-print"></i>
                                            </a>
                                            <?php if (temPermissao('os_editar') && $os['status'] != 'Concluída'): ?>
                                            <button onclick="alterarStatus(<?php echo $os['id']; ?>)" class="btn btn-warning btn-sm" title="Alterar Status">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                            <?php if (temPermissao('os_concluir') && $os['status'] != 'Concluída'): ?>
                                            <button onclick="concluirOS(<?php echo $os['id']; ?>)" class="btn btn-success btn-sm" title="Concluir OS">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <?php endif; ?>
                                            <?php if (temPermissao('os_excluir')): ?>
                                            <button onclick="excluirOS(<?php echo $os['id']; ?>)" class="btn btn-danger btn-sm" title="Excluir OS">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($ordens_servico)): ?>
                                <tr>
                                    <td colspan="8">
                                        <div class="empty-state">
                                            <i class="fas fa-clipboard-list"></i>
                                            <h3>Nenhuma ordem de serviço encontrada</h3>
                                            <p>Comece criando sua primeira ordem de serviço</p>
                                            <?php if (temPermissao('os_editar')): ?>
                                            <button onclick="abrirModal()" class="btn btn-success" style="margin-top: 16px;">
                                                <i class="fas fa-plus"></i> Criar OS
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="footer-info">
                <div class="footer-contact">
                    <h4>Contato</h4>
                    <p><i class="fas fa-phone-alt"></i> (85) 3095.0064</p>
                    <p><i class="fas fa-envelope"></i> contato@storessmart.com.br</p>
                    <p><i class="fas fa-globe"></i> www.storessmart.com.br</p>
                </div>
                
                <div class="footer-credits">
                    <h4>Desenvolvimento</h4>
                    <p><i class="fas fa-code"></i> Desenvolvido por: Josué</p>
                    <p><i class="fas fa-mobile-alt"></i> WhatsApp: (55) 85 992589475</p>
                    <p><i class="fas fa-id-card"></i> ID: 05989425309</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Modal OS -->
    <div id="modalOS" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus-circle"></i> <span id="modalTitulo">Nova Ordem de Serviço</span></h2>
                <button class="close" onclick="fecharModal()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formOS" method="POST">
                    <input type="hidden" name="acao" value="adicionar">
                    
                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-user"></i> Informações do Cliente</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Cliente</label>
                                <select name="cliente_id" id="cliente_id" class="form-control" required>
                                    <option value="">Selecione um cliente</option>
                                    <?php foreach ($clientes as $cli): ?>
                                    <option value="<?php echo $cli['id']; ?>" 
                                        <?php echo ($cliente_id == $cli['id'] || ($orcamento && $orcamento['cliente_id'] == $cli['id'])) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cli['nome']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Técnico Responsável</label>
                                <select name="tecnico_id" id="tecnico_id" class="form-control">
                                    <option value="">Selecione o técnico</option>
                                    <?php foreach ($tecnicos as $tec): ?>
                                    <option value="<?php echo $tec['id']; ?>"><?php echo htmlspecialchars($tec['nome']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-laptop"></i> Informações do Equipamento</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Equipamento</label>
                                <input type="text" name="equipamento" id="equipamento" class="form-control" required 
                                       placeholder="Ex: Notebook Dell, iPhone 12, etc.">
                            </div>
                            <div class="form-group">
                                <label>Modelo</label>
                                <input type="text" name="modelo" id="modelo" class="form-control" 
                                       placeholder="Ex: Inspiron 15, iPhone 12 Pro Max">
                            </div>
                            <div class="form-group">
                                <label>Número de Série</label>
                                <input type="text" name="numero_serie" id="numero_serie" class="form-control" 
                                       placeholder="Número de série do equipamento">
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-calendar"></i> Datas e Prioridade</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Data de Entrada</label>
                                <input type="date" name="data_entrada" id="data_entrada" class="form-control" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Previsão de Entrega</label>
                                <input type="date" name="data_previsao" id="data_previsao" class="form-control" 
                                       value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>">
                            </div>
                            <div class="form-group">
                                <label>Prioridade</label>
                                <select name="prioridade" id="prioridade" class="form-control">
                                    <option value="Baixa">Baixa</option>
                                    <option value="Normal" selected>Normal</option>
                                    <option value="Alta">Alta</option>
                                    <option value="Urgente">Urgente</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-exclamation-triangle"></i> Descrição do Problema</h3>
                        
                        <div class="form-group">
                            <label>Defeito Relatado pelo Cliente</label>
                            <textarea name="defeito_relatado" id="defeito_relatado" class="form-control" rows="3" required 
                                      placeholder="Descreva o problema relatado pelo cliente"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Diagnóstico Técnico</label>
                            <textarea name="diagnostico_tecnico" id="diagnostico_tecnico" class="form-control" rows="3" 
                                      placeholder="Diagnóstico técnico inicial (pode ser preenchido posteriormente)"></textarea>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-tools"></i> Serviços e Peças</h3>
                        
                        <div id="itensContainer">
                            <div class="item-row">
                                <div class="form-group">
                                    <label>Tipo</label>
                                    <select name="itens[0][tipo]" class="item-tipo form-control" onchange="carregarItensOS(this, 0)" required>
                                        <option value="">Tipo</option>
                                        <option value="produto">Produto</option>
                                        <option value="servico">Serviço</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Item</label>
                                    <select name="itens[0][item_id]" class="item-select form-control" required onchange="atualizarPrecoOS(this, 0)">
                                        <option value="">Selecione...</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Qtd</label>
                                    <input type="number" name="itens[0][quantidade]" class="item-quantidade form-control" value="1" min="1" step="0.01" onchange="calcularTotalOS(0)" required>
                                </div>
                                <div class="form-group">
                                    <label>Preço Unit.</label>
                                    <input type="text" name="itens[0][preco_unitario]" class="item-preco form-control money" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Total</label>
                                    <input type="text" name="itens[0][total]" class="item-total form-control money" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Descrição</label>
                                    <input type="text" name="itens[0][descricao]" class="item-descricao form-control" placeholder="Descrição">
                                </div>
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="button" class="btn btn-danger" onclick="removerItemOS(this)" style="background: #ef4444;">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <button type="button" class="btn btn-primary" onclick="adicionarItemOS()">
                            <i class="fas fa-plus"></i> Adicionar Item
                        </button>
                    </div>

                    <div class="form-section">
                        <h3 class="section-title"><i class="fas fa-sticky-note"></i> Observações</h3>
                        
                        <div class="form-group">
                            <textarea name="observacoes" class="form-control" rows="3" 
                                      placeholder="Observações adicionais sobre a ordem de serviço"></textarea>
                        </div>
                    </div>

                    <div style="margin-top: 32px; text-align: right; padding-top: 24px; border-top: 1px solid #e5e7eb;">
                        <button type="button" onclick="fecharModal()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Salvar Ordem de Serviço
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Alterar Status -->
    <div id="modalStatus" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h2><i class="fas fa-edit"></i> Alterar Status da OS</h2>
                <button class="close" onclick="fecharModalStatus()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formStatus" method="POST">
                    <input type="hidden" name="acao" value="alterar_status">
                    <input type="hidden" name="id" id="osId">
                    
                    <div class="form-group">
                        <label>Novo Status</label>
                        <select name="status" id="novoStatus" class="form-control" required>
                            <option value="Aberta">Aberta</option>
                            <option value="Em Andamento">Em Andamento</option>
                            <option value="Aguardando Peças">Aguardando Peças</option>
                            <option value="Concluída">Concluída</option>
                        </select>
                    </div>
                    
                    <div style="margin-top: 24px; text-align: right;">
                        <button type="button" onclick="fecharModalStatus()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Alterar Status
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Excluir OS -->
    <div id="modalExcluir" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h2><i class="fas fa-trash"></i> Excluir Ordem de Serviço</h2>
                <button class="close" onclick="fecharModalExcluir()">&times;</button>
            </div>
            
            <div class="modal-body">
                <form id="formExcluir" method="POST">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" id="excluirOsId">
                    
                    <div class="form-group">
                        <p style="font-size: 16px; color: #374151; margin-bottom: 16px;">
                            <i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i>
                            Tem certeza que deseja excluir esta ordem de serviço?
                        </p>
                        <p style="color: #6b7280; font-size: 14px;">
                            Esta ação não poderá ser desfeita. Todos os dados da OS, incluindo itens e histórico, serão permanentemente removidos.
                        </p>
                    </div>
                    
                    <div style="margin-top: 24px; text-align: right;">
                        <button type="button" onclick="fecharModalExcluir()" class="btn" style="background: #6b7280; color: white; margin-right: 12px;">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Excluir
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        let itemCountOS = 1;
        const produtosOS = <?php echo json_encode($produtos); ?>;
        const servicosOS = <?php echo json_encode($servicos); ?>;

        function abrirModal() {
            document.getElementById('modalOS').style.display = 'block';
            document.getElementById('modalTitulo').textContent = 'Nova Ordem de Serviço';
            document.getElementById('formOS').reset();
            document.getElementById('itensContainer').innerHTML = `
                <div class="item-row">
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="itens[0][tipo]" class="item-tipo form-control" onchange="carregarItensOS(this, 0)" required>
                            <option value="">Tipo</option>
                            <option value="produto">Produto</option>
                            <option value="servico">Serviço</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Item</label>
                        <select name="itens[0][item_id]" class="item-select form-control" required onchange="atualizarPrecoOS(this, 0)">
                            <option value="">Selecione...</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Qtd</label>
                        <input type="number" name="itens[0][quantidade]" class="item-quantidade form-control" value="1" min="1" step="0.01" onchange="calcularTotalOS(0)" required>
                    </div>
                    <div class="form-group">
                        <label>Preço Unit.</label>
                        <input type="text" name="itens[0][preco_unitario]" class="item-preco form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="itens[0][total]" class="item-total form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Descrição</label>
                        <input type="text" name="itens[0][descricao]" class="item-descricao form-control" placeholder="Descrição">
                    </div>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" class="btn btn-danger" onclick="removerItemOS(this)" style="background: #ef4444;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            itemCountOS = 1;
            
            <?php if ($orcamento): ?>
            document.getElementById('cliente_id').value = '<?php echo $orcamento['cliente_id']; ?>';
            <?php endif; ?>
        }

        function alterarStatus(osId) {
            document.getElementById('modalStatus').style.display = 'block';
            document.getElementById('osId').value = osId;
        }

        function fecharModalStatus() {
            document.getElementById('modalStatus').style.display = 'none';
        }

        function excluirOS(osId) {
            document.getElementById('modalExcluir').style.display = 'block';
            document.getElementById('excluirOsId').value = osId;
        }

        function fecharModalExcluir() {
            document.getElementById('modalExcluir').style.display = 'none';
        }

        function concluirOS(osId) {
            if (confirm('Deseja marcar esta OS como concluída?\n\nEsta ação não pode ser desfeita.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="alterar_status">
                    <input type="hidden" name="id" value="${osId}">
                    <input type="hidden" name="status" value="Concluída">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function filtrarOS() {
            const status = document.getElementById('statusFilter').value;
            let url = 'ordens_servico.php';
            if (status) {
                url += '?status=' + encodeURIComponent(status);
            }
            window.location.href = url;
        }

        // Funções para itens
        function adicionarItemOS() {
            const html = `
                <div class="item-row">
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="itens[${itemCountOS}][tipo]" class="item-tipo form-control" onchange="carregarItensOS(this, ${itemCountOS})" required>
                            <option value="">Tipo</option>
                            <option value="produto">Produto</option>
                            <option value="servico">Serviço</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Item</label>
                        <select name="itens[${itemCountOS}][item_id]" class="item-select form-control" required onchange="atualizarPrecoOS(this, ${itemCountOS})">
                            <option value="">Selecione...</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Qtd</label>
                        <input type="number" name="itens[${itemCountOS}][quantidade]" class="item-quantidade form-control" value="1" min="1" step="0.01" onchange="calcularTotalOS(${itemCountOS})" required>
                    </div>
                    <div class="form-group">
                        <label>Preço Unit.</label>
                        <input type="text" name="itens[${itemCountOS}][preco_unitario]" class="item-preco form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Total</label>
                        <input type="text" name="itens[${itemCountOS}][total]" class="item-total form-control money" readonly>
                    </div>
                    <div class="form-group">
                        <label>Descrição</label>
                        <input type="text" name="itens[${itemCountOS}][descricao]" class="item-descricao form-control" placeholder="Descrição">
                    </div>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" class="btn btn-danger" onclick="removerItemOS(this)" style="background: #ef4444;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            document.getElementById('itensContainer').insertAdjacentHTML('beforeend', html);
            itemCountOS++;
        }

        function carregarItensOS(select, index) {
            const tipo = select.value;
            const itemSelect = select.parentNode.parentNode.querySelector('.item-select');
            itemSelect.innerHTML = '<option value="">Selecione...</option>';
            
            const itens = tipo === 'produto' ? produtosOS : servicosOS;
            itens.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = `${item.codigo} - ${item.nome} (${formatarMoeda(item.preco)})`;
                option.setAttribute('data-preco', item.preco);
                option.setAttribute('data-descricao', item.nome);
                itemSelect.appendChild(option);
            });
        }

        function atualizarPrecoOS(select, index) {
            const selectedOption = select.options[select.selectedIndex];
            const preco = selectedOption.getAttribute('data-preco');
            const descricao = selectedOption.getAttribute('data-descricao');
            
            const row = select.parentNode.parentNode;
            row.querySelector('.item-preco').value = preco;
            row.querySelector('.item-descricao').value = descricao;
            
            calcularTotalOS(index);
        }

        function calcularTotalOS(index) {
            const rows = document.querySelectorAll('.item-row');
            const row = rows[index];
            const quantidade = parseFloat(row.querySelector('.item-quantidade').value) || 0;
            const preco = parseFloat(row.querySelector('.item-preco').value) || 0;
            const total = quantidade * preco;
            
            row.querySelector('.item-total').value = total.toFixed(2);
        }

        function removerItemOS(button) {
            if (document.querySelectorAll('.item-row').length > 1) {
                button.parentNode.parentNode.remove();
            }
        }

        function formatarMoeda(valor) {
            return 'R$ ' + parseFloat(valor).toFixed(2).replace('.', ',');
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modalOS = document.getElementById('modalOS');
            const modalStatus = document.getElementById('modalStatus');
            const modalExcluir = document.getElementById('modalExcluir');
            
            if (event.target === modalOS) {
                fecharModal();
            }
            if (event.target === modalStatus) {
                fecharModalStatus();
            }
            if (event.target === modalExcluir) {
                fecharModalExcluir();
            }
        }

        function fecharModal() {
            document.getElementById('modalOS').style.display = 'none';
        }

        // Formatação de moeda para inputs
        document.addEventListener('DOMContentLoaded', function() {
            const moneyInputs = document.querySelectorAll('.money');
            
            moneyInputs.forEach(input => {
                // Formatar ao digitar
                input.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    
                    if (value === '') {
                        e.target.value = '';
                        return;
                    }
                    
                    // Adiciona zeros à esquerda para ter pelo menos 3 dígitos
                    while (value.length < 3) {
                        value = '0' + value;
                    }
                    
                    const cents = value.slice(-2);
                    const reais = value.slice(0, -2) || '0';
                    
                    // Formata com separadores de milhar
                    const reaisFormatado = reais.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
                    
                    e.target.value = `R$ ${reaisFormatado},${cents}`;
                });
            });
        });

        // Debug no console
        console.log('Página de ordens de serviço carregada');
    </script>
</body>
</html>