<?php
include 'config.php';
verificarLogin();

// Buscar dados do usuário logado
$usuario_id = $_SESSION['usuario_id'];
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch();

// Se não encontrou o usuário, redireciona
if (!$usuario) {
    header('Location: dashboard.php');
    exit;
}

// Processar atualização do perfil
$mensagem = '';
$tipo_mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'] ?? '';
        $data_nascimento = $_POST['data_nascimento'] ?? null;
        
        // Verificar se email já existe (excluindo o próprio usuário)
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
        $stmt->execute([$email, $usuario_id]);
        
        if ($stmt->fetch()) {
            $mensagem = 'Este email já está em uso por outro usuário.';
            $tipo_mensagem = 'erro';
        } else {
            // Atualizar dados básicos
            $stmt = $pdo->prepare("UPDATE usuarios SET nome = ?, email = ?, telefone = ?, data_nascimento = ? WHERE id = ?");
            $stmt->execute([$nome, $email, $telefone, $data_nascimento, $usuario_id]);
            
            // Atualizar senha se fornecida
            if (!empty($_POST['senha'])) {
                if ($_POST['senha'] === $_POST['confirmar_senha']) {
                    if (strlen($_POST['senha']) >= 6) {
                        $senha_hash = password_hash($_POST['senha'], PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
                        $stmt->execute([$senha_hash, $usuario_id]);
                    } else {
                        $mensagem = 'A senha deve ter pelo menos 6 caracteres.';
                        $tipo_mensagem = 'erro';
                    }
                } else {
                    $mensagem = 'As senhas não coincidem.';
                    $tipo_mensagem = 'erro';
                }
            }
            
            // Atualizar foto se enviada
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
                $foto = $_FILES['foto'];
                $extensao = strtolower(pathinfo($foto['name'], PATHINFO_EXTENSION));
                $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                
                if (in_array($extensao, $extensoes_permitidas)) {
                    // Verificar tamanho do arquivo (máximo 5MB)
                    if ($foto['size'] <= 5 * 1024 * 1024) {
                        $nome_foto = 'usuario_' . $usuario_id . '_' . time() . '.' . $extensao;
                        $caminho_foto = 'uploads/usuarios/' . $nome_foto;
                        
                        // Criar diretório se não existir
                        if (!is_dir('uploads/usuarios')) {
                            mkdir('uploads/usuarios', 0777, true);
                        }
                        
                        if (move_uploaded_file($foto['tmp_name'], $caminho_foto)) {
                            // Remover foto antiga se existir
                            if (!empty($usuario['foto']) && file_exists($usuario['foto']) && $usuario['foto'] != 'uploads/usuarios/default.png') {
                                unlink($usuario['foto']);
                            }
                            
                            $stmt = $pdo->prepare("UPDATE usuarios SET foto = ? WHERE id = ?");
                            $stmt->execute([$caminho_foto, $usuario_id]);
                        }
                    } else {
                        $mensagem = 'A imagem deve ter no máximo 5MB.';
                        $tipo_mensagem = 'erro';
                    }
                } else {
                    $mensagem = 'Formato de imagem não suportado. Use JPG, PNG, GIF ou WebP.';
                    $tipo_mensagem = 'erro';
                }
            }
            
            // Remover foto se solicitado
            if (isset($_POST['remover_foto']) && $_POST['remover_foto'] == '1') {
                if (!empty($usuario['foto']) && file_exists($usuario['foto']) && $usuario['foto'] != 'uploads/usuarios/default.png') {
                    unlink($usuario['foto']);
                }
                $stmt = $pdo->prepare("UPDATE usuarios SET foto = NULL WHERE id = ?");
                $stmt->execute([$usuario_id]);
            }
            
            if (empty($mensagem)) {
                $mensagem = 'Perfil atualizado com sucesso!';
                $tipo_mensagem = 'sucesso';
                
                // Recarregar dados do usuário
                $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
                $stmt->execute([$usuario_id]);
                $usuario = $stmt->fetch();
                
                // Atualizar sessão
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_foto'] = $usuario['foto'];
            }
        }
    } catch (Exception $e) {
        $mensagem = 'Erro ao atualizar perfil: ' . $e->getMessage();
        $tipo_mensagem = 'erro';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;
            --purple: #8b5cf6;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* Header Compacto */
        .header {
            background: white;
            padding: 0.75rem 1.5rem;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 60px;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.1rem;
            color: #64748b;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 0.375rem;
            transition: background-color 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .logo img {
            height: 2rem;
        }
        
        .logo h1 {
            font-size: 1.2rem;
            font-weight: 700;
            color: #1e293b;
            white-space: nowrap;
        }
        
        .logo span {
            color: var(--primary);
        }
        
        .header-title {
            font-size: 1.1rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            cursor: pointer;
        }
        
        .user-profile-link {
            cursor: pointer;
            transition: color 0.2s;
            font-weight: 500;
            font-size: 0.9rem;
            white-space: nowrap;
        }
        
        .user-profile-link:hover {
            color: var(--primary);
        }
        
        .user-avatar {
            width: 2.25rem;
            height: 2.25rem;
            background: var(--primary);
            border-radius: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, background-color 0.2s;
            font-size: 0.9rem;
        }
        
        .user-avatar:hover {
            transform: scale(1.05);
            background: var(--purple);
        }
        
        /* Sidebar Compacto */
        .sidebar {
            position: fixed;
            left: 0;
            top: 60px;
            height: calc(100vh - 60px);
            width: 220px;
            background: #1e293b;
            color: white;
            z-index: 999;
            transition: transform 0.3s ease;
            overflow-y: auto;
            transform: translateX(0);
        }
        
        .sidebar.open {
            transform: translateX(0);
        }
        
        .nav-links {
            list-style: none;
            padding: 0.75rem 0;
        }
        
        .nav-links li {
            margin: 0.2rem 0.75rem;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 0.6rem 0.75rem;
            border-radius: 0.375rem;
            transition: all 0.2s;
            font-size: 0.85rem;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: var(--primary);
            color: white;
        }
        
        .nav-links i {
            width: 1.1rem;
            margin-right: 0.6rem;
            font-size: 0.9rem;
        }
        
        /* Main Content Ajustado */
        .main-content {
            margin-top: 60px;
            margin-left: 220px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            min-height: calc(100vh - 60px);
            flex: 1;
            width: calc(100% - 220px);
        }
        
        /* Footer Compacto */
        footer {
            background: #0f172a;
            color: white;
            padding: 1rem 1.5rem;
            text-align: center;
            margin-left: 220px;
            transition: margin-left 0.3s ease;
            font-size: 0.875rem;
        }
        
        /* Conteúdo do Perfil Compacto */
        .profile-container {
            max-width: 900px;
            margin: 0 auto;
            width: 100%;
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
            padding: 1.5rem;
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .profile-avatar {
            position: relative;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--purple));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            font-weight: 600;
            overflow: hidden;
            flex-shrink: 0;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .profile-info {
            flex: 1;
            min-width: 0;
        }
        
        .profile-info h1 {
            font-size: 1.5rem;
            color: #1e293b;
            margin-bottom: 0.5rem;
            word-wrap: break-word;
        }
        
        .profile-info p {
            color: #64748b;
            margin-bottom: 0.25rem;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-item {
            background: white;
            padding: 1.25rem;
            border-radius: 0.75rem;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .stat-number {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 0.8rem;
        }
        
        .profile-card {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
            overflow: hidden;
        }
        
        .card-header {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        
        .card-header h2 {
            font-size: 1.1rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #374151;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 0.7rem 0.9rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 0.9rem;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .btn {
            padding: 0.7rem 1.25rem;
            border: none;
            border-radius: 0.5rem;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #374151;
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            background: #dc2626;
        }
        
        .btn-small {
            padding: 0.5rem 0.9rem;
            font-size: 0.8rem;
        }
        
        .alert {
            padding: 0.9rem 1.25rem;
            border-radius: 0.5rem;
            margin-bottom: 1.25rem;
            border-left: 4px solid;
            font-size: 0.9rem;
        }
        
        .alert-success {
            background: #f0fdf4;
            border-color: var(--success);
            color: #166534;
        }
        
        .alert-error {
            background: #fef2f2;
            border-color: var(--danger);
            color: #991b1b;
        }
        
        .file-upload {
            position: relative;
            display: inline-block;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .photo-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #e2e8f0;
            margin-bottom: 0.75rem;
            flex-shrink: 0;
        }
        
        /* Novos estilos adicionados */
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #64748b;
            cursor: pointer;
            font-size: 0.9rem;
        }

        .password-input {
            position: relative;
        }

        .password-strength {
            margin-top: 0.5rem;
            font-size: 0.8rem;
        }

        .strength-weak { color: #ef4444; }
        .strength-medium { color: #f59e0b; }
        .strength-strong { color: #10b981; }

        .photo-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .photo-section {
            display: flex;
            align-items: flex-start;
            gap: 1.5rem;
            flex-wrap: wrap;
        }

        .photo-controls {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        /* Overlay para mobile */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 998;
        }

        .sidebar-overlay.active {
            display: block;
        }

        /* Responsividade Melhorada */
        @media (max-width: 1024px) {
            .sidebar {
                width: 200px;
            }
            
            .main-content {
                margin-left: 200px;
                width: calc(100% - 200px);
            }
            
            footer {
                margin-left: 200px;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 260px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 1rem;
            }
            
            footer {
                margin-left: 0;
            }
            
            .profile-header {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
                padding: 1.25rem;
            }
            
            .profile-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 0.75rem;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .photo-section {
                justify-content: center;
                text-align: center;
            }
            
            .header-title {
                font-size: 1rem;
            }
            
            .user-profile-link {
                display: none;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 0.75rem 1rem;
                height: 55px;
            }
            
            .sidebar {
                top: 55px;
                height: calc(100vh - 55px);
            }
            
            .main-content {
                margin-top: 55px;
                padding: 0.75rem;
            }
            
            .profile-stats {
                grid-template-columns: 1fr;
            }
            
            .card-body {
                padding: 1.25rem;
            }
            
            .profile-header {
                padding: 1rem;
            }
            
            .logo h1 {
                font-size: 1.1rem;
            }
            
            .header-title {
                font-size: 0.9rem;
            }
        }

        @media (max-width: 360px) {
            .profile-avatar {
                width: 80px;
                height: 80px;
                font-size: 1.5rem;
            }
            
            .photo-preview {
                width: 100px;
                height: 100px;
            }
            
            .btn {
                padding: 0.6rem 1rem;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="logo.png" alt="SmartMais">
                <h2>Smart<span>Mais</span></h2>
            </div>
        </div>
        
        <div class="header-title">
            <i class="fas fa-user"></i> Meu Perfil
        </div>
        
        <div class="user-info" onclick="window.location.href='perfil_usuario.php'">
            <span class="user-profile-link">Olá, <?php echo $_SESSION['usuario_nome']; ?></span>
            <div class="user-avatar">
                <?php 
                if (!empty($usuario['foto']) && file_exists($usuario['foto'])) {
                    echo '<img src="' . $usuario['foto'] . '" alt="Avatar" style="width: 100%; height: 100%; border-radius: 0.5rem; object-fit: cover;">';
                } else {
                    echo strtoupper(substr($usuario['nome'], 0, 1));
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Overlay para mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="vendas.php"><i class="fas fa-shopping-cart"></i> Vendas</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="relatorios.php"><i class="fas fa-chart-pie"></i> Relatórios</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li class="active"><a href="perfil_usuario.php"><i class="fas fa-user-edit"></i> Meu Perfil</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="profile-container">
            <?php if ($mensagem): ?>
                <div class="alert alert-<?php echo $tipo_mensagem === 'sucesso' ? 'success' : 'error'; ?>">
                    <i class="fas fa-<?php echo $tipo_mensagem === 'sucesso' ? 'check' : 'exclamation-triangle'; ?>"></i>
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>

            <!-- Cabeçalho do Perfil -->
            <div class="profile-header">
                <div class="profile-avatar">
                    <?php if (!empty($usuario['foto']) && file_exists($usuario['foto'])): ?>
                        <img src="<?php echo $usuario['foto']; ?>" alt="Foto do perfil" id="currentPhoto">
                    <?php else: ?>
                        <div id="currentPhoto"><?php echo strtoupper(substr($usuario['nome'], 0, 1)); ?></div>
                    <?php endif; ?>
                </div>
                <div class="profile-info">
                    <h1><?php echo $usuario['nome']; ?></h1>
                    <p><i class="fas fa-envelope"></i> <?php echo $usuario['email']; ?></p>
                    <?php if (!empty($usuario['telefone'])): ?>
                        <p><i class="fas fa-phone"></i> <?php echo $usuario['telefone']; ?></p>
                    <?php endif; ?>
                    <?php if (!empty($usuario['data_nascimento'])): ?>
                        <p><i class="fas fa-birthday-cake"></i> <?php echo date('d/m/Y', strtotime($usuario['data_nascimento'])); ?></p>
                    <?php endif; ?>
                    <p><i class="fas fa-calendar"></i> Membro desde <?php echo date('d/m/Y', strtotime($usuario['data_criacao'])); ?></p>
                </div>
            </div>

            <!-- Estatísticas -->
            <div class="profile-stats">
                <div class="stat-item">
                    <div class="stat-number"><?php 
                        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM vendas WHERE usuario_id = ? AND status = 'concluida'");
                        $stmt->execute([$usuario_id]);
                        echo $stmt->fetch()['total'];
                    ?></div>
                    <div class="stat-label">Vendas Realizadas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">R$ <?php 
                        $stmt = $pdo->prepare("SELECT COALESCE(SUM(total), 0) as total FROM vendas WHERE usuario_id = ? AND status = 'concluida'");
                        $stmt->execute([$usuario_id]);
                        echo number_format($stmt->fetch()['total'], 2, ',', '.');
                    ?></div>
                    <div class="stat-label">Total em Vendas</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php 
                        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM ordens_servico WHERE usuario_id = ?");
                        $stmt->execute([$usuario_id]);
                        echo $stmt->fetch()['total'];
                    ?></div>
                    <div class="stat-label">Ordens de Serviço</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php 
                        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM clientes WHERE usuario_cadastro = ?");
                        $stmt->execute([$usuario_id]);
                        echo $stmt->fetch()['total'];
                    ?></div>
                    <div class="stat-label">Clientes Cadastrados</div>
                </div>
            </div>

            <!-- Formulário de Edição -->
            <div class="profile-card">
                <div class="card-header">
                    <h2><i class="fas fa-edit"></i> Editar Perfil</h2>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="foto">Foto do Perfil</label>
                            <div class="photo-section">
                                <?php if (!empty($usuario['foto']) && file_exists($usuario['foto'])): ?>
                                    <img src="<?php echo $usuario['foto']; ?>" alt="Foto atual" class="photo-preview" id="photoPreview">
                                <?php else: ?>
                                    <div class="photo-preview" id="photoPreview" style="background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-size: 2.5rem; color: #64748b;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="photo-controls">
                                    <div class="file-upload">
                                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('foto').click()">
                                            <i class="fas fa-camera"></i> Alterar Foto
                                        </button>
                                        <input type="file" id="foto" name="foto" accept="image/*" onchange="previewImage(this)">
                                    </div>
                                    <?php if (!empty($usuario['foto']) && file_exists($usuario['foto'])): ?>
                                        <div class="photo-actions">
                                            <button type="button" class="btn btn-danger btn-small" onclick="removePhoto()">
                                                <i class="fas fa-trash"></i> Remover Foto
                                            </button>
                                        </div>
                                        <input type="hidden" name="remover_foto" id="remover_foto" value="0">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="nome">Nome Completo *</label>
                                <input type="text" id="nome" name="nome" class="form-control" value="<?php echo htmlspecialchars($usuario['nome']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email">E-mail *</label>
                                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($usuario['email']); ?>" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="telefone">Telefone</label>
                                <input type="text" id="telefone" name="telefone" class="form-control" value="<?php echo htmlspecialchars($usuario['telefone'] ?? ''); ?>" placeholder="(00) 00000-0000">
                            </div>

                            <div class="form-group">
                                <label for="data_nascimento">Data de Nascimento</label>
                                <input type="date" id="data_nascimento" name="data_nascimento" class="form-control" value="<?php echo $usuario['data_nascimento'] ?? ''; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Alterar Senha</label>
                            <div class="password-input">
                                <input type="password" id="senha" name="senha" class="form-control" placeholder="Digite a nova senha (mínimo 6 caracteres)" onkeyup="checkPasswordStrength(this.value)">
                                <button type="button" class="password-toggle" onclick="togglePassword('senha')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div id="passwordStrength" class="password-strength"></div>
                        </div>

                        <div class="form-group">
                            <div class="password-input">
                                <input type="password" id="confirmar_senha" name="confirmar_senha" class="form-control" placeholder="Confirme a nova senha">
                                <button type="button" class="password-toggle" onclick="togglePassword('confirmar_senha')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Salvar Alterações
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="window.location.href='dashboard.php'">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div style="text-align: center; color: #94a3b8;">
            <p>&copy; 2024 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script>
        // Menu Mobile
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        function toggleSidebar() {
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
        }

        mobileMenuBtn.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);

        // Fechar sidebar ao clicar em um link (mobile)
        sidebar.addEventListener('click', (e) => {
            if (e.target.tagName === 'A' && window.innerWidth <= 768) {
                toggleSidebar();
            }
        });

        // Preview da imagem
        function previewImage(input) {
            const preview = document.getElementById('photoPreview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.innerHTML = '<img src="' + e.target.result + '" alt="Preview" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">';
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Remover foto
        function removePhoto() {
            if (confirm('Tem certeza que deseja remover sua foto de perfil?')) {
                document.getElementById('remover_foto').value = '1';
                document.getElementById('photoPreview').innerHTML = '<div style="width: 100%; height: 100%; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-size: 2.5rem; color: #64748b; border-radius: 50%;"><i class="fas fa-user"></i></div>';
                if (document.querySelector('.photo-actions')) {
                    document.querySelector('.photo-actions').style.display = 'none';
                }
            }
        }

        // Alternar visibilidade da senha
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = field.nextElementSibling.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Verificar força da senha
        function checkPasswordStrength(password) {
            const strengthBar = document.getElementById('passwordStrength');
            
            if (password.length === 0) {
                strengthBar.innerHTML = '';
                return;
            }
            
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            let strengthText = '';
            let strengthClass = '';
            
            if (strength <= 2) {
                strengthText = 'Fraca';
                strengthClass = 'strength-weak';
            } else if (strength <= 4) {
                strengthText = 'Média';
                strengthClass = 'strength-medium';
            } else {
                strengthText = 'Forte';
                strengthClass = 'strength-strong';
            }
            
            strengthBar.innerHTML = '<span class="' + strengthClass + '">Força da senha: ' + strengthText + '</span>';
        }

        // Máscara de telefone
        document.getElementById('telefone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length <= 10) {
                value = value.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
            } else {
                value = value.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
            }
            e.target.value = value;
        });

        // Formatação inicial da data de nascimento
        document.addEventListener('DOMContentLoaded', function() {
            const dataNascimento = document.getElementById('data_nascimento');
            if (dataNascimento.value) {
                // Converte de YYYY-MM-DD para o formato do input date
                const date = new Date(dataNascimento.value + 'T00:00:00');
                dataNascimento.value = date.toISOString().split('T')[0];
            }
        });

        // Fechar sidebar quando a janela for redimensionada para desktop
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.remove('active');
            }
        });
    </script>
</body>
</html>