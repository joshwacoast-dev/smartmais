<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config.php';
verificarLogin();

// Verificar permissões - apenas administradores podem acessar
if ($_SESSION['usuario_tipo'] != 'Administrador') {
    header("Location: dashboard.php");
    exit();
}

$mensagem = '';
$erro = '';

// Processar backup
if ($_POST && isset($_POST['acao']) && $_POST['acao'] == 'backup') {
    try {
        $backup_file = gerarBackup();
        $mensagem = "Backup criado com sucesso! Arquivo: " . basename($backup_file);
    } catch (Exception $e) {
        $erro = "Erro ao criar backup: " . $e->getMessage();
    }
}

// Processar reset
if ($_POST && isset($_POST['acao']) && $_POST['acao'] == 'reset') {
    $confirmacao = $_POST['confirmacao'] ?? '';
    
    if ($confirmacao === 'CONFIRMAR RESET') {
        try {
            resetarSistema();
            $mensagem = "Sistema resetado com sucesso! Todos os dados foram removidos.";
            
            // Logout automático após reset
            session_destroy();
            header("Location: login.php?sucesso=Sistema resetado com sucesso. Faça login novamente.");
            exit();
        } catch (Exception $e) {
            $erro = "Erro ao resetar sistema: " . $e->getMessage();
        }
    } else {
        $erro = "Confirmação incorreta. Digite 'CONFIRMAR RESET' para confirmar.";
    }
}

// Função para gerar backup
function gerarBackup() {
    global $pdo;
    
    $backup_dir = 'backups/';
    if (!is_dir($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }
    
    $backup_file = $backup_dir . 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $handle = fopen($backup_file, 'w');
    
    if (!$handle) {
        throw new Exception("Não foi possível criar arquivo de backup");
    }
    
    // Cabeçalho do backup
    fwrite($handle, "-- Backup do Sistema SmartMais\n");
    fwrite($handle, "-- Data: " . date('d/m/Y H:i:s') . "\n");
    fwrite($handle, "-- Banco: " . DB_NAME . "\n\n");
    
    // Lista de tabelas na ordem correta (evitando problemas de foreign keys)
    $tables = [
        'venda_itens', 'vendas', 'os_itens', 'ordens_servico', 
        'orcamento_itens', 'orcamentos', 'estoque_movimentacao',
        'documentos_compartilhados', 'assinaturas_digitais', 'logs',
        'clientes', 'produtos', 'servicos', 'usuarios', 
        'empresa_info', 'permissoes_sistema', 'cidades', 'estados'
    ];
    
    foreach ($tables as $table) {
        // Desativar foreign keys temporariamente
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        
        // Drop table se existir
        fwrite($handle, "DROP TABLE IF EXISTS `$table`;\n\n");
        
        // Create table
        $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
        $create = $stmt->fetch(PDO::FETCH_ASSOC);
        fwrite($handle, $create['Create Table'] . ";\n\n");
        
        // Inserir dados
        $stmt = $pdo->query("SELECT * FROM `$table`");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($rows) > 0) {
            fwrite($handle, "INSERT INTO `$table` VALUES\n");
            
            $values = [];
            foreach ($rows as $row) {
                $row_values = [];
                foreach ($row as $value) {
                    if ($value === null) {
                        $row_values[] = "NULL";
                    } else {
                        $row_values[] = "'" . addslashes($value) . "'";
                    }
                }
                $values[] = "(" . implode(", ", $row_values) . ")";
            }
            
            fwrite($handle, implode(",\n", $values) . ";\n\n");
        }
        
        // Reativar foreign keys
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n\n");
    }
    
    fclose($handle);
    
    // Registrar log
    registrarLog('Backup do sistema', 'Backup criado: ' . basename($backup_file));
    
    return $backup_file;
}

// Função para resetar o sistema
function resetarSistema() {
    global $pdo;
    
    // Lista de tabelas para limpar (na ordem correta para evitar problemas de FK)
    $tables = [
        'venda_itens', 'vendas', 'os_itens', 'ordens_servico', 
        'orcamento_itens', 'orcamentos', 'estoque_movimentacao',
        'documentos_compartilhados', 'assinaturas_digitais', 'logs',
        'clientes', 'produtos', 'servicos'
    ];
    
    // Desativar foreign keys
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    try {
        // Limpar dados das tabelas
        foreach ($tables as $table) {
            $pdo->exec("TRUNCATE TABLE `$table`");
        }
        
        // Resetar sequências auto_increment
        $pdo->exec("ALTER TABLE assinaturas_digitais AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE clientes AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE documentos_compartilhados AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE estoque_movimentacao AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE logs AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE orcamentos AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE orcamento_itens AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE ordens_servico AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE os_itens AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE produtos AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE servicos AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE vendas AUTO_INCREMENT = 1");
        $pdo->exec("ALTER TABLE venda_itens AUTO_INCREMENT = 1");
        
        // Manter dados essenciais
        // - Estados e cidades são mantidos
        // - Empresa info é mantido
        // - Usuários são mantidos (mas pode resetar senha do admin se necessário)
        // - Permissões são mantidas
        
        // Reativar foreign keys
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        
        // Registrar log
        registrarLog('Reset do sistema', 'Todos os dados foram resetados');
        
    } catch (Exception $e) {
        // Reativar foreign keys em caso de erro
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        throw $e;
    }
}

// Listar backups existentes
$backups = [];
$backup_dir = 'backups/';
if (is_dir($backup_dir)) {
    $files = scandir($backup_dir);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
            $file_path = $backup_dir . $file;
            $backups[] = [
                'nome' => $file,
                'caminho' => $file_path,
                'tamanho' => filesize($file_path),
                'data' => date('d/m/Y H:i:s', filemtime($file_path))
            ];
        }
    }
    
    // Ordenar por data (mais recente primeiro)
    usort($backups, function($a, $b) {
        return filemtime($b['caminho']) - filemtime($a['caminho']);
    });
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup & Reset - SmartMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #f8fafc;
            color: #334155;
            line-height: 1.6;
        }
        
        /* Header e Navegação */
        .header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        
        .mobile-menu-btn:hover {
            background: #f1f5f9;
            color: #334155;
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .header h1 i {
            color: #3b82f6;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            color: #64748b;
            font-weight: 500;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 73px;
            height: calc(100vh - 73px);
            width: 280px;
            background: #1e293b;
            color: white;
            padding: 0;
            z-index: 999;
            border-right: 1px solid #334155;
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .nav-links {
            list-style: none;
            padding: 16px 0;
        }
        
        .nav-links li {
            margin: 4px 16px;
        }
        
        .nav-links a {
            color: #cbd5e1;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: #334155;
            color: white;
        }
        
        .nav-links li.active a {
            background: #3b82f6;
            color: white;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        .nav-links i {
            width: 20px;
            margin-right: 12px;
            font-size: 16px;
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-top: 73px;
            margin-left: 280px;
            padding: 0;
            min-height: calc(100vh - 193px);
            transition: margin-left 0.3s ease;
        }
        
        .container {
            padding: 32px;
            max-width: 1200px;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid #e2e8f0;
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .card-header {
            padding: 24px 32px;
            border-bottom: 1px solid #e2e8f0;
            background: #f8fafc;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .card-header h2 i {
            color: #3b82f6;
        }
        
        .card-body {
            padding: 32px;
        }
        
        /* Alertas */
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-left-color: #ef4444;
        }
        
        .alert-warning {
            background: #fffbeb;
            color: #92400e;
            border-left-color: #f59e0b;
        }
        
        /* Botões */
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #3b82f6;
            color: white;
            box-shadow: 0 1px 3px rgba(59, 130, 246, 0.3);
        }
        
        .btn-primary:hover {
            background: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
        }
        
        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 1px 3px rgba(16, 185, 129, 0.3);
        }
        
        .btn-success:hover {
            background: #059669;
            transform: translateY(-1px);
        }
        
        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 1px 3px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
            box-shadow: 0 1px 3px rgba(107, 114, 128, 0.3);
        }
        
        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-1px);
        }
        
        /* Formulários */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background: white;
            color: #374151;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            line-height: 1.5;
        }
        
        /* Tabela */
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .table th {
            background: #f8fafc;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
            font-size: 14px;
        }
        
        .table td {
            padding: 16px 20px;
            border-bottom: 1px solid #f3f4f6;
            color: #6b7280;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        /* Seções */
        .section {
            margin-bottom: 40px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin: 24px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            color: #3b82f6;
        }
        
        /* Warning Box */
        .warning-box {
            background: #fffbeb;
            border: 1px solid #fcd34d;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .warning-box h4 {
            color: #92400e;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .warning-box p {
            color: #92400e;
            margin-bottom: 8px;
        }
        
        .warning-box ul {
            color: #92400e;
            margin-left: 20px;
            margin-bottom: 8px;
        }
        
        /* Backup List */
        .backup-item {
            display: flex;
            justify-content: between;
            align-items: center;
            padding: 16px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            margin-bottom: 12px;
            background: white;
        }
        
        .backup-info {
            flex: 1;
        }
        
        .backup-name {
            font-weight: 600;
            color: #374151;
            margin-bottom: 4px;
        }
        
        .backup-details {
            font-size: 14px;
            color: #6b7280;
        }
        
        .backup-actions {
            display: flex;
            gap: 8px;
        }
        
        /* Footer */
        footer {
            background: #0f172a;
            color: white;
            padding: 30px 20px;
            text-align: center;
            margin-left: 280px;
            transition: margin-left 0.3s ease;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        
        .footer-logo {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }
        
        .footer-logo img {
            height: 40px;
        }
        
        .footer-logo h3 {
            font-size: 22px;
            font-weight: 700;
        }
        
        .footer-logo span {
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .copyright {
            font-size: 14px;
            color: #64748b;
            border-top: 1px solid #334155;
            padding-top: 20px;
            width: 100%;
        }
        
        /* Responsividade */
        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
            }
            
            .sidebar.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            footer {
                margin-left: 0;
            }
            
            .container {
                padding: 20px;
            }
            
            .card-body {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 20px;
            }
            
            .backup-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }
            
            .backup-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }
        
        @media (max-width: 480px) {
            .header {
                padding: 12px 16px;
            }
            
            .container {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            
            .card-body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <img src="https://storessmart.com.br/logo.png" alt="SmartMais Logo">
                <h1>Smart<span>Mais</span></h1>
            </div>
        </div>
        
        <h1><i class="fas fa-database"></i> Backup & Reset</h1>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['usuario_nome'], 0, 1)); ?>
            </div>
            <span><?php echo $_SESSION['usuario_nome']; ?></span>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul class="nav-links">
            <li><a href="dashboard.php"><i class="fas fa-chart-bar"></i> Dashboard</a></li>
            <li><a href="clientes.php"><i class="fas fa-users"></i> Clientes</a></li>
            <li><a href="produtos.php"><i class="fas fa-box"></i> Produtos</a></li>
            <li><a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a></li>
            <li><a href="orcamentos.php"><i class="fas fa-file-invoice-dollar"></i> Orçamentos</a></li>
            <li><a href="ordens_servico.php"><i class="fas fa-clipboard-list"></i> Ordens de Serviço</a></li>
            <li><a href="estoque.php"><i class="fas fa-warehouse"></i> Estoque</a></li>
            <li><a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a></li>
            <li><a href="empresa.php"><i class="fas fa-building"></i> Empresa</a></li>
            <li class="active"><a href="backup_reset.php"><i class="fas fa-database"></i> Backup & Reset</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <?php if ($mensagem): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    <span><?php echo $mensagem; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($erro): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> 
                    <span><?php echo $erro; ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Seção de Backup -->
            <div class="section">
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-download"></i> Backup do Sistema</h2>
                    </div>
                    <div class="card-body">
                        <p style="margin-bottom: 20px; color: #6b7280;">
                            Crie um backup completo do sistema incluindo todos os dados: clientes, produtos, serviços, orçamentos, ordens de serviço, etc.
                        </p>
                        
                        <form method="POST">
                            <input type="hidden" name="acao" value="backup">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Criar Backup Agora
                                </button>
                            </div>
                        </form>
                        
                        <?php if (!empty($backups)): ?>
                            <div class="section-title">
                                <i class="fas fa-history"></i> Backups Existentes
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Arquivo</th>
                                            <th>Data</th>
                                            <th>Tamanho</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($backups as $backup): ?>
                                        <tr>
                                            <td>
                                                <div class="backup-name">
                                                    <i class="fas fa-file-archive"></i>
                                                    <?php echo $backup['nome']; ?>
                                                </div>
                                            </td>
                                            <td><?php echo $backup['data']; ?></td>
                                            <td><?php echo formatBytes($backup['tamanho']); ?></td>
                                            <td>
                                                <div class="backup-actions">
                                                    <a href="<?php echo $backup['caminho']; ?>" download class="btn btn-success btn-sm">
                                                        <i class="fas fa-download"></i> Download
                                                    </a>
                                                    <a href="backup_reset.php?delete=<?php echo urlencode($backup['nome']); ?>" 
                                                       class="btn btn-danger btn-sm"
                                                       onclick="return confirm('Tem certeza que deseja excluir este backup?')">
                                                        <i class="fas fa-trash"></i> Excluir
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-info-circle"></i>
                                <span>Nenhum backup encontrado.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Seção de Reset -->
            <div class="section">
                <div class="card">
                    <div class="card-header">
                        <h2><i class="fas fa-exclamation-triangle"></i> Reset do Sistema</h2>
                    </div>
                    <div class="card-body">
                        <div class="warning-box">
                            <h4><i class="fas fa-exclamation-triangle"></i> ATENÇÃO: OPERAÇÃO PERIGOSA</h4>
                            <p>Esta operação irá <strong>remover permanentemente</strong> todos os dados do sistema.</p>
                            <p><strong>Dados que serão removidos:</strong></p>
                            <ul>
                                <li>Todos os clientes cadastrados</li>
                                <li>Todos os produtos e serviços</li>
                                <li>Todos os orçamentos e ordens de serviço</li>
                                <li>Todas as vendas e movimentações de estoque</li>
                                <li>Todos os logs e documentos compartilhados</li>
                            </ul>
                            <p><strong>Dados que serão mantidos:</strong></p>
                            <ul>
                                <li>Informações da empresa</li>
                                <li>Usuários do sistema</li>
                                <li>Permissões e configurações</li>
                                <li>Estados e cidades</li>
                            </ul>
                            <p><strong style="color: #dc2626;">RECOMENDADO: Faça um backup antes de prosseguir!</strong></p>
                        </div>
                        
                        <form method="POST" onsubmit="return confirmReset()">
                            <input type="hidden" name="acao" value="reset">
                            
                            <div class="form-group">
                                <label for="confirmacao">
                                    <i class="fas fa-shield-alt"></i> Digite "CONFIRMAR RESET" para prosseguir:
                                </label>
                                <input type="text" name="confirmacao" id="confirmacao" class="form-control" 
                                       placeholder="CONFIRMAR RESET" required>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-bomb"></i> Resetar Sistema Completo
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="https://storessmart.com.br/logo.png" alt="SmartMais Logo">
                <h3>Smart<span>Mais</span></h3>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 SmartMais by Smart Tecnologia. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    
    <script>
        // Menu Mobile
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('open');
        });
        
        // Função para formatar bytes
        function formatBytes(bytes, decimals = 2) {
            if (bytes === 0) return '0 Bytes';
            
            const k = 1024;
            const dm = decimals < 0 ? 0 : decimals;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        }
        
        // Confirmação de reset
        function confirmReset() {
            const confirmacao = document.getElementById('confirmacao').value;
            if (confirmacao !== 'CONFIRMAR RESET') {
                alert('Digite "CONFIRMAR RESET" exatamente como mostrado para confirmar.');
                return false;
            }
            
            return confirm('⚠️ ATENÇÃO FINAL!\n\nEsta ação é IRREVERSÍVEL e removerá TODOS os dados do sistema.\n\nTem certeza absoluta que deseja continuar?');
        }
        
        // Adicionar formatação de bytes para a tabela
        document.addEventListener('DOMContentLoaded', function() {
            const sizeCells = document.querySelectorAll('td:nth-child(3)');
            sizeCells.forEach(cell => {
                const bytes = parseInt(cell.textContent);
                if (!isNaN(bytes)) {
                    cell.textContent = formatBytes(bytes);
                }
            });
        });
    </script>
    
    <?php
    // Função para formatar bytes (PHP)
    function formatBytes($bytes, $decimals = 2) {
        $size = ['B', 'KB', 'MB', 'GB', 'TB'];
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . ' ' . @$size[$factor];
    }
    
    // Processar exclusão de backup
    if (isset($_GET['delete'])) {
        $backup_file = 'backups/' . basename($_GET['delete']);
        if (file_exists($backup_file) {
            unlink($backup_file);
            header("Location: backup_reset.php?sucesso=Backup excluído com sucesso");
            exit();
        }
    }
    ?>
</body>
</html>